const { defaults } = require("jest-config");

module.exports = {
  setupTestFrameworkScriptFile: "./jestSetup.js",
  collectCoverage: true,
  coverageDirectory: "./coverage",
  collectCoverageFrom: [
    "**/*.{js,jsx}",
    "!**/node_modules/**",
    "!**/vendor/**",
    "!**/coverage/**",
    "!*.config.js",
    "!**/storybook-build/**",
    "!jestSetup.js"
  ],
  moduleFileExtensions: [...defaults.moduleFileExtensions, "stories.js"],
  automock: false,
  testMatch: [...defaults.testMatch, "*.test.js"],
  testResultsProcessor: "./jest-custom-reporter",
  transformIgnorePatterns: ["node_modules/(?!ck12-redux|ck12-loader)"],
  moduleNameMapper: {
    "\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$":
      "<rootDir>/__mocks__/fileMock.js"
  }
};
