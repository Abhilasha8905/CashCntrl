import moment from "moment";
import {
  FetchDataForPayments,
  getDates,
  scenarioFilteredData,
  agingSorted,
  groupByDes
} from "../utility/LiquidityUtil";

import { FROM_DATE, TO_DATE } from "../constants";

import {
  LIQUIDITY_DATA,
  SCENARIO_DATA,
  DELETE_SCENARIO,
  SAVE_SCENARIO,
  UPDATE_SCENARIO,
  CREATE_SCENARIO,
  SORT_DATA
} from "../actions/LiquidityActionTypes";

import { SCENARIO_NAMES, SELECTED_SCENARIO } from "../actions/CommonActionTypes";

const initialState = {
  data: { collection: [], payments: [] },
  fromDate: moment(FROM_DATE),
  toDate: moment(TO_DATE),
  scenarioData: [],
  dates: [],
  payment: [],
  collection: [],
  scenarioName: "Default",
  currentScenario: "Default",
  graphData: [],
  newlyCreated: false,
  updateDropDown: true,
  savedData: "",
  scenarioNames: [],
  currentScenaruiId: "1",
  selectedScenario: false,
  method: "",
  agingSorted: []
};

const DateStore = (state = initialState, action) => {
  switch (action.type) {
    case LIQUIDITY_DATA: {
      console.log(action, ".......gghhgg");
      const data = FetchDataForPayments(action.data);

      const payment = data.payments;
      const { collection } = data;
      let scenarioData = [];
      if (action.data.droppedInvoices.length > 0) {
        scenarioData = scenarioFilteredData(action.data.droppedInvoices);
      } else {
        scenarioData = action.data.droppedInvoices;
      }
      // console.log(groupByDes(scenarioData),"...data")
      const dates = getDates("09/24/2019");
      return {
        ...state,
        data,
        payment,
        collection,
        scenarioData,
        dates
      };
    }

    // case SCENARIO_DATA: {
    //   const dates = getDates("09/24/2019");

    //   const scenarioData = scenarioFilteredData(action.scenarioData);

    //   return {
    //     ...state,
    //     scenarioData,
    //     dates
    //   };
    // }
    case DELETE_SCENARIO: {
      return {
        ...state,
        currentScenario: "Default",
        scenarioName: "Default",
        currentScenaruiId: "1"
      };
    }
    case SAVE_SCENARIO: {
      console.log(action, action.id, "action");
      return {
        ...state,
        currentScenario: action.name,
        newlyCreated: false,
        savedData: action.name,
        updateDropDown: false,
        currentScenaruiId: action.id
      };
    }
    case UPDATE_SCENARIO: {
      return {
        ...state
      };
    }
    case CREATE_SCENARIO: {
      return {
        ...state,
        scenarioName: action.scenarioName,
        newlyCreated: true
      };
    }

    case SCENARIO_NAMES: {
      const scenarioNames = action.data;
      return {
        ...state,
        scenarioNames
      };
    }

    case SELECTED_SCENARIO: {
      const currentScenario = action.Scenario;
      const currentScenaruiId = action.ScenaruiId;

      return {
        ...state,
        currentScenario,
        currentScenaruiId,
        selectedScenario: true,
        scenarioName: currentScenario
      };
    }

    case SORT_DATA: {
      console.log(action, "action");
      return {
        ...state,
        collection: action.collection,
        payment: action.payment
      };
    }

    default:
      return state;
  }
};

export default DateStore;
