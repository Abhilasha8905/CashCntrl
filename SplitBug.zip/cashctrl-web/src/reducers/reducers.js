import moment from "moment-timezone";

const initialState = {
  fromDate: null,
  toDate: null,
  dates: "",
  series: "",
  dateChanged: false,
  datefilter: "Day",
  sum: 0,
  collectionFilter: "",
  options: "",
  amount: 0,
  balOne: 0,
  balTwo: 0,
  cname: [],
  point: ""
};

const DateStore = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_DATE": {
      return {
        ...state,
        fromDate: moment(action.fromDate).format("MM/DD/YYYY"),
        toDate: moment(action.toDate).format("MM/DD/YYYY"),
        dateChanged: true
      };
    }

    case "DISPLAY_DATES": {
      return {
        ...state,
        dates: action.dates
      };
    }
    case "DATA_POINT": {
      return {
        ...state,
        point: action.point,
        dateChanged: true
      };
    }
    case "SERIES": {
      return {
        ...state,
        series: action.series
      };
    }
    case "APPLY_DATES": {
      return {
        ...state,
        dateChanged: false
      };
    }
    case "FILTER_DATE": {
      return {
        ...state,
        datefilter: action.datefilter,
        dateChanged: true
      };
    }
    case "MONTH_FILTER": {
      return {
        ...state,
        dates: action.dates
      };
    }
    case "ADD_AMOUNT": {
      return {
        ...state,
        sum: action.sum
      };
    }
    case "TOP_COLLECTION": {
      return {
        ...state,
        collectionFilter: action.collectionFilter,
        dateChanged: true
      };
    }
    case "SET_FILTER": {
      return {
        ...state,
        options: action.options
      };
    }

    case "CUSTOMER_FILTER": {
      return {
        ...state,
        cname: action.cname,
        dateChanged: true
      };
    }

    case "ENTER_AMOUNT": {
      return {
        ...state,
        amount: action.amount,
        dateChanged: true
      };
    }
    case "RANGE": {
      return {
        ...state,
        balOne: action.balOne,
        balTwo: action.balTwo,
        dateChanged: true
      };
    }

    case "IS_DROPPED": {
      return {
        ...state
      };
    }
    default:
      return state;
  }
};

export default DateStore;
