import moment from "moment";
import {
  InFlowData,
  OutFlowData,
  BalanceData,
  Dates,
  extractData,
  groupBy,
  extractDataForReminder,
} from "../utility/dasboardUtils";

import { FROM_DATE, TO_DATE } from "../constants";

import {
  DASHBOARD_DATA,
  DASHBOARD_FAILURE,
  DASHBOARD_ADD_DATE,
  DASHBOARD_FILTER_DATE,
  DASHBOARD_DATA_POINT,
  DASHBOARD_CARDS_DATA,
  DASHBOARD_PDC_CLEAR_DATA,
  DASHBOARD_BANK_BALANCE,
  DASHBOARD_CNCI,
  DASHBOARD_CNCR,
  REMINDER_DATA
} from "../actions/DashboardActionTypes";

const initialState = {
  data: [],
  fromDate: moment(FROM_DATE),
  toDate: moment(TO_DATE),
  dates: "",
  dateChanged: false,
  datefilter: "Day",
  sum: 0,
  cname: [],
  point: "",
  cleanData: [],
  balanceData: [],
  inFlowData: [],
  outFlowData: [],
  bankBalance: "",
  cnClear: "",
  ciClear: "",
  pdcIssue: "",
  cashBalance: "",
  dasboardTypeData: [1, 2, 3, 4],
  dashboardTypeDataCnci: [],
  dashboardTypeDataCncr: [],
  dashboardType: "CNC",
  cardData: {},
  reminderCollections:[],
  bankBalance: false
};

const DashboardReducer = (state = initialState, action) => {
  switch (action.type) {
    case DASHBOARD_CARDS_DATA: {
      const { data } = action;
      const { bankBalance } = data;
      // const { cnClear } = data;
      const { pdcIssue } = data;
      const { cashBalance } = data;
      const dasboardTypeData = data.accounts;
      return {
        ...state,
        cardData: data,
        bankBalance,
        dashboardType: "bankBalance",
        pdcIssue,
        cashBalance,
        dasboardTypeData,
      };
    }
    case DASHBOARD_DATA: {
      const cleanData = extractData(action.data, state.datefilter);
      const data = groupBy(cleanData, state.datefilter);
      const balanceData = BalanceData(data);
      const inFlowData = InFlowData(data);
      const outFlowData = OutFlowData(data);
      const dates = Dates(data, state.datefilter);
      return {
        ...state,
        data,
        balanceData,
        inFlowData,
        outFlowData,
        dates
      };
    }

    case DASHBOARD_BANK_BALANCE: {
      const dasboardTypeData = state.cardData.accounts;
      return {
        ...state,
        dasboardTypeData
      };
    }

    case DASHBOARD_ADD_DATE: {
      return {
        ...state,
        fromDate: moment(action.fromDate).format("MM/DD/YYYY"),
        toDate: moment(action.toDate).format("MM/DD/YYYY")
      };
    }

    case DASHBOARD_PDC_CLEAR_DATA: {
      const dasboardTypeData = action.PDCOrClearData;
      const { dashboardType } = action;
      return {
        ...state,
        dasboardTypeData,
        dashboardType
      };
    }
   case REMINDER_DATA: {
     const reminderCollections=extractDataForReminder(action.data.collections)
     return {
       ...state,
       reminderCollections
     }
   }
    case DASHBOARD_CNCI: {
      const dashboardTypeData = action.PDCOrClearData;
      const { dashboardType } = action;
      return {
        ...state,
        dashboardTypeDataCnci: dashboardType === "CNCI" ? dashboardTypeData : [],
        ciClear: action.total.amount,
        dashboardType
      };
    }
    case DASHBOARD_CNCR: {
      const dashboardTypeData = action.PDCOrClearData;
      const { dashboardType } = action;
      return {
        ...state,
        dashboardTypeDataCncr: dashboardType === "CNCR" ? dashboardTypeData : [],
        cnClear: action.total.amount,
        dashboardType
      };
    }

    case DASHBOARD_DATA_POINT: {
      return {
        ...state,
        point: action.point,
        dateChanged: true
      };
    }

    case DASHBOARD_FILTER_DATE: {
      const cleanData = extractData(state.data, action.datefilter);
      const data = groupBy(cleanData, action.datefilter);
      const balanceData = BalanceData(data);
      const inFlowData = InFlowData(data);
      const outFlowData = OutFlowData(data);
      const dates = Dates(data, action.datefilter);

      return {
        ...state,
        datefilter: action.datefilter,
        balanceData,
        inFlowData,
        outFlowData,
        dates,
        cleanData
      };
    }

    default:
      return state;
  }
};

export default DashboardReducer;
