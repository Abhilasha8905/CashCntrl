import moment from "moment";

import {
  fetchCategories,
  seriesFun,
  getNames,
  getVendorNames,
  extractData,
  extractDataForCluster
} from "../utility/newOutflow";

import {
  getCustomerClusterNames,
  
  getVendorClusterNames,
  customerClusterNames,
  vendorClusterNames,
  extractCustomerIdsFromCluster
} from "../utility/newutil";

// import { fetchCategories, seriesFun, getNames, extractData } from "../utility/newOutflow";
import { FROM_DATE, TO_DATE } from "../constants";

import {
  OUTFLOW_DATA,
  OUTFLOW_ADD_DATE,
  OUTFLOW_DISPLAY_DATES,
  OUTFLOW_SERIES,
  OUTFLOW_APPLY_DATES,
  OUTFLOW_FILTER_DATE,
  OUTFLOW_MONTH_FILTER,
  OUTFLOW_DATA_POINT,
  OUTFLOW_ADD_AMOUNT,
  OUTFLOW_TOP_COLLECTION,
  OUTFLOW_CUSTOMER_FILTER,
  OUTFLOW_SET_FILTER,
  OUTFLOW_ENTER_AMOUNT,
  OUTFLOW_RANGE,
  FILTERLIST_DATA,
  VENDOR_LIST,
  CLUSTER_DATA,
  CUSTOMERDATA_FROM_ID,
  DATA_FOR_CLUSTER_VIEW,
  OUTFLOW_UPDATE
} from "../actions/OutflowActionTypes";

const initialState = {
  data: [],
  initialData: [],
  fromDate: moment(FROM_DATE),
  toDate: moment(TO_DATE),
  dates: "",
  series: "",
  dateChanged: false,
  datefilter: "Day",
  sum: 0,
  collectionFilter: "",
  options: "",
  amount: 0,
  balOne: 0,
  otherCollections:[],
  balTwo: 0,
  cname: [],
  point: "",
  fullDates:[],
  productsList: [],
  initialList: [],
  cleanData: [],
  vendorlist: [],
  groupedData:{},
  vendorClusterData: [],
  customerDataFromId: {},
  customersIdsInCluster: [],
  customersIdsInCluster: []
};

const DateStore = (state = initialState, action) => {
  switch (action.type) {
    case OUTFLOW_DATA: {
      const cleanData = extractData(action.data, []);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        []
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];
      const initialList = getNames(cleanData, []);
      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        []
      );
      const productsList = getNames(cleanData, []);
      return {
        ...state,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        fullDates,
        sum,
        initialList,
        data: action.data,
        cleanData,
        initialData: cleanData,
        productsList
      };
    }
    case DATA_FOR_CLUSTER_VIEW: {
      const dataForCluster = extractDataForCluster(state.data, state.customersIdsInCluster);
      const cleanData = extractData(dataForCluster, state.cname);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const productsList = getNames(cleanData, state.cname);
      return {
        ...state,
        dataForCluster,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        fullDates,
        sum,
        cleanData,
        productsList
      };
    }
    case OUTFLOW_UPDATE: {
      const cleanData = state.initialData;
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        []
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];
      // const initialList = getNames(state.cleanData, []);
      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        []
      );
      const productsList = getNames(cleanData, []);
      return {
        ...state,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        fullDates,
        cleanData,
        sum,
        productsList,
        cname: []
      };
    }
    case OUTFLOW_ADD_DATE: {
      return {
        ...state,
        fromDate: moment(action.fromDate).format("MM/DD/YYYY"),
        toDate: moment(action.toDate).format("MM/DD/YYYY"),
        dateChanged: true
      };
    }

    case CLUSTER_DATA: {
      const customerClusterData = getCustomerClusterNames(action.data);
      const vendorClusterData = getVendorClusterNames(action.data);
      const customerclusterNames = customerClusterNames(action.data);
      const vendorclusterNames = vendorClusterNames(action.data);
      const customersIdsInCluster = extractCustomerIdsFromCluster(action.data);
      return {
        ...state,
        customerClusterData,
        vendorClusterData,
        customerclusterNames,
        vendorclusterNames,
        customersIdsInCluster
      };
    }
    case CUSTOMERDATA_FROM_ID: {
      return {
        ...state,
        customerDataFromId: action.data
      };
    }
    case OUTFLOW_DISPLAY_DATES: {
      return {
        ...state,
        dates: action.dates
      };
    }
    case FILTERLIST_DATA: {
      return {
        ...state,
        ldata: action.ldata,
        productList
      };
    }
    case OUTFLOW_DATA_POINT: {
      return {
        ...state,
        point: action.point,
        dateChanged: true
      };
    }
    case OUTFLOW_SERIES: {
      return {
        ...state,
        series: action.series
      };
    }
    case OUTFLOW_FILTER_DATE: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        action.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        action.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const productsList = getNames(state.cleanData, state.cname);
      return {
        ...state,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        sum,
        fullDates,
        productsList,
        datefilter: action.datefilter
      };
    }

    case OUTFLOW_APPLY_DATES: {
      return {
        ...state,
        dateChanged: false
      };
    }

    case OUTFLOW_MONTH_FILTER: {
      return {
        ...state,
        dates: action.dates
      };
    }
    case OUTFLOW_ADD_AMOUNT: {
      return {
        ...state,
        sum: action.sum
      };
    }
    case OUTFLOW_TOP_COLLECTION: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        action.collectionFilter,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        action.collectionFilter,
        state.cname
      );
      return {
        ...state,
        collectionFilter: action.collectionFilter,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        sum,
        fullDates
      };
    }
    case OUTFLOW_SET_FILTER: {
      
      return {
        ...state,
        options: action.options
      };
    }

    case OUTFLOW_CUSTOMER_FILTER: {
      const cleanData = extractData(state.data, action.cname);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const productsList = getNames(cleanData, action.cname);
      return {
        ...state,
        cname: action.cname,
        cleanData,
        productsList,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        sum,
        fullDates
      };
    }

    case OUTFLOW_ENTER_AMOUNT: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        action.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        state.datefilter,
        state.options,
        action.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      return {
        ...state,
        amount: action.amount,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        fullDates,
        sum
      };
    }
    case VENDOR_LIST: {
      const vendorlist = getVendorNames(action.data);
      return {
        ...state,
        vendorlist
      };
    }
    case OUTFLOW_RANGE: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        action.balOne,
        action.balTwo,
        state.collections,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        state.datefilter,
        state.options,
        state.amount,
        action.balOne,
        action.balTwo,
        state.collections,
        state.cname
      );
      return {
        ...state,
        balOne: action.balOne,
        balTwo: action.balTwo,
        series:series[0],
        otherCollections:series[1],
        groupedData:series[2],
        dates: categories,
        fullDates,
        sum
      };
    }
    // case "OUTFLOW_IS_DROPPED": {
    //   return {
    //     ...state
    //   };
    // }
    default:
      return state;
  }
};

export default DateStore;
