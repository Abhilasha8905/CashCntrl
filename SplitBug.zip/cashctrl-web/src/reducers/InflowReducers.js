import moment from "moment";
import {
  fetchCategories,
  seriesFun,
  getNames,
  extractData,
  getCustomerClusterNames,
  getVendorClusterNames,
  getCustomerNames,
  customerClusterNames,
  vendorClusterNames,
  extractCustomerIdsFromCluster,
  getCClusterNames,
  getVClusterNames,
  horizontalSum,
  extractDataForCluster
} from "../utility/newutil";
import { FROM_DATE, TO_DATE } from "../constants";

import {
  CLUSTER_DATA,
  INFLOW_DATA,
  INFLOW_ADD_DATE,
  INFLOW_DISPLAY_DATES,
  INFLOW_SERIES,
  INFLOW_APPLY_DATES,
  INFLOW_FILTER_DATE,
  INFLOW_MONTH_FILTER,
  INFLOW_DATA_POINT,
  INFLOW_ADD_AMOUNT,
  INFLOW_TOP_COLLECTION,
  INFLOW_CUSTOMER_FILTER,
  INFLOW_CLUSTER_FILTER,
  INFLOW_SET_FILTER,
  INFLOW_ENTER_AMOUNT,
  INFLOW_RANGE,
  FILTERLIST_DATA,
  CUSTOMER_LIST,
  CLUSTER_CUSTOMERS,
  CREATE_NEW_CLUSTER,
  DATA_FOR_CLUSTER_VIEW,
  CUSTOMERDATA_FROM_ID,
  INFLOW_UPDATE,
  CLEAR_CUSTOMERS,
  ADD_EXISTING_IDS,
  REMOVE_EXISTING_IDS
} from "../actions/InflowActionTypes";

const initialState = {
  data: [],
  initialData: [],
  fromDate: moment(FROM_DATE),
  toDate: moment(TO_DATE),
  dates: "",
  series: "",
  dateChanged: false,
  datefilter: "Day",
  sum: 0,
  collectionFilter: "",
  options: "",
  amount: 0,
  balOne: 0,
  balTwo: 0,
  cname: [],
  point: "",
  ccustomers: [],
  productsList: [],
  initialList: [],
  cleanData: [],
  fullDates: [],
  customerClusterData: [],
  otherCollections: [],
  vendorClusterData: [],
  customerlist: [],
  customerIds: [],
  vendorlist: [],
  customer: "",
  customerclusterNames: [],
  vendorclusterNames: [],
  customersIdsInCluster: [],
  dataForCluster: [],
  customerDataFromId: {},
  customersIdsInCluster: [],
  dataForCluster: [],
  groupedData: {}
};

const DateStore = (state = initialState, action) => {
  switch (action.type) {
    case INFLOW_DATA: {
      const cleanData = extractData(action.data, []);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        "",
        0,
        0,
        0,
        "",
        []
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];
      const initialList = getNames(cleanData, []);
      const series = seriesFun(cleanData, state.datefilter, "", 0, 0, 0, "", []);
      const productsList = getNames(cleanData, []);
      return {
        ...state,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum,
        data: action.data,
        cleanData,
        initialData: cleanData,
        initialList,
        productsList
      };
    }
    case INFLOW_UPDATE: {
      const cleanData = state.initialData;
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        []
      );
      const categories = data[0];
      const sum = data[1];
      // const initialList = getNames(state.cleanData, []);
      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        []
      );
      const productsList = getNames(cleanData, []);
      return {
        ...state,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        cleanData,
        sum,
        productsList,
        cname: []
      };
    }
    case CLUSTER_DATA: {
      const customerClusterData = getCustomerClusterNames(action.data);
      const vendorClusterData = getVendorClusterNames(action.data);
      const customerclusterNames = customerClusterNames(action.data);

      const vendorclusterNames = vendorClusterNames(action.data);
      const customersIdsInCluster = extractCustomerIdsFromCluster(action.data);

      return {
        ...state,
        customerClusterData,
        vendorClusterData,
        customerclusterNames,
        vendorclusterNames,
        customersIdsInCluster
      };
    }
    case DATA_FOR_CLUSTER_VIEW: {
      const dataForCluster = extractDataForCluster(state.data, state.customersIdsInCluster);

      const cleanData = extractData(dataForCluster, state.cname);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const productsList = getNames(cleanData, state.cname);
      return {
        ...state,
        dataForCluster,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum,
        cleanData,
        productsList
      };
    }
    case CUSTOMER_LIST: {
      const customerlist = getCustomerNames(action.data);
      return {
        ...state,
        customerlist
      };
    }

    case CLUSTER_CUSTOMERS: {
      const { id } = action.customer;
      return {
        ...state,
        customer: action.customer,
        customerIds: [...state.customerIds, { id }]
      };
    }

    case ADD_EXISTING_IDS: {
      return {
        ...state,
        customerIds: [...state.customerIds, ...action.ids]
      };
    }

    case REMOVE_EXISTING_IDS: {
      return {
        ...state,
        customerIds: action.customerIds,
        customer: action.customer,
      };
    }

    case CLEAR_CUSTOMERS: {
      return {
        ...state,
        customer: "",
        customerIds: []
      };
    }

    case CREATE_NEW_CLUSTER: {
      return {
        ...state
      };
    }
    case INFLOW_ADD_DATE: {
      return {
        ...state,
        fromDate: moment(action.fromDate).format("MM/DD/YYYY"),
        toDate: moment(action.toDate).format("MM/DD/YYYY"),
        dateChanged: true
      };
    }
    case INFLOW_DISPLAY_DATES: {
      fetchCategories();
      return {
        ...state,
        dates: action.dates
      };
    }
    case FILTERLIST_DATA: {
      return {
        ...state,
        ldata: action.ldata,
        productList
      };
    }

    case INFLOW_DATA_POINT: {
      return {
        ...state,
        point: action.point,
        dateChanged: true
      };
    }
    case CUSTOMERDATA_FROM_ID: {
      return {
        ...state,
        customerDataFromId: action.data
      };
    }
    case INFLOW_SERIES: {
      return {
        ...state,
        series: action.series
      };
    }
    case INFLOW_APPLY_DATES: {
      return {
        ...state,
        dateChanged: false
      };
    }
    case INFLOW_FILTER_DATE: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        action.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        action.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        state.cname
      );
      const productsList = getNames(state.cleanData, state.cname);
      return {
        ...state,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum,

        productsList,
        datefilter: action.datefilter
      };
    }

    case INFLOW_MONTH_FILTER: {
      return {
        ...state,
        dates: action.dates
      };
    }
    case INFLOW_ADD_AMOUNT: {
      return {
        ...state,
        sum: action.sum
      };
    }
    case INFLOW_TOP_COLLECTION: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        action.collectionFilter,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        action.collectionFilter,
        state.cname
      );
      return {
        ...state,
        collectionFilter: action.collectionFilter,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum
      };
    }

    case INFLOW_SET_FILTER: {
      return {
        ...state,
        options: action.options
      };
    }

    case INFLOW_CUSTOMER_FILTER: {
      const cleanData = extractData(state.data, action.cname);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const productsList = getNames(
        cleanData,
        action.clusterName ? action.clusterName : action.cname
      );
      return {
        ...state,
        cname: action.cname,
        cleanData,
        productsList,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum
      };
    }
    case INFLOW_CLUSTER_FILTER: {
      const cleanData = extractData(state.data, action.ccustomers);
      const data = fetchCategories(
        cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        cleanData,
        state.datefilter,
        state.options,
        state.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const productsList = getNames(cleanData, action.ccustomers);
      return {
        ...state,
        cname: action.cname,
        cleanData,
        productsList,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum
      };
    }
    case INFLOW_ENTER_AMOUNT: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        action.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        state.datefilter,
        state.options,
        action.amount,
        state.balone,
        state.baltwo,
        state.collections,
        action.cname
      );
      return {
        ...state,
        amount: action.amount,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum
      };
    }
    case INFLOW_RANGE: {
      const data = fetchCategories(
        state.cleanData,
        state.fromDate,
        state.toDate,
        state.datefilter,
        state.options,
        state.amount,
        action.balOne,
        action.balTwo,
        state.collections,
        state.cname
      );
      const categories = data[0][0];
      const fullDates = data[0][1];
      const sum = data[1];

      const series = seriesFun(
        state.cleanData,
        state.datefilter,
        state.options,
        state.amount,
        action.balOne,
        action.balTwo,
        state.collections,
        state.cname
      );
      return {
        ...state,
        balOne: action.balOne,
        balTwo: action.balTwo,
        series: series[0],
        otherCollections: series[1],
        groupedData: series[2],
        dates: categories,
        fullDates,
        sum
      };
    }

    default:
      return state;
  }
};

export default DateStore;
