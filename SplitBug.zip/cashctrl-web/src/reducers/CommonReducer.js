import moment from "moment";
import { InFlowData } from "../utility/dasboardUtils";

import { FROM_DATE, TO_DATE } from "../constants";

import { SCENARIO_NAMES, SELECTED_SCENARIO } from "../actions/CommonActionTypes";

const initialState = {
  scenarioNames: [],
  currentScenario: "Default",
  currentScenaruiId: "1",
  defaultDate: moment(new Date())
};

const CommonStore = (state = initialState, action) => {
  switch (action.type) {
    case SELECTED_SCENARIO: {
      const currentScenario = action.Scenario;
      const currentScenaruiId = action.ScenaruiId;

      return {
        ...state,
        currentScenario,
        currentScenaruiId,
        selectedScenario: true
      };
    }

    default:
      return state;
  }
};

export default CommonStore;
