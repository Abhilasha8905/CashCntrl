import moment from "moment";
import get from "lodash/get";
import includes from "lodash/includes";

const userLogin = (state = {}, action) => {
  switch (action.type) {
    case "FETCH_USER_START": {
      return {
        ...state,
        user: "loading",
        userInfo: {
          id: null
        },
        tokan: {
          accessToken: null
        }
      };
      // const groups = state;
      // let { groups: newGroups = [] } = action.payload;
      // newGroups = newGroups.map(function(group) {
      //   return {
      //     id: group.id,
      //     title: group.name,
      //     thumbNailURL: group.resource && group.resource.uri,
      //     membersCount: group.membersCount,
      //     assignmentsCount: group.totalAssignmentsCount,
      //     isCoTeacher: group.isCoTeacher,
      //     isGroupOwner: group.isGroupOwner,
      //     handle: group.handle
      //   };
      // });
      // return Array.isArray(groups) ? groups.concat(newGroups) : newGroups;
    }
    case "FETCH_USER_SUCCESS": {
      const { data } = action.payload;
      const { userName, userId, userEmail, tokenPair, scenarioList, organisation } = data;
      const userInfo = {
        name: userName,
        id: userId,
        email: userEmail
      };
      const { accessToken, refreshToken } = tokenPair;
      const tokan = {
        accessToken,
        refreshToken
      };

      return {
        userInfo,
        organisation,
        scenarioList,
        tokan,
        user: "loaded"
      };
    }
    case "FETCH_USER_ERROR": {
      return {
        ...state,
        user: "error"
      };
    }

    case "REGISTER_USER_START": {
      return {
        ...state,
        registerMsg: false,
        registerUserStatus: "start"
      };
    }

    case "REGISTER_USER_SUCCESS": {
      const { data } = action.payload;
      const { alreadyExisting, successfullyRegistered } = data;
      const newState = { ...state };
      const registeredUserList = get(newState,"registeredUserList", []);
      const registerMsg = successfullyRegistered.length > 0 ? "User successfully Registered": "Email Already Exist";


      const finalAttemptedTestID = includes(registeredUserList, successfullyRegistered[0] || alreadyExisting[0])
        ? registeredUserList
        : registeredUserList && successfullyRegistered[0] && registeredUserList.push(successfullyRegistered[0]);

      return {
        registerMsg,
        registerUserStatus: "done",
        successfullyRegistered,
        alreadyExisting,
        registeredUserList
      };
    }

    case "REGISTER_USER_ERROR": {
      const { response: registerMsg } = action.payload.request;
      console.log(registerMsg);
      return {
        registerMsg,
        registerUserStatus: "error"
      };
    }

    case "GET_REGISTERED_USERS_START": {
      return{
        ...state,
        allUserInfo: "loading",
        registeredUserList: []
      }
    }

    case "GET_REGISTERED_USERS_SUCCESS": {
      console.log("SUCCESSSSSSS!!!!!");
      //const newState = { ...state };
      const {data} = action.payload ;
      console.log(data);
      //const registeredUserList = get(newState,"registeredUserList", []);
      //const finalRegisteredUserList = registeredUserList.length > 0 ? registeredUserList : "";
      //console.log(finalRegisteredUserList);
      return {
        registeredUserList: data,
        allUserInfo: "loaded"                                                                                       
      };
    }

    case "GET_REGISTERED_USERS_ERROR": {
      return {
        allUserInfo: "error",
        registeredUserList: []
      }
    }

    default:
      return state;
  }
};

export default userLogin;
