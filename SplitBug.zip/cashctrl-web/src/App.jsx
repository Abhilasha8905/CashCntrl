import React, { Component } from "react";
import { connect } from "react-redux";
import { Container, Row, Col } from "react-bootstrap";
import styled, { createGlobalStyle } from "styled-components";

import { BrowserRouter as Router, Route, Switch, Redirect, Link } from "react-router-dom";
import DashboardContainer from "./containers/DashboardContainer";
import InflowContainer from "./containers/InflowContainer";
// import Outflows from "./Outflows/OutflowsScreen";
import OutflowContainer from "./containers/OutflowContainer";
import CustomerVendorview from "./components/dashboardComponents/CustomerVendorView";
import LiquidityContainer from "./containers/LiquidityContainer";
import LoginContainer from "./containers/LoginContainer";
// import SideBar from './Dashboard/sideBar';
import HeaderContainer from "./containers/HeaderContainer";
import Navbar from "./components/dashboardComponents/navbar";
import ActNav from "./components/dashboardComponents/ActiveNavbar";
import Homepage from "./components/registration/Homepage";
import "./global.css";
import SettingContainer from "./containers/SettingContainer";

// import route Components here
const GlobalStyle = createGlobalStyle`
  body,html,section {
    overflow: hidden;
    height:100%;
    font-family: Nunito !important;
  }
  img{
    cursor:pointer;
  }
  .container-fluid,.row, .container{
    height: inherit !important;
  }
  img[disabled]{
    opacity:0.5;
    cursor:default;
  }
`;
const Div = styled.div`
background-color: #ffffff;
border-right: solid 1px #ebebeb;
padding: 0px !important;
max-width: 60px !important;
position: absolute;
height: 100%;
width: 100%;
z-index: 1000;
display: ${props => props.userStatus === "loaded" || props.userLogin  ? "block":"none"}
}
`;

const Image = styled.img.attrs({
  src: props => props.imageURL
})`
  height: 25px;
  width: 25px;
  position: absolute;
  bottom: 20px;
`;

const handleTimeDifference = ({tokanTime})=>{
  const userInfo = JSON.parse(localStorage.getItem("user-info"));

  const currentTime = new Date().getTime();
  const timeDifferenceInMinute = (currentTime - tokanTime)/1000/60 ;
  if(timeDifferenceInMinute <= 30){
    return true
  }else{
    return false;
  }
}

const PrivateRoute = ({ component: Component, path, ...rest }) => {
  //const userLogin = window.localStorage.getItem("user-login");
  const userInfo = localStorage.getItem("user-info") && JSON.parse(localStorage.getItem("user-info"));
  const userLogin = userInfo && userInfo["user-login"] === true && handleTimeDifference(userInfo) ? true: false
  return (
    <Route
      {...rest}
      render={props =>
        userLogin ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: "/login",
              state: {
                prevLocation: path,
                error: "You need to login first!"
              }
            }}
          />
        )
      }
    />
  );
};

class App extends Component {
  render() {
    const {userStatus} = this.props;
    const userInfo = localStorage.getItem("user-info") && JSON.parse(localStorage.getItem("user-info"));
    const userLogin = userInfo && userInfo["user-login"] === true && handleTimeDifference(userInfo) ? true: false

    return (
      <React.Fragment>
        <GlobalStyle />
        <Router>
          <Route path="/login" exact component={LoginContainer} />
          <Container fluid style={{ backgroundColor: "#f8f9fb" }}>
            <Row>
              <Div userStatus={userStatus} userLogin={userLogin}>
              <Link to="/setting">
              <Image  imageURL={require("./images/dashboard/settings.svg")} />
              </Link>
              </Div>
              <Col lg={12} md={12} xs={12} className="dashBoard">
                <Row >
                  <Col lg={12} md={12} xs={12} style={{ boxShadow: "none" }}>
                    <HeaderContainer />
                  </Col>
                </Row>
                <Row style={{marginBottom:"20px"}}>
                  <Col lg={12} md={12} xs={12} style={{ boxShadow: "none" }}>
                    <Navbar />
                    {/* <ActNav /> */}
                  </Col>
                </Row>

                <Switch>
                  <PrivateRoute path="/" exact component={DashboardContainer} />
                  <PrivateRoute path="/dashboard" exact component={DashboardContainer} />
                  <PrivateRoute path="/inflows" exact component={InflowContainer} />
                  <PrivateRoute path="/outflows" exact component={OutflowContainer} />
                  <PrivateRoute path="/clusterview" exact component={CustomerVendorview} />
                  <PrivateRoute path="/liquidity" exact component={LiquidityContainer} />
                  <PrivateRoute path="/setting" exact component={SettingContainer} />

                </Switch>
              </Col>
            </Row>
          </Container>
        </Router>
      </React.Fragment>
    );
  }
}
const mapStateToProps = state => ({
  userStatus: state.login.user
});

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    //loginUser: data => dispatch(loginUser(data))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
//export default App;
