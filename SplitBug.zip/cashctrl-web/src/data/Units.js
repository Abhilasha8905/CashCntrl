export const Units ={
    Lacs : "lacs"
}