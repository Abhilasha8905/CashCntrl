import moment from "moment";
import API_SERVICE from "../services";
import {
  DASHBOARD_DATA,
  DASHBOARD_FAILURE,
  DASHBOARD_ADD_DATE,
  DASHBOARD_DISPLAY_DATES,
  DASHBOARD_APPLY_DATES,
  DASHBOARD_FILTER_DATE,
  DASHBOARD_MONTH_FILTER,
  DASHBOARD_DATA_POINT,
  DASHBOARD_ADD_AMOUNT,
  DASHBOARD_SET_FILTER,
  DASHBOARD_CARDS_DATA,
  DASHBOARD_CARDS_FAILURE,
  DASHBOARD_PDC_CLEAR_DATA,
  DASHBOARD_BANK_BALANCE,
  DASHBOARD_CNCI,
  DASHBOARD_CNCR,
  REMINDER_DATA
} from "./DashboardActionTypes";
// import { DATE } from "../constants";
const DATE = "07/02/2019";

const api = new API_SERVICE();

export const addPDCOrClearIssue = dashboardType => {
  return dispatch => {
    let date = new Date();
    date = moment(date).format("DD/MM/YYYY");
    const queryParams = {
      date: DATE,
      dashboardType
    };
    api
      .getPDCOrClearDataDashboard(queryParams)
      .then(res => {
        dispatch(dashboardPDCOrClearData(res.data, dashboardType));
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const addCNCIorCNCR = dashboardType => {
  return dispatch => {
    let date = new Date();
    date = moment(date).format("DD/MM/YYYY");
    const queryParams = {
      date: DATE,
      dashboardType
    };
    api
      .getPDCOrClearDataDashboard(queryParams)
      .then(res => {
        if (dashboardType === "CNCI") {
          dispatch(dashboardCNCI(res.data, dashboardType));
        } else {
          dispatch(dashboardCNCR(res.data, dashboardType));
        }
      })
      .catch(err => {
        console.log(err);
      });
  };
};
export const getReminderData = () => {
  return (dispatch, getState) => {
    const scenarioId = getState().common.currentScenaruiId;
    const date = "25/09/2019";
    const payload = `scenarioId=${scenarioId}&date=${date}`;
    api
      .getReminderData(payload)
      .then(res => {
        dispatch(reminderData(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const reminderData = data => {
  return {
    type: REMINDER_DATA,
    data
  };
};
export const addCardsData = () => {
  return dispatch => {
    let date = new Date();
    date = moment(date).format("DD/MM/YYYY");
    const queryParams = {
      date: DATE
    };
    api
      .getCardsDataDasboard(queryParams)
      .then(res => {
        dispatch(dashboardCardsData(res.data));
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const dashboardPDCOrClearData = (PDCOrClearData, dashboardType) => {
  return {
    type: DASHBOARD_PDC_CLEAR_DATA,
    PDCOrClearData,
    dashboardType
  };
};

export const dashboardCNCI = (PDCOrClearData, dashboardType) => {
  return {
    type: DASHBOARD_CNCI,
    PDCOrClearData,
    total: PDCOrClearData.reduce((a, b) => ({ amount: a.amount + b.amount })),
    dashboardType
  };
};

export const dashboardCNCR = (PDCOrClearData, dashboardType) => {
  return {
    type: DASHBOARD_CNCR,
    PDCOrClearData,
    total: PDCOrClearData.reduce((a, b) => ({ amount: a.amount + b.amount })),
    dashboardType
  };
};
// bankBal;

export const bankBal = bankBalance => {
  return {
    type: DASHBOARD_BANK_BALANCE,
    bankBalance
  };
};

export const dashboardCardsData = data => {
  return {
    type: DASHBOARD_CARDS_DATA,
    data
  };
};

export const addDateDashboard = (from, to) => {
  return (dispatch, getState) => {
    dispatch(addDate(from, to));
    const fromDate = moment(from).format("DD/MM/YYYY");
    const toDate = moment(to).format("DD/MM/YYYY");
    const queryParams = {
      fromDate,
      toDate,
      scenarioId: getState().liquidity.currentScenaruiId
    };
    api
      .getDasboardData(queryParams)
      .then(res => {
        dispatch(dashboardData(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};

export const dashboardData = data => {
  return {
    type: DASHBOARD_DATA,
    data
  };
};

export const addCardFailure = error => {
  return {
    type: DASHBOARD_CARDS_FAILURE,
    error
  };
};

export const addTodoFailure = error => {
  return {
    type: DASHBOARD_FAILURE,
    error
  };
};

export const addDate = (fromDate, toDate) => {
  return {
    type: DASHBOARD_ADD_DATE,
    fromDate,
    toDate
  };
};
export const dateValuesDashboard = dates => {
  return {
    type: DASHBOARD_DISPLAY_DATES,
    dates
  };
};

export const applyDatePicker = () => {
  return {
    type: DASHBOARD_APPLY_DATES
  };
};
export const onButtonSelectDashboard = datefilter => {
  return {
    type: DASHBOARD_FILTER_DATE,
    datefilter
  };
};
export const monthFilterDashboard = dates => {
  return {
    type: DASHBOARD_MONTH_FILTER,
    dates
  };
};
export const dataPointDashboard = point => {
  return {
    type: DASHBOARD_DATA_POINT,
    point
  };
};
export const sumOfAmountDashboard = sum => {
  return {
    type: DASHBOARD_ADD_AMOUNT,
    sum
  };
};

export const setFilterOptionsDasboard = options => {
  return {
    type: DASHBOARD_SET_FILTER,
    options
  };
};
