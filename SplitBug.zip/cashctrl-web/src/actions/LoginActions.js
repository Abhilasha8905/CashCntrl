import moment from "moment";
import API_SERVICE from "../services";

const api = new API_SERVICE();

export const fetchUserStart = () => {
  return {
    type: "FETCH_USER_START"
  };
};

export const fetchUserSuccess = data => {
  console.log(data);
  return {
    type: "FETCH_USER_SUCCESS",
    payload: data
  };
};

export const fetchUserError = data => {
  return {
    type: "FETCH_USER_ERROR",
    payload: data
  };
};

export const registerUserStart = () => {
  return {
    type: "REGISTER_USER_START"
  };
};

export const registerUserSuccess = data => {
  console.log(data);
  return {
    type: "REGISTER_USER_SUCCESS",
    payload: data
  };
};

export const registerUserError = data => {
  return {
    type: "REGISTER_USER_ERROR",
    payload: data
  };
};

export const getAllRegisteredUsersStart = () => {
  return {
    type: "GET_REGISTERED_USERS_START"
  };
};

export const getAllRegisteredUsersSuccess = data => {
  console.log(data);
  return {
    type: "GET_REGISTERED_USERS_SUCCESS",
    payload: data
  };
};

export const getAllRegisteredUsersError = data => {
  return {
    type: "GET_REGISTERED_USERS_ERROR",
    payload: data
  };
};

export const loginUser = data => {
  return dispatch => {
    dispatch(fetchUserStart());
    api
      .loginUser(data)
      .then(res => {
        dispatch(fetchUserSuccess(res));
      })
      .catch(err => {
        // console.log(err);
        dispatch(fetchUserError(err));
      });
  };
};

export const resetRegisterUser = () => {
  return dispatch => {
    dispatch(registerUserStart());
  };
};

export const registerUser = data => {
  return dispatch => {
    dispatch(registerUserStart());
    api
      .registerUser(data)
      .then(res => {
        dispatch(registerUserSuccess(res));
      })
      .catch(err => {
        console.log(err);
        dispatch(registerUserError(err));
      });
  };
};

export const getAllRegisteredUsers = () => {
  return dispatch => {
    dispatch(getAllRegisteredUsersStart());
    api
      .getAllRegisteredUsers()
      .then(res => {
        dispatch(getAllRegisteredUsersSuccess(res));
      })
      .catch(err => {
        console.log(err);
        dispatch(getAllRegisteredUsersError(err));
      });
  };
};