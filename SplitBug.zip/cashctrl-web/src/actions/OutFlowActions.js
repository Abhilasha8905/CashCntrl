import moment from "moment";

import { extractData } from "../utility/newOutflow";
import API_SERVICE from "../services";
import {
  OUTFLOW_DATA,
  OUTFLOW_ADD_DATE,
  OUTFLOW_DISPLAY_DATES,
  OUTFLOW_SERIES,
  OUTFLOW_APPLY_DATES,
  OUTFLOW_FILTER_DATE,
  OUTFLOW_MONTH_FILTER,
  OUTFLOW_DATA_POINT,
  OUTFLOW_ADD_AMOUNT,
  OUTFLOW_TOP_COLLECTION,
  OUTFLOW_CUSTOMER_FILTER,
  OUTFLOW_SET_FILTER,
  OUTFLOW_ENTER_AMOUNT,
  OUTFLOW_RANGE,
  FILTERLIST_DATA,
  VENDOR_LIST,
  CUSTOMERDATA_FROM_ID,
  DATA_FOR_CLUSTER_VIEW,
  OUTFLOW_UPDATE,
  CLUSTER_DATA
} from "./OutflowActionTypes";

export const addDateOutflow = (from, to, id) => {
  return (dispatch, getState) => {
    dispatch(addDate(from, to));
    const fromDate = moment(from).format("YYYY-MM-DD");
    const toDate = moment(to).format("YYYY-MM-DD");
    const ids = id || 1;
    const postData = {
      ledgerType: "OUTFLOW",
      startDate: fromDate,
      currentDate: "2019-09-26",
      endDate: toDate,
      scenario: {
        id: getState().liquidity.currentScenaruiId
      }
    };
    const api = new API_SERVICE();
    api
      .postInflowData(postData)
      .then(res => {
        dispatch(outflowData(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};

export const addOutflowType = (from, to, type) => {
  return (dispatch, getState) => {
    dispatch(addDate(from, to));
    const fromDate = moment(from).format("YYYY-MM-DD");
    const toDate = moment(to).format("YYYY-MM-DD");
    const postData = {
      ledgerType: "OUTFLOW",
      startDate: fromDate,
      endDate: toDate,
      currentDate: moment(getState().common.defaultDate).format("YYYY-MM-DD"),
      scenario: {
        id: 1
      },
      ledgerFilters: type === "Cheques issued" ? ["CHEQUES_ISSUED"] : ["PDC_ISSUED"]
    };
    const api = new API_SERVICE();
    api
      .postInflowData(postData)
      .then(res => {
        dispatch(outflowData(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};

export const getVendorsList = () => {
  return dispatch => {
    const api = new API_SERVICE();
    api
      .getVendorsListData()
      .then(res => {
        dispatch(clusterVendordata(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};

export const clusterVendordata = data => {
  return {
    type: VENDOR_LIST,
    data
  };
};
export const outflowData = data => {
  return {
    type: OUTFLOW_DATA,
    data
  };
};

export const outflowUpdate = () => {
  return {
    type: OUTFLOW_UPDATE
  };
};

export const firstDataOutflow = data => {
  return {
    type: "FIRST_CHANGE",
    data
  };
};
export const addTodoFailure = error => {
  return {
    type: OUTFLOW_FAILURE,
    error
  };
};

export const addDate = (fromDate, toDate) => {
  return {
    type: OUTFLOW_ADD_DATE,
    fromDate,
    toDate
  };
};
export const getCustomerDetailsonId = (id, from, to) => {
  return (dispatch, getState) => {
    const postData = {
      ledgerType: "OUTFLOW",
      startDate: moment(from).format("YYYY-MM-DD"),
      endDate: moment(to).format("YYYY-MM-DD"),
      currentDate: moment(getState().common.defaultDate).format("YYYY-MM-DD"),
      scenario: {
        id: 1
      }
    };
    const api = new API_SERVICE();
    api
      .postCustomerDetailsOnId(postData, id)
      .then(res => {
        dispatch(customerDataOnId(res.data));
      })
      .catch(err => {
        // dispatch(addTodoFailure(err.message));
        console.log(err);
      });
  };
};
export const customerDataOnId = data => {
  return {
    type: CUSTOMERDATA_FROM_ID,
    data
  };
};

export const dateValuesOutflow = dates => {
  return {
    type: OUTFLOW_DISPLAY_DATES,
    dates
  };
};
export const seriesDataOutflow = series => {
  return {
    type: OUTFLOW_SERIES,
    series
  };
};

export const applyDatesOutflow = () => {
  return {
    type: OUTFLOW_APPLY_DATES
  };
};
export const onButtonSelectOutflow = datefilter => {
  return {
    type: OUTFLOW_FILTER_DATE,
    datefilter
  };
};
export const monthFilterOutflow = dates => {
  return {
    type: OUTFLOW_MONTH_FILTER,
    dates
  };
};
export const dataPointOutflow = point => {
  return {
    type: OUTFLOW_DATA_POINT,
    point
  };
};
export const sumOfAmountOutflow = sum => {
  return {
    type: OUTFLOW_ADD_AMOUNT,
    sum
  };
};
export const collectionsOutflow = collectionFilter => {
  return {
    type: OUTFLOW_TOP_COLLECTION,
    collectionFilter
  };
};
export const customerFilterOutflow = cname => {
  return {
    type: OUTFLOW_CUSTOMER_FILTER,
    cname
  };
};
export const setFilterOptionsOutflow = options => {
  return {
    type: OUTFLOW_SET_FILTER,
    options
  };
};
export const enteredAmountOutflow = amount => {
  return {
    type: OUTFLOW_ENTER_AMOUNT,
    amount
  };
};
export const rangeOutflow = (balOne, balTwo) => {
  return {
    type: OUTFLOW_RANGE,
    balOne,
    balTwo
  };
};
export const filterList = ldata => {
  return {
    type: FILTERLIST_DATA,
    ldata
  };
};
export const getClusterData = () => {
  return {
    type: DATA_FOR_CLUSTER_VIEW
  };
};

export const getNames = (datas, fromDate, toDate, cname = []) => {
  const names = [];

  const data = extractData(datas, fromDate, toDate, cname);
  for (let i = 0; i < data.length; i++) {
    const obj = data[i];

    if (!names.includes(obj.name)) {
      names.push(obj.name);
    }
  }
  const list = [];
  names.map(n => {
    return list.push({
      name: n,
      isAdded: false
    });
  });
  return list;
};

export const clusterData = () => {
  return dispatch => {
    const api = new API_SERVICE();
    api
      .getClusterData()
      .then(res => {
        dispatch(clusterFilterdata(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};

export const clusterFilterdata = data => {
  return {
    type: CLUSTER_DATA,
    data
  };
};
