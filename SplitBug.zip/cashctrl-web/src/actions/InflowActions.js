import moment from "moment";
import { extractData } from "../utility/newutil";
import API_SERVICE from "../services";
import { addDateOutflow } from "./OutFlowActions";
import {
  CLUSTER_DATA,
  INFLOW_DATA,
  INFLOW_FAILURE,
  INFLOW_ADD_DATE,
  INFLOW_DISPLAY_DATES,
  INFLOW_SERIES,
  INFLOW_APPLY_DATES,
  INFLOW_FILTER_DATE,
  INFLOW_MONTH_FILTER,
  INFLOW_DATA_POINT,
  INFLOW_ADD_AMOUNT,
  INFLOW_TOP_COLLECTION,
  INFLOW_CUSTOMER_FILTER,
  CLUSTER_FILTER,
  INFLOW_SET_FILTER,
  INFLOW_ENTER_AMOUNT,
  INFLOW_RANGE,
  FILTERLIST_DATA,
  CUSTOMER_LIST,
  CLUSTER_CUSTOMERS,
  CREATE_NEW_CLUSTER,
  DATA_FOR_CLUSTER_VIEW,
  CUSTOMERDATA_FROM_ID,
  INFLOW_UPDATE,
  REMOVE_EXISTING_IDS
} from "./InflowActionTypes";

export const addDateInflow = (from, to, id) => {
  return (dispatch, getState) => {
    dispatch(addDate(from, to));
    const fromDate = moment(from).format("YYYY-MM-DD");
    const toDate = moment(to).format("YYYY-MM-DD");
    const ids = id || 1;
    const postData = {
      ledgerType: "INFLOW",
      startDate: fromDate,
      currentDate: "2019-09-26",
      endDate: toDate,

      scenario: {
        id: getState().liquidity.currentScenaruiId
      }
    };
    const api = new API_SERVICE();
    api
      .postInflowData(postData)
      .then(res => {
        dispatch(inflowData(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const clusterData = () => {
  return dispatch => {
    const api = new API_SERVICE();
    api
      .getClusterData()
      .then(res => {
        dispatch(clusterFilterdata(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const getCustomersList = () => {
  return dispatch => {
    const api = new API_SERVICE();
    api
      .getCustomerListData()
      .then(res => {
        dispatch(clusterCustomerData(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const createNewVendorCluster = (customerids, name) => {
  const postData = {
    name,
    type: "VENDOR",
    vendors: customerids
  };

  return dispatch => {
    const api = new API_SERVICE();
    api
      .postClusterData(postData)
      .then(res => {
        dispatch(clusterData());
        // dispatch(clusterFilterdata(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const createNewCustomerCluster = (customerids, name) => {
  const postData = {
    name,
    type: "CUSTOMER",
    customers: customerids
  };

  return dispatch => {
    const api = new API_SERVICE();
    api
      .postClusterData(postData)
      .then(res => {
        dispatch(clusterData());
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const editCustomerCluster = (clusterId, name, customerids) => {
  const postData = {
    id: clusterId,
    name,
    type: "CUSTOMER",
    customers: customerids
  };

  return dispatch => {
    const api = new API_SERVICE();
    api
      .putEditClusterData(postData)
      .then(res => {
        dispatch(clusterData());
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const editVendorCluster = (clusterId, name, customerids) => {
  const postData = {
    id: clusterId,
    name,
    type: "VENDOR",
    vendors: customerids
  };
  console.log(postData, "////////////////");
  return dispatch => {
    const api = new API_SERVICE();
    api
      .putEditClusterData(postData)
      .then(res => {
        dispatch(clusterData());
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};
export const clusterCustomerData = data => {
  return {
    type: CUSTOMER_LIST,
    data
  };
};

export const customerListInflow = customer => {
  return (dispatch, getState) => {
    if (
      (getState().inflow.customerIds,
      customer.id,
      getState().inflow.customerIds.some(a => a.id === customer.id))
    ) {
      const newCustomer = getState().inflow.customerIds.filter(i => i.id !== customer.id);
      dispatch({
        type: REMOVE_EXISTING_IDS,
        customerIds: newCustomer,
        customer: { ...customer, isAdded: false }
      });
    } else {
      dispatch(addClusterId(customer));
    }
  };
};

export const addClusterId = customer => {
  return {
    type: CLUSTER_CUSTOMERS,

    customer
  };
};

export const clusterFilterdata = data => {
  return {
    type: CLUSTER_DATA,
    data
  };
};

export const inflowUpdate = () => {
  return {
    type: INFLOW_UPDATE
  };
};

export const inflowData = data => {
  return {
    type: INFLOW_DATA,
    data
  };
};
export const getClusterData = () => {
  return {
    type: DATA_FOR_CLUSTER_VIEW
  };
};
export const firstDataInflow = data => {
  return {
    type: "FIRST_CHANGE",
    data
  };
};

export const addTodoFailure = error => {
  return {
    type: INFLOW_FAILURE,
    error
  };
};

export const addDate = (fromDate, toDate) => {
  return {
    type: INFLOW_ADD_DATE,
    fromDate,
    toDate
  };
};
export const dateValuesInflow = dates => {
  return {
    type: INFLOW_DISPLAY_DATES,
    dates
  };
};
export const seriesDataInflow = series => {
  return {
    type: INFLOW_SERIES,
    series
  };
};

export const applyDatesInflow = () => {
  return {
    type: INFLOW_APPLY_DATES
  };
};
export const onButtonSelectInflow = datefilter => {
  return {
    type: INFLOW_FILTER_DATE,
    datefilter
  };
};
export const monthFilterInflow = dates => {
  return {
    type: INFLOW_MONTH_FILTER,
    dates
  };
};
export const dataPointInflow = point => {
  return {
    type: INFLOW_DATA_POINT,
    point
  };
};
export const getCustomerDetailsonId = (id, from, to) => {
  return (dispatch, getState) => {
    const postData = {
      ledgerType: "INFLOW",
      startDate: moment(from).format("YYYY-MM-DD"),
      endDate: moment(to).format("YYYY-MM-DD"),
      // currentDate: moment(getState().common.defaultDate).format("YYYY-MM-DD"),
      scenario: {
        id: 1
      }
    };
    const api = new API_SERVICE();
    api
      .postCustomerDetailsOnId(postData, id)
      .then(res => {
        dispatch(customerDataOnId(res.data));
      })
      .catch(err => {
        // dispatch(addTodoFailure(err.message));
        console.log(err);
      });
  };
};
export const customerDataOnId = data => {
  return {
    type: CUSTOMERDATA_FROM_ID,
    data
  };
};

export const sumOfAmountInflow = sum => {
  return {
    type: INFLOW_ADD_AMOUNT,
    sum
  };
};
export const collectionsInflow = collectionFilter => {
  return {
    type: INFLOW_TOP_COLLECTION,
    collectionFilter
  };
};
export const customerFilterInflow = (cname, clusterName) => {
  return {
    type: INFLOW_CUSTOMER_FILTER,
    cname,
    clusterName
  };
};
export const clusterFilter = ccustomers => {
  return {
    type: INFLOW_CUSTOMER_FILTER,
    ccustomers
  };
};
export const setFilterOptionsInflow = options => {
  return {
    type: INFLOW_SET_FILTER,
    options
  };
};
export const enteredAmountInflow = amount => {
  return {
    type: INFLOW_ENTER_AMOUNT,
    amount
  };
};
export const rangeInflow = (balOne, balTwo) => {
  return {
    type: INFLOW_RANGE,
    balOne,
    balTwo
  };
};
export const filterList = ldata => {
  return {
    type: FILTERLIST_DATA,
    ldata
  };
};
export const getNames = (datas, fromDate, toDate, cname = []) => {
  const names = [];

  const data = extractData(datas, fromDate, toDate, cname);
  for (let i = 0; i < data.length; i++) {
    const obj = data[i];

    if (!names.includes(obj.name)) {
      names.push(obj.name);
    }
  }
  const list = [];
  names.map(n => {
    return list.push({
      name: n,
      isAdded: false
    });
  });
  return list;
};
