import moment from "moment";
import API_SERVICE from "../services";
import { DATE } from "../constants";
import { SELECTED_SCENARIO, SCENARIO_NAMES } from "./CommonActionTypes";

import { addDateInflow } from "./InflowActions";
import { addDateOutflow } from "./OutFlowActions";
import { GetLiquidityData } from "./LiquidityActions";

const api = new API_SERVICE();

export const SenenarioNames = () => {
  return dispatch => {
    api
      .getScenarioData()
      .then(res => {
        dispatch(scenarioNames(res.data));
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const scenarioNames = data => {
  return {
    type: SCENARIO_NAMES,
    data
  };
};

export const SelectedScenario = (Scenario, ScenaruiId) => {
  return {
    type: SELECTED_SCENARIO,
    Scenario,
    ScenaruiId
  };
};
