import moment from "moment";
import API_SERVICE from "../services";
import { DATE, FROM_DATE, TO_DATE } from "../constants";

import { SenenarioNames } from "./CommonActions";
import { addDateInflow } from "./InflowActions";
import { addDateOutflow } from "./OutFlowActions";
import { addDateDashboard, getReminderData } from "./DasboardActions";
import { LiquiditySorted } from "../utility/LiquidityUtil";

import {
  LIQUIDITY_DATA,
  SCENARIO_DATA,
  DELETE_SCENARIO,
  SAVE_SCENARIO,
  UPDATE_SCENARIO,
  CREATE_SCENARIO,
  SORT_DATA
} from "./LiquidityActionTypes";

const api = new API_SERVICE();

export const GetLiquidityData = id => {
  return dispatch => {
    let date = new Date();
    const from = moment(FROM_DATE);
    const to = moment(TO_DATE);

    date = moment(date).format("DD/MM/YYYY");
    console.log(date, "...date");
    const ids = id || 1;
    const queryParams = {
      scenarioId: ids,
      date: DATE
    };

    api
      .getLiquidityData(queryParams)
      .then(res => {
        dispatch(liquidityData(res.data));
        dispatch(addDateInflow(from, to, id));
        dispatch(addDateOutflow(from, to, id));
        dispatch(addDateDashboard(from, to, id));
        dispatch(getReminderData(id, "25/09/2019"));
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const liquidityData = data => {
  return {
    type: LIQUIDITY_DATA,
    data
  };
};

export const GetDefaultScenarioData = id => {
  return dispatch => {
    let date = new Date();
    const from = moment(FROM_DATE);
    const to = moment(TO_DATE);
    date = moment(date).format("DD/MM/YYYY");
    const currentDate = "";
    const ids = id || 1;
    const queryParams = {
      scenarioId: id,
      currentDate: "2019-09-24"
    };
    api
      .getDefaultScenarioData(queryParams)
      .then(res => {
        dispatch(ScenarioData(res.data, currentDate));
        dispatch(addDateInflow(from, to, id));
        dispatch(addDateOutflow(from, to, id));
        dispatch(addDateDashboard(from, to, id));
        dispatch(getReminderData(id, "25/09/2019"));
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const ScenarioData = (scenarioData, date) => {
  return {
    type: SCENARIO_DATA,
    scenarioData,
    date
  };
};

export const DeleteScenario = id => {
  return dispatch => {
    api
      .deleteScenarioSelected(id)
      .then(res => {
        dispatch(deleteScenarioData());
        dispatch(GetLiquidityData(1));
        dispatch(SenenarioNames());
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const deleteScenarioData = () => {
  return {
    type: DELETE_SCENARIO
  };
};
export const saveScenario = param => {
  return dispatch => {
    api
      .saveScenario(param)
      .then(res => {
        dispatch(saveScenarioData(param.scenario.name, res.data, res.data.id));
        dispatch(GetLiquidityData(res.data.id));
        dispatch(SenenarioNames());
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const saveScenarioData = (name, data, id) => {
  return {
    type: SAVE_SCENARIO,
    name,
    data,
    id
  };
};
export const UpdateScenario = param => {
  return dispatch => {
    api
      .updateScenario(param)
      .then(res => {
        dispatch(updateScenarioData());
      })
      .catch(err => {
        console.log(err);
      });
  };
};

export const updateScenarioData = () => {
  return {
    type: UPDATE_SCENARIO
  };
};

export const createScenario = (scenarioName, graphData) => {
  return {
    type: CREATE_SCENARIO,
    scenarioName,
    graphData
  };
};
export const sortData = (method, payments, collections) => {
  const data = LiquiditySorted(method, payments, collections);
  const payment = data.payments;
  const { collection } = data;

  return {
    type: SORT_DATA,
    method,
    payment,
    collection
  };
};
