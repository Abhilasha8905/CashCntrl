import axios from "axios";
import { BASE_URL } from "../constants";

class API_SERVICE {
  constructor() {
    this.axios = axios.create({
      baseURL: BASE_URL,
      headers: {
        "Cache-Control": "no-cache",
        "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,OPTIONS",
        "Access-Control-Allow-Origin": "*",
        Accept: "application/json"
      }
    });
  }

  getInflowData(queryParams) {
    return this.axios.get("/", { params: queryParams });
  }

  postInflowData(payload) {
    return this.axios.post("/ledgers", payload);
  }

  getDasboardData(queryParams) {
    return this.axios.get("/dashboard/graphData", { params: queryParams });
  }
  getReminderData(id,date) {
    return this.axios.get(`/reminders?${id}&date=${date}`)
  }
  getClusterData() {
    return this.axios.get("/clusters");
  }

  postCustomerDetailsOnId(payload, id) {
    return this.axios.post(`/ledgers/${id}`, payload);
  }

  postClusterData(payload) {
    return this.axios.post("/clusters", payload);
  }

  putEditClusterData(payload) {
    return this.axios.put("/clusters", payload);
  }

  getCustomerListData() {
    return this.axios.get("/clusters/customers");
  }

  getVendorsListData() {
    return this.axios.get("/clusters/vendors");
  }

  postDashboardData(payload) {
    return this.axios.post("/dashboard/graphData", payload);
  }

  getCardsDataDasboard(queryParams) {
    return this.axios.get("/dashboard/aggregateData", { params: queryParams });
  }

  getPDCOrClearDataDashboard(queryParams) {
    return this.axios.get("/dashboard/breakupData", { params: queryParams });
  }

  getLiquidityData(queryParams) {
    return this.axios.get("/invoices", { params: queryParams });
  }

  getDefaultScenarioData(queryParams) {
    return this.axios.get("/liquidityPredictor/scenarios", { params: queryParams });
  }

  saveScenario(payload) {
    return this.axios.post("/invoices", payload);
  }

  deleteScenarioSelected(id) {
    const url = `/scenarios/${id}`;

    return this.axios.delete(url);
  }

  updateScenario(payload) {
    return this.axios.put("/invoices", payload);
  }

  getScenarioData() {
    return this.axios.get("/scenarios");
  }

  loginUser(payload) {
    return this.axios.post("/authentication/login", payload);
  }

  registerUser(payload) {
    return this.axios.post("/authentication/register", payload);
  }

  getAllRegisteredUsers(payload) {
    return this.axios.get("/authentication/registeredUsers", payload);
  }
}

export default API_SERVICE;
