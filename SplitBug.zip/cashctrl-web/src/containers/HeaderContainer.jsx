import React, { Component } from "react";
import { Col, Dropdown, Row } from "react-bootstrap";
import styled from "styled-components";
import moment from "moment";

import { connect } from "react-redux";
import TopIcon from "../images/header/TopIcon.png";
import Tricon from "../images/header/Tricon-logo.png";
import calandar from "../images/header/calendar.png";
import Profile from "../images/header/Profile.png";
import DropdownIcon from "../images/header/DropDownIcon.png";
import DropdownComponent from "../components/dashboardComponents/DropdownComponent";
import CustomerClusterButton from "../components/CustomerClusterButton";
import { DATE } from "../constants";
import { SenenarioNames, SelectedScenario } from "../actions/CommonActions";
import { addDateInflow } from "../actions/InflowActions";
import { addDateOutflow } from "../actions/OutFlowActions";
import { GetLiquidityData, GetDefaultScenarioData } from "../actions/LiquidityActions";

const UL = styled.ul`
  list-style-type: none;
  overflow: hidden;
  object-fit: contain;
  margin-bottom: 0.1rem;
  padding:0;
  display:inline-flex;
}
`;

const LI = styled.li`
  display: inline-block;
  line-height: 33px;
  margin: ${props => (props && props.margin ? props.margin : null)};
`;

const DropDownIcon = styled.img.attrs({
  src: DropdownIcon
})`
  width: 8px;
  height: 4.7px;

  margin-right: 30px;
`;

const ProfileIcon = styled.img.attrs({
  src: Profile
})`
  border-width: thin;
  border: 2px solid#C94593;
  border-radius: 50%;
  width: 30px;
  height: 29.5px;
  object-fit: contain;
  vertical-align: middle;

  width: 38px;
  height: 37.5px;
  background-color: var(--darkish-pink);
`;

const WelcomeText = styled.h6`
  font-size: 13px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  text-align: right;
  color: var(--black);
  opacity: 0.6;
  font-family: "Nunito", sans-serif;
  padding: 0px 10px;
  margin-top: 0px;
  margin-bottom: 0px;
`;

const CurrentDate = styled.span`
  width: 93px;
  height: 18px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  margin-left: 5px;
  font-family: "Nunito", sans-serif;
  font-family: "Open Sans", sans-serif;
  opacity: 0.6;
`;

const Calendar = styled.img.attrs({
  src: calandar
})`
  width: 13.7px;
  height: 14px;
  object-fit: contain;
  font-size: 2em;
`;

const CashCntrlIcon = styled.img.attrs({
  src: TopIcon
})`
    width: 117px;
    object-fit: contain;
    margin-left: 8px
    padding:0.5rem;
`;

const TriconIcon = styled.img.attrs({
  src: Tricon
})`
  width: 125px;
  height: 50px;
  object-fit: contain;
  margin-left: 8px;
  padding: 0.5rem;
`;

const TopHeader = styled.div`
  background-color: #ffffff;
  position: relative;
  margin: 0px 0px 5px 0px;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
  maxwidth: 100%;
  display: flex;
  justify-content: space-between;
`;

const FloatRight = styled.div`
  float: right;
`;

const format = "Do MMM YYYY";
const defaultDate = DATE;
class HeaderContainer extends Component {
  constructor() {
    super();
    this.logOut = this.logOut.bind(this);
  }

  SenenarioNames(name, id) {
    this.props.SelectedScenario(name, id);
    this.props.GetLiquidityData(id);
  }

  UpdateScenarioData(id) {
    // this.props.addDateInflow(id);
    // this.props.addDateOutflow(id);
    this.props.GetDefaultScenarioData(id);
  }

  componentWillMount() {
    this.props.SenenarioNames();
  }
  logOut(){
  window.localStorage.setItem("user-info","");
  window.location.reload();
  }

  render() {
    return (
      <TopHeader>
        <div className="align-self-center">
          <CashCntrlIcon />
        </div>
        <div className="align-self-center">
          <DropdownComponent
            SelectedScenario={this.SenenarioNames.bind(this)}
            UpdateScenarioData={this.UpdateScenarioData.bind(this)}
            scenarioNames={this.props.scenarioNames}
            currentScenario={this.props.currentScenario}
            scenarioName={this.props.scenarioName}
            updateDropDown={this.props.updateDropDown}
            savedData={this.props.savedData}
          />
        </div>
        <div className="flex-container">
          <span className="align-self-center">
            <Calendar /> <CurrentDate>{moment(this.props.defaultDate).format(format)}</CurrentDate>
          </span>

          <TriconIcon />

          <WelcomeText className="align-self-center">
            <span>Welcome</span>
            <a onClick={this.logOut} style={{color:"blue",marginLeft:"5px",cursor:"pointer",textDecoration:"underline"}}>Logout</a>
          </WelcomeText>
          <div className="align-self-center">
            <ProfileIcon />
            <DropDownIcon />
          </div>
        </div>
      </TopHeader>
    );
  }
}

const mapStateToProps = state => ({
  scenarioNames: state.liquidity.scenarioNames,
  scenarioName: state.liquidity.scenarioName,
  currentScenario: state.liquidity.currentScenario,
  updateDropDown: state.liquidity.updateDropDown,
  currentScenaruiId: state.liquidity.currentScenaruiId,
  savedData: state.liquidity.savedData,
  defaultDate: state.common.defaultDate
});
const mapDispatchToProps = dispatch => {
  return {
    SelectedScenario: (name, id) => {
      dispatch(SelectedScenario(name, id));
    },
    addDateInflow: id => {
      dispatch(addDateInflow(id));
    },
    addDateOutflow: id => {
      dispatch(addDateOutflow(id));
    },
    GetLiquidityData: id => {
      dispatch(GetLiquidityData(id));
    },
    SenenarioNames: () => {
      dispatch(SenenarioNames());
    },
    GetDefaultScenarioData: id => {
      dispatch(GetDefaultScenarioData(id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HeaderContainer);
