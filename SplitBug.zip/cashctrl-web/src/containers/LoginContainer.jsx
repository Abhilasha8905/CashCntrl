import { connect } from "react-redux";
import React, { Component } from "react";
import styled from "styled-components";
import Liquidity from "../components/Liquidity";
import { loginUser } from "../actions/LoginActions";
import Login from "../components/registration/Login";
import Toggleswitch from "../components/registration/Toggleswitch";
import TopIcon from "../images/header/TopIcon.png";

const Container = styled.div`
  position: fixed;
  height: 100%;
  width: 100%;
  background: rgb(248, 249, 251);
  z-index: 1;
`;

const SubContainer = styled.div`
  max-width: 550px;
  margin: 0 auto;
  border: 1px solid #ebebeb;
  margin-top: 50px;
  min-height: 400px;
  background: white;
`;

const Heading = styled.div.attrs({})`
  width: 100%;
  background: #fff;
  float: left;
  text-align: center;
  cursor: default;
  text-transform: uppercase;
  color: black;
  font-size: 20px;
  padding: 20px 0px;
`;

const CashCntrlIcon = styled.img.attrs({
  src: TopIcon
})`
    width: 117px;
    object-fit: contain;
    margin-left: 8px
    padding:0.5rem;
`;

class LoginContainer extends React.PureComponent {
  constructor(props) {
    super(props);
    this.handleLogin = this.handleLogin.bind(this);
  }

  componentWillUpdate(nextProps) {
    const { userStatus, userInfo, userTokan } = nextProps;
    //const { accessToken, refreshToken} = userTokan
    const { state = {} } = this.props.location;
    const { prevLocation } = state;
    const {
      userStatus: prevUserStatus,
      userInfo: prevUserInfo,
      userTokan: prevUserTokan
    } = this.props;
    if (
      userStatus === "loaded" &&
      userInfo.id !== prevUserInfo.id &&
      userTokan.accessToken &&
      userTokan.accessToken !== prevUserTokan.accessToken
    ) {
      const loginTime = new Date().getTime();
      const userInfo = {
        "user-login": true,
        userTokan,
        tokanTime: loginTime
      };
      window.localStorage.setItem("user-info", JSON.stringify(userInfo));
      // for logout
      // window.localStorage.setItem("user-login", "");
      this.props.history.push(prevLocation || "/");
    }
  }

  handleLogin(data) {
    const { loginUser } = this.props;
    loginUser(data);
  }

  render() {
    const { history, location } = this.props;
    return (
      <Container>
        <div className="container-fluid" style={{ margin: "0px", padding: "0px" }}>
          <div
            className="align-self-center"
            style={{
              borderBottom: "1px solid #ebebeb",
              padding: "10px 20px",
              boxShadow: "0 5px 10px 0 rgba(0,0,0,0.04)",
              background: "white"
            }}
          >
            <div className="container">
              <CashCntrlIcon />
            </div>
          </div>
          <SubContainer>
            <Heading>Sign In</Heading>
            <Login history={history} location={location} handleLogin={this.handleLogin} />
          </SubContainer>
        </div>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  userStatus: state.login.user,
  userInfo: state.login.userInfo,
  userTokan: state.login.tokan
});

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    loginUser: data => dispatch(loginUser(data))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LoginContainer);
