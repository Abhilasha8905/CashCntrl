import { connect } from "react-redux";
import React from "react";
import PropTypes from "prop-types";
import Inflow from "../components/Inflow";
import {
  addDateInflow,
  onButtonSelectInflow,
  dateValuesInflow,
  seriesDataInflow,
  applyDatesInflow,
  sumOfAmountInflow,
  dataPointInflow,
  filterList,
  customerFilterInflow,
  collectionsInflow,
  setFilterOptionsInflow,
  enteredAmountInflow,
  rangeInflow,
  clusterData,
  getClusterData,
  getCustomerDetailsonId,
  inflowUpdate
} from "../actions/InflowActions";

// Presentational component
class InflowContainer extends React.PureComponent {
  constructor(props) {
    super(props);

    this.callfunction = this.callfunction.bind(this);
  }

  componentWillMount() {
    if (this.props.cleanData.length === 0) {
      this.props.addDateInflow(this.props.fromDate, this.props.toDate);
    }
    this.props.clusterData();
  }

  callfunction(name) {
    
    this.props.dataPointInflow(name);
  }

  rangeInflow(balOne, balTwo) {
    this.props.rangeInflow(balOne, balTwo);
  }

  applyDatesInflow() {}

  enteredAmountInflow(amount) {
    this.props.enteredAmountInflow(amount);
  }

  filterList(ldata) {
    this.props.filterList(ldata);
  }

  getClusterData() {
    this.props.getClusterData();
  }

  dataPointInflow(point) {
    this.props.dataPointInflow(point);
  }

  getCustomerDetailsonId(id, from, to) {
    this.props.getCustomerDetailsonId(id, from, to);
  }

  sumOfAmountInflow() {
    this.props.sumOfAmountInflow(sum);
  }

  seriesDataInflow() {
    this.props.seriesDataInflow(series);
  }

  applyDatePicker(fromDate, toDate) {
    this.props.addDateInflow(fromDate, toDate);
  }

  onButtonSelectInflow(datefilter) {
    this.props.onButtonSelectInflow(datefilter);
  }

  collectionsInflow(collectionFilter) {
    this.props.collectionsInflow(collectionFilter);
  }

  dateValuesInflow() {
    this.props.dateValuesInflow(dates);
  }

  setFilterOptionsInflow(options) {
    this.props.setFilterOptionsInflow(options);
  }

  customerFilterInflow(cname, clusterName) {
    this.props.customerFilterInflow(cname, clusterName);
  }

  render() {
    //  this.props.dataPointInflow("seriesName.name");
    return (
      <Inflow
        data={this.props.data}
        fromDate={this.props.fromDate}
        toDate={this.props.toDate}
        dates={this.props.dates}
        series={this.props.series}
        dateChanged={this.props.dateChanged}
        datefilter={this.props.datefilter}
        sum={this.props.sum}
        collectionFilter={this.props.collectionFilter}
        options={this.props.options}
        amount={this.props.amount}
        balOne={this.props.balOne}
        balTwo={this.props.balTwo}
        cname={this.props.cname}
        point={this.props.point}
        fullDates={this.props.fullDates}
        otherCollections={this.props.otherCollections}
        customerDataFromId={this.props.customerDataFromId}
        customerlist={this.props.customerlist}
        customerclusterNames={this.props.customerclusterNames}
        groupedData={this.props.groupedData}
        customerClusterData={this.props.customerClusterData}
        applyDatePicker={this.applyDatePicker.bind(this)}
        dateValuesInflow={dateValuesInflow.bind(this)}
        seriesDataInflow={seriesDataInflow.bind(this)}
        applyDatesInflow={applyDatesInflow.bind(this)}
        sumOfAmountInflow={sumOfAmountInflow.bind(this)}
        dataPointInflow={this.callfunction}
        filterList={filterList.bind(this)}
        getClusterData={this.getClusterData.bind(this)}
        getCustomerDetailsonId={this.getCustomerDetailsonId.bind(this)}
        onButtonSelect={this.onButtonSelectInflow.bind(this)}
        collectionsInflow={this.collectionsInflow.bind(this)}
        setFilterOptionsInflow={this.setFilterOptionsInflow.bind(this)}
        customerFilterInflow={this.customerFilterInflow.bind(this)}
        productsList={this.props.productsList}
        initialList={this.props.initialList}
        enteredAmountInflow={this.props.enteredAmountInflow}
        rangeInflow={this.props.rangeInflow.bind(this)}
        inflowUpdate={this.props.inflowUpdate.bind(this)}
      />
    );
  }
}
// state: our state is passed as the first argument here
const mapStateToProps = state => ({
  data: state.inflow.data,
  cleanData: state.inflow.cleanData,
  fromDate: state.inflow.fromDate,
  toDate: state.inflow.toDate,
  dates: state.inflow.dates,
  series: state.inflow.series,
  dateChanged: state.inflow.dateChanged,
  datefilter: state.inflow.datefilter,
  sum: state.inflow.sum,
  collectionFilter: state.inflow.collectionFilter,
  options: state.inflow.options,
  amount: state.inflow.amount,
  balOne: state.inflow.balOne,
  balTwo: state.inflow.balTwo,
  cname: state.inflow.cname,
  point: state.inflow.point,
  productsList: state.inflow.productsList,
  initialList: state.inflow.initialList,
  customerclusterNames: state.inflow.customerclusterNames,
  customerlist: state.inflow.customerlist,
  customerDataFromId: state.inflow.customerDataFromId,
  otherCollections:state.inflow.otherCollections,
  customerClusterData: state.inflow.customerClusterData,
  fullDates:state.inflow.fullDates,
  groupedData: state.inflow.groupedData,
});

InflowContainer.propTypes = {
  data: PropTypes.array,
  fromDate: PropTypes.instanceOf(Date),
  toDate: PropTypes.instanceOf(Date),
  dates: PropTypes.array,
  series: PropTypes.array,
  dateChanged: PropTypes.bool,
  datefilter: PropTypes.string,
  sum: PropTypes.string,
  collectionFilter: PropTypes.string,
  options: PropTypes.string,
  amount: PropTypes.string,
  balOne: PropTypes.string,
  balTwo: PropTypes.string,
  cname: PropTypes.array,
  point: PropTypes.string
};

// actions: Redux's dispatch function is passed as the first argument here
const mapDispatchToProps = dispatch => {
  return {
    addDateInflow: (fromDate, toDate) => dispatch(addDateInflow(fromDate, toDate)),
    onButtonSelectInflow: datefilter => dispatch(onButtonSelectInflow(datefilter)),
    dateValuesInflow: dates => dispatch(dateValuesInflow(dates)),
    seriesDataInflow: series => dispatch(seriesDataInflow(series)),
    applyDatesInflow: () => dispatch(applyDatesInflow()),
    sumOfAmountInflow: sum => dispatch(sumOfAmountInflow(sum)),
    dataPointInflow: point => dispatch(dataPointInflow(point)),
    filterList: ldata => dispatch(filterList(ldata)),
    collectionsInflow: collectionFilter => dispatch(collectionsInflow(collectionFilter)),
    setFilterOptionsInflow: options => dispatch(setFilterOptionsInflow(options)),
    customerFilterInflow: (cname, clusterName) =>
      dispatch(customerFilterInflow(cname, clusterName)),
    enteredAmountInflow: amount => dispatch(enteredAmountInflow(amount)),
    rangeInflow: (balOne, balTwo) => dispatch(rangeInflow(balOne, balTwo)),
    clusterData: () => dispatch(clusterData()),
    getClusterData: () => dispatch(getClusterData()),
    getCustomerDetailsonId: (id, from, to) => dispatch(getCustomerDetailsonId(id, from, to)),
    inflowUpdate: () => dispatch(inflowUpdate())
  };
};
// defining the Container component, passing the above 2 functions into Redux's connect().
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(InflowContainer);
