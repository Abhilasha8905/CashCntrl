import { connect } from "react-redux";
import React from "react";
import Dashboard from "../components/Dashboard";

import {
  addDateDashboard,
  onButtonSelectDashboard,
  dateValuesDashboard,
  applyDatePicker,
  sumOfAmountDashboard,
  dataPointDashboard,
  addCardsData,
  addPDCOrClearIssue,
  bankBal,
  addCNCIorCNCR,
  getReminderData
} from "../actions/DasboardActions";

// Presentational component
class DashboardContainer extends React.PureComponent {
  componentWillMount() {
    if (this.props.data.length === 0) {
      this.props.addDateDashboard(this.props.fromDate, this.props.toDate);
      this.props.addCardsData();
      this.props.addCNCIorCNCR('CNCI');
      this.props.addCNCIorCNCR('CNCR');
    }
  }
  getReminderData() {
    this.props.getReminderData();
  }
  dataPointDashboard(point) {
    this.props.dataPointDashboard(point);
  }

  onButtonSelectDashboard(datefilter) {
    this.props.onButtonSelectDashboard(datefilter);
  }

  dateValuesDashboard() {
    this.props.dateValuesDashboard(dates);
  }

  applyDatePicker(fromDate, toDate) {
    this.props.addDateDashboard(fromDate, toDate);
  }

  addPDCOrClearIssue(dashboardType) {
    this.props.addPDCOrClearIssue(dashboardType);
  }

  bankBal(bankBalance) {
    this.props.bankBal(bankBalance);
  }

  addCardsData() {
    this.props.addCardsData();
  }

  addCNCIorCNCR(dashboardType) {
    this.props.addCNCIorCNCR(dashboardType);
  }

  render() {
    return (
      <Dashboard
        fromDate={this.props.fromDate}
        toDate={this.props.toDate}
        dateChanged={this.props.dateChanged}
        sum={this.props.sum}
        dates={this.props.dates}
        balanceData={this.props.balanceData}
        inFlowData={this.props.inFlowData}
        outFlowData={this.props.outFlowData}
        dashboardTypeDataCnci={this.props.dashboardTypeDataCnci}
        dashboardTypeDataCncr={this.props.dashboardTypeDataCncr}
        applyDatePicker={this.applyDatePicker.bind(this)}
        getReminderData={this.getReminderData.bind(this)}
        dateValuesDashboard={dateValuesDashboard.bind(this)}
        sumOfAmountDashboard={sumOfAmountDashboard.bind(this)}
        dataPointDashboard={dataPointDashboard.bind(this)}
        onButtonSelectDashboard={this.onButtonSelectDashboard.bind(this)}
        addPDCOrClearIssue={this.addPDCOrClearIssue.bind(this)}
        bankBalance={this.props.bankBalance}
        cashBalance={this.props.cashBalance}
        reminderCollections={this.props.reminderCollections}
        cnClear={this.props.cnClear}
        ciClear={this.props.ciClear}
        pdcIssue={this.props.pdcIssue}
        datefilter={this.props.datefilter}
        dashboardType={this.props.dashboardType}
        dasboardTypeData={this.props.dasboardTypeData}
        dashboardType={this.props.dashboardType}
        bankBal={this.bankBal.bind(this)}
        bankBalance={this.props.bankBalance}
        addCardsData={this.addCardsData.bind(this)}
        addCNCIorCNCR={this.props.addCNCIorCNCR.bind(this)}
      />
    );
  }
}
// state: our state is passed as the first argument here
const mapStateToProps = state => ({
  data: state.dashboard.data,
  fromDate: state.dashboard.fromDate,
  toDate: state.dashboard.toDate,
  dates: state.dashboard.dates,
  datefilter: state.dashboard.datefilter,
  balanceData: state.dashboard.balanceData,
  inFlowData: state.dashboard.inFlowData,
  outFlowData: state.dashboard.outFlowData,
  bankBalance: state.dashboard.bankBalance,
  cnClear: state.dashboard.cnClear,
  ciClear: state.dashboard.ciClear,
  pdcIssue: state.dashboard.pdcIssue,
  cashBalance: state.dashboard.cashBalance,
  dasboardTypeData: state.dashboard.dasboardTypeData,
  dashboardType: state.dashboard.dashboardType,
  dashboardTypeDataCnci: state.dashboard.dashboardTypeDataCnci,
  dashboardTypeDataCncr: state.dashboard.dashboardTypeDataCncr,
  bankBalance: state.dashboard.bankBalance,
  reminderCollections: state.dashboard.reminderCollections
});
// actions: Redux's dispatch function is passed as the first argument here
const mapDispatchToProps = dispatch => {
  return {
    addDateDashboard: (fromDate, toDate) => dispatch(addDateDashboard(fromDate, toDate)),
    onButtonSelectDashboard: datefilter => dispatch(onButtonSelectDashboard(datefilter)),
    dateValuesDashboard: dates => dispatch(dateValuesDashboard(dates)),
    sumOfAmountDashboard: sum => dispatch(sumOfAmountDashboard(sum)),
    dataPointDashboard: point => dispatch(dataPointDashboard(point)),
    addCardsData: () => dispatch(addCardsData()),
    addPDCOrClearIssue: dashboardType => dispatch(addPDCOrClearIssue(dashboardType)),
    bankBal: bankBalance => dispatch(bankBal(bankBalance)),
    addCNCIorCNCR: (dashboardType) => dispatch(addCNCIorCNCR(dashboardType)),
    getReminderData: () => dispatch(getReminderData())
  };
};
// defining the Container component, passing the above 2 functions into Redux's connect().
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DashboardContainer);
