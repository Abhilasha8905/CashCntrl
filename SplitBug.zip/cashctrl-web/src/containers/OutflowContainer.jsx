import { connect } from "react-redux";
import React, { Component } from "react";
import PropTypes from "prop-types";
import Outflow from "../components/Outflow";
import {
  addDateOutflow,
  onButtonSelectOutflow,
  dateValuesOutflow,
  seriesDataOutflow,
  applyDatesOutflow,
  sumOfAmountOutflow,
  dataPointOutflow,
  filterList,
  customerFilterOutflow,
  collectionsOutflow,
  setFilterOptionsOutflow,
  enteredAmountOutflow,
  rangeOutflow,
  getCustomerDetailsonId,
  outflowUpdate,
  getClusterData,
  clusterData,
  addOutflowType
} from "../actions/OutFlowActions";

// Presentational component
class OutflowContainer extends Component {
  constructor(props) {
    super(props);

    this.callfunction = this.callfunction.bind(this);
  }

  componentWillMount() {
    if (this.props.cleanData.length === 0) {
      this.props.addDateOutflow(this.props.fromDate, this.props.toDate);
    }
    this.props.clusterData();
  }

  rangeOutflow(balOne, balTwo) {
    this.props.rangeOutflow(balOne, balTwo);
  }

  applyDatesOutflow() {}

  getClusterData() {
    this.props.getClusterData();
  }

  enteredAmountOutflow(amount) {
    this.props.enteredAmountOutflow(amount);
  }

  addOutflowType(fromDate, toDate, type) {
    this.props.addOutflowType(fromDate, toDate, type);
    // this.props.addDateOutflow(fromDate, toDate);
  }

  filterList(ldata) {
    this.props.filterList(ldata);
  }

  getCustomerDetailsonId(id, from, to) {
    this.props.getCustomerDetailsonId(id, from, to);
  }

  dataPointOutflow(point) {
    this.props.dataPointOutflow(point);
  }

  sumOfAmountOutflow() {
    this.props.sumOfAmountOutflow(sum);
  }

  seriesDataOutflow() {
    this.props.seriesDataOutflow(series);
  }

  applyDatePicker(fromDate, toDate) {
    this.props.addDateOutflow(fromDate, toDate);
  }

  onButtonSelectOutflow(datefilter) {
    this.props.onButtonSelectOutflow(datefilter);
  }

  callfunction(name) {
    this.props.dataPointOutflow(name);
  }

  collectionsOutflow(collectionFilter) {
    this.props.collectionsOutflow(collectionFilter);
  }

  dateValuesOutflow(dates) {
    this.props.dateValuesOutflow(dates);
  }

  setFilterOptionsOutflow(options) {
    this.props.setFilterOptionsOutflow(options);
  }

  customerFilterOutflow(cname) {
    this.props.customerFilterOutflow(cname);
  }

  render() {
    return (
      <Outflow
        data={this.props.data}
        fromDate={this.props.fromDate}
        toDate={this.props.toDate}
        dates={this.props.dates}
        series={this.props.series}
        dateChanged={this.props.dateChanged}
        datefilter={this.props.datefilter}
        sum={this.props.sum}
        collectionFilter={this.props.collectionFilter}
        customerDataFromId={this.props.customerDataFromId}
        options={this.props.options}
        amount={this.props.amount}
        balOne={this.props.balOne}
        balTwo={this.props.balTwo}
        cname={this.props.cname}
        point={this.props.point}
        fullDates={this.props.fullDates}
        groupedData={this.props.groupedData}
        otherCollections={this.props.otherCollections}
        vendorClusterData={this.props.vendorClusterData}
        vendorclusterNames={this.props.vendorclusterNames}
        applyDatePicker={this.applyDatePicker.bind(this)}
        addOutflowType={this.props.addOutflowType.bind(this)}
        dateValuesOutflow={dateValuesOutflow.bind(this)}
        seriesDataOutflow={seriesDataOutflow.bind(this)}
        applyDateOutflow={applyDatesOutflow.bind(this)}
        sumOfAmountOutflow={sumOfAmountOutflow.bind(this)}
        getCustomerDetailsonId={this.getCustomerDetailsonId.bind(this)}
        dataPointOutflow={this.callfunction}
        filterList={filterList.bind(this)}
        getClusterData={this.getClusterData.bind(this)}
        onButtonSelect={this.onButtonSelectOutflow.bind(this)}
        collectionsOutflow={this.collectionsOutflow.bind(this)}
        setFilterOptionsOutflow={this.setFilterOptionsOutflow.bind(this)}
        customerFilterOutflow={this.customerFilterOutflow.bind(this)}
        productsList={this.props.productsList}
        initialList={this.props.initialList}
        enteredAmountOutflow={this.props.enteredAmountOutflow}
        rangeOutflow={this.props.rangeOutflow.bind(this)}
        outflowUpdate={this.props.outflowUpdate.bind(this)}
      />
    );
  }
}
// state: our state is passed as the first argument here
const mapStateToProps = state => ({
  data: state.outflow.data,
  cleanData: state.outflow.cleanData,
  fromDate: state.outflow.fromDate,
  toDate: state.outflow.toDate,
  dates: state.outflow.dates,
  series: state.outflow.series,
  dateChanged: state.outflow.dateChanged,
  datefilter: state.outflow.datefilter,
  sum: state.outflow.sum,
  collectionFilter: state.outflow.collectionFilter,
  options: state.outflow.options,
  amount: state.outflow.amount,
  balOne: state.outflow.balOne,
  balTwo: state.outflow.balTwo,
  cname: state.outflow.cname,
  point: state.outflow.point,
  productsList: state.outflow.productsList,
  vendorclusterNames: state.outflow.vendorclusterNames,
  customerDataFromId: state.outflow.customerDataFromId,
  initialList: state.outflow.initialList,
  vendorclusterNames: state.outflow.vendorclusterNames,
  vendorClusterData: state.outflow.vendorClusterData,
  otherCollections: state.outflow.otherCollections,
  fullDates: state.outflow.fullDates,
  groupedData: state.outflow.groupedData
});

OutflowContainer.propTypes = {
  data: PropTypes.array,
  fromDate: PropTypes.instanceOf(Date),
  toDate: PropTypes.instanceOf(Date),
  dates: PropTypes.array,
  series: PropTypes.array,
  dateChanged: PropTypes.bool,
  datefilter: PropTypes.string,
  sum: PropTypes.string,
  collectionFilter: PropTypes.string,
  options: PropTypes.string,
  amount: PropTypes.string,
  balOne: PropTypes.string,
  balTwo: PropTypes.string,
  cname: PropTypes.array,
  point: PropTypes.string
};

// actions: Redux's dispatch function is passed as the first argument here
const mapDispatchToProps = dispatch => {
  return {
    addDateOutflow: (fromDate, toDate) => dispatch(addDateOutflow(fromDate, toDate)),
    onButtonSelectOutflow: datefilter => dispatch(onButtonSelectOutflow(datefilter)),
    dateValuesOutflow: dates => dispatch(dateValuesOutflow(dates)),
    seriesDataOutflow: series => dispatch(seriesDataOutflow(series)),
    applyDatesOutflow: () => dispatch(applyDatesOutflow()),
    sumOfAmountOutflow: sum => dispatch(sumOfAmountOutflow(sum)),
    dataPointOutflow: point => dispatch(dataPointOutflow(point)),
    filterList: ldata => dispatch(filterList(ldata)),
    collectionsOutflow: collectionFilter => dispatch(collectionsOutflow(collectionFilter)),
    setFilterOptionsOutflow: options => dispatch(setFilterOptionsOutflow(options)),
    customerFilterOutflow: cname => dispatch(customerFilterOutflow(cname)),
    enteredAmountOutflow: amount => dispatch(enteredAmountOutflow(amount)),
    rangeOutflow: (balOne, balTwo) => dispatch(rangeOutflow(balOne, balTwo)),
    getCustomerDetailsonId: (id, from, to) => dispatch(getCustomerDetailsonId(id, from, to)),
    getClusterData: () => dispatch(getClusterData()),
    clusterData: () => dispatch(clusterData()),
    outflowUpdate: () => dispatch(outflowUpdate()),
    addOutflowType: (from, to, type) => dispatch(addOutflowType(from, to, type))
  };
};
// defining the Container component, passing the above 2 functions into Redux's connect().
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OutflowContainer);
