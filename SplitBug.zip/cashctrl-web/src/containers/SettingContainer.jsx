import React from "react";
import { connect } from "react-redux";
import styled from "styled-components";
import Setting from "../components/registration/Setting";
import AddedUser from "../components/registration/AddedUser";
import { registerUser, resetRegisterUser, getAllRegisteredUsers } from "../actions/LoginActions";
import { Col } from "react-bootstrap";
import {Link } from "react-router-dom";


import "./settings.css";

// Presentational component
const Container = styled.div`
height: 100%;
`;

const Heading = styled.div.attrs({})`
  width: 100%;
  background: #fff;
  float: left;
  height: 60px;
  line-height: 60px;
  text-align: center;
  cursor: pointer;
  text-transform: uppercase;
  background: ${props => (props.active ? `#34b3a0` : "")};
  color: ${props => (props.active ? `white` : `black`)};
`;

class SettingContainer extends React.PureComponent {
  constructor(props) {
    super(props);
    this.handleSetting = this.handleSetting.bind(this);
  }


  componentWillMount() {
    this.props.resetRegisterUser();
    this.props.getAllRegisteredUsers();
  }

  componentWillUpdate(nextProps) {
    const { userStatus, userInfo, userTokan } = nextProps;
    const { state = {} } = this.props.location;
    const { prevLocation } = state;
    const {
      userStatus: prevUserStatus,
      userInfo: prevUserInfo,
      userTokan: prevUserTokan
    } = this.props;
    if (
      userStatus === "loaded" &&
      userInfo.id !== prevUserInfo.id &&
      userTokan.accessToken &&
      userTokan.accessToken !== prevUserTokan.accessToken
    ) {
      console.log("Write Redirection logic here");

      window.localStorage.setItem("user-register", "true");
      this.props.history.push(prevLocation || "/");
    }
  }

  handleSetting(data) {
    const { registerUser } = this.props;
    registerUser(data);
  }

  render() {
    const { history, location, registerMsg, registerUserStatus, resetRegisterUser, registeredUserList } = this.props;

    return (
      <div className="row h-100" style={{ position: "fixed", top: "51px", width: "100%" }}>
        <Container className="container-fluid setting-container">
        <Link to="/dashboard">

          <div 
            style={{
              width: "60px", height: "30px", background: "white", position: "absolute", top: "10px",textDecoration:"underline",
              textAlign: "center", borderRadius: "5px", marginLeft: "10px", fontSize: "12px",cursor:"pointer",zIndex:"1",lineHeight:"30px" }}>
            <img
              src={require("../images/flowChart/arrow-left.png")}
              style={{ marginLeft: "0px", marginRight: "5px", width: "5px" }}
            />
            BACK
       </div>
       </Link>
          <div>
            <Col lg={6} className="float-left adduser" style={{ paddingRight: "0px" }}>
              <h1>Add User</h1>
              <Setting history={history} location={location} handleSetting={this.handleSetting} registerMsg={registerMsg} registerUserStatus={registerUserStatus}
                resetRegisterUser={resetRegisterUser}
              ></Setting>
            </Col>
            <Col lg={6} className="float-left account-info" style={{ paddingLeft: "0px" }}>
              <h1>Account Information</h1>
              <AddedUser registeredUserList={registeredUserList} />
            </Col>
          </div>
        </Container>
      </div>
    );
  }
}

// const AddedUser = ({registeredUserList = []}) => {
//
//   console.log(registeredUserList)
//   if(registeredUserList.length>0){
//
//     return (
//       <div>
//         <div>Vipin</div>
//
//       </div>
//     )
//   }else{
//     return ""
//   }
//
// }

const mapStateToProps = state => ({
  registerMsg: state.login.registerMsg,
  registerUserStatus: state.login.registerUserStatus,
  registeredUserList: state.login.registeredUserList
});

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    registerUser: data => dispatch(registerUser(data)),
    resetRegisterUser: () => dispatch(resetRegisterUser()),
    getAllRegisteredUsers: () => dispatch(getAllRegisteredUsers())
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SettingContainer);
