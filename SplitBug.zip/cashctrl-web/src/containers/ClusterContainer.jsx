import { connect } from "react-redux";
import React from "react";
import CustomerVendor from "../components/dashboardComponents/CustomerVendorView";
import {
  clusterData,
  clusterFilter,
  getCustomersList,
  customerListInflow,
  createNewCustomerCluster,
  createNewVendorCluster
} from "../../actions/InflowActions";
import { getVendorsList } from "../../actions/OutFlowActions";

class ClusterContainer extends React.PureComponent {
  componentWillMount() {
    if (this.props.ccustomers.length === 0) {
      this.props.clusterData();
    }
  }

  clusterFilter(ccustomers) {
    this.props.clusterFilter(ccustomers);
  }

  customerListInflow(customer) {
    this.props.customerListInflow(customer);
  }

  createNewCustomerCluster(customerids, name) {
    this.props.createNewCluster(customerids, name);
  }

  createNewVendorCluster(customerids, name) {
    this.props.createNewCluster(customerids, name);
  }

  render() {
    return (
      <CustomerVendor
        ccustomers={this.props.ccustomers}
        customerClusterData={this.props.customerClusterData}
        vendorClusterData={this.props.vendorClusterData}
        customerlist={this.props.customerlist}
        customer={this.props.customer}
        customerIds={this.props.customerIds}
        vendorlist={this.props.vendorlist}
        customerListInflow={this.props.customerListInflow.bind(this)}
        createNewCustomerCluster={this.props.createNewCustomerCluster.bind(this)}
        createNewVendorCluster={this.props.createNewVendorCluster.bind(this)}
        clusterFilter={this.props.clusterFilter.bind(this)}
      />
    );
  }
}
const mapStateToProps = state => ({
  ccustomers: state.inflow.ccustomers,
  customerClusterData: state.inflow.customerClusterData,
  vendorClusterData: state.inflow.vendorClusterData,
  customerlist: state.inflow.customerlist,
  customer: state.inflow.customer,
  customerIds: state.inflow.customerIds,
  vendorlist: state.outflow.vendorlist
});
const mapDispatchToProps = dispatch => {
  return {
    clusterFilter: ccustomers => dispatch(clusterFilter(ccustomers)),
    clusterData: () => dispatch(clusterData()),
    getCustomersList: () => dispatch(getCustomersList()),
    getVendorsList: () => dispatch(getVendorsList()),
    customerListInflow: customer => dispatch(customerListInflow(customer)),
    createNewCustomerCluster: (customerids, name) =>
      dispatch(createNewCustomerCluster(customerids, name)),
    createNewVendorCluster: (customerids, name) =>
      dispatch(createNewVendorCluster(customerids, name))
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ClusterContainer);
