import { connect } from "react-redux";
import React, { Component } from "react";
import Liquidity from "../components/Liquidity";
import { SenenarioNames } from "../actions/CommonActions";
import { addDateInflow } from "../actions/InflowActions";
import { addDateOutflow } from "../actions/OutFlowActions";
import {
  GetLiquidityData,
  GetDefaultScenarioData,
  saveScenario,
  createScenario,
  DeleteScenario,
  sortData,
  UpdateScenario
} from "../actions/LiquidityActions";

// Presentational component
class LiquidityContainer extends Component {
  componentWillMount() {
    if (this.props.scenarioData.length === 0) {
      this.props.GetLiquidityData();
      this.props.GetDefaultScenarioData();
    }
  }

  componentDidUpdate() {
    console.log(this.props.payment, "kjkjlkj");
  }

  sortData(method) {
    console.log("method", method);
    this.props.sortData(method, this.props.payment, this.props.collection);
  }

  saveScenario(param) {
    this.props.saveScenario(param);
  }

  UpdateScenarioData() {
    this.props.addDateInflow(id);
    this.props.addDateOutflow(id);
    this.props.GetLiquidityData(id);
  }

  createScenario(scenarioName) {
    this.props.createScenario(scenarioName);
  }

  DeleteScenario() {
    this.props.DeleteScenario(this.props.currentScenaruiId);
  }

  UpdateScenario(param) {
    this.props.UpdateScenario(param);
  }

  render() {
    console.log("shjdbghs", this.props.payment);

    return (
      <Liquidity
        scenarioData={this.props.scenarioData}
        ledgerData={this.props.ledgerData}
        dates={this.props.dates}
        payment={this.props.payment}
        collection={this.props.collection}
        saveScenario={this.saveScenario.bind(this)}
        createScenario={this.createScenario.bind(this)}
        scenarioName={this.props.scenarioName}
        newlyCreated={this.props.newlyCreated}
        DeleteScenario={this.DeleteScenario.bind(this)}
        currentScenario={this.props.currentScenario}
        scenarioNames={this.props.scenarioNames}
        sortData={this.sortData.bind(this)}
        UpdateScenario={this.UpdateScenario.bind(this)}
        currentScenaruiId={this.props.currentScenaruiId}
      />
    );
  }
}
// state: our state is passed as the first argument here
const mapStateToProps = state => ({
  dates: state.liquidity.dates,
  scenarioData: state.liquidity.scenarioData,
  ledgerData: state.liquidity.data,
  payment: state.liquidity.payment,
  collection: state.liquidity.collection,
  scenarioName: state.liquidity.scenarioName,
  newlyCreated: state.liquidity.newlyCreated,
  currentScenaruiId: state.liquidity.currentScenaruiId,
  scenarioNames: state.liquidity.scenarioNames
});
// actions: Redux's dispatch function is passed as the first argument here
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    GetLiquidityData: () => dispatch(GetLiquidityData()),
    GetDefaultScenarioData: () => dispatch(GetDefaultScenarioData()),
    saveScenario: param => dispatch(saveScenario(param)),
    createScenario: scenarioName => dispatch(createScenario(scenarioName)),
    sortData: (method, payments, collections) => dispatch(sortData(method, payments, collections)),
    UpdateScenario: param => dispatch(UpdateScenario(param)),
    SenenarioNames: () => {
      dispatch(SenenarioNames());
    },
    DeleteScenario: id => {
      dispatch(DeleteScenario(id));
    }
  };
};
// defining the Container component, passing the above 2 functions into Redux's connect().
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LiquidityContainer);
