import { createStore, compose, applyMiddleware } from "redux";

import thunk from "redux-thunk";
import Middlewares from "./appMiddlewares";

import Reducers from "./appReducers";

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const configureStore = (instances, initialState = {}) => {
  return composeEnhancers(Middlewares())(createStore)(
    Reducers(instances),
    initialState,
    applyMiddleware(thunk)
  );
};

export default configureStore;
