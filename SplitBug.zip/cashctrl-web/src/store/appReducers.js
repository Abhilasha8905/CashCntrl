import { combineReducers } from "redux";
import DashboardReducer from "../reducers/DasboardReducer";
import InflowReducer from "../reducers/InflowReducers";
import OutflowReducer from "../reducers/OutflowReducer";
import LiquidityReducer from "../reducers/LiquidityReducers";

import CommonReducer from "../reducers/CommonReducer";
import LoginReducer from "../reducers/LoginReducer";

export default () => {
  return combineReducers({
    dashboard: DashboardReducer,
    inflow: InflowReducer,
    outflow: OutflowReducer,
    liquidity: LiquidityReducer,
    common: CommonReducer,
    login: LoginReducer
  });
};
