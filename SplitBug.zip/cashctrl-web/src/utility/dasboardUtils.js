import moment from "moment";
import NewData from "../components/dashboardComponents/NewData";

const weekData = date => {
  return moment()
    .day("Monday")
    .week(date)
    .format("MM/DD/YYYY");
};

const monthData = date => {
  date = parseInt(date);
  const formattedMonth = moment.months(date - 1);
  return moment()
    .endOf("month")
    .month(formattedMonth)
    .format("MM/DD/YYYY");
};
export const InFlowData = data => {
  const InflowArr = [];
  data.map(x => {
    InflowArr.push(x.graphDataSample.inFlow);
  });
  
  return InflowArr;
};
export const extractDataForReminder = data => {
  let Newdata = [];
 data.map(item => {
   let name=item.customer.name;
   let id=item.id;
   let date=item.invoiceDate;
   let amount=item.invoiceValue;
   Newdata.push({
     name:name,
     id:id,
     date:date,
     amount:amount
   });
 });
 return Newdata;
}
export const OutFlowData = data => {
  const OutflowArr = [];
  data.map(x => {
    OutflowArr.push(x.graphDataSample.outFlow);
  });
  
  return OutflowArr;
};
export const BalanceData = data => {
  const BalanceArr = [];
  data.map(x => {
    BalanceArr.push(x.graphDataSample.netBalance);
  });
  
  return BalanceArr;
};

export const Dates = (data, datefilter) => {
  const DatesArr = [];
  let date = 0;
  data.map(x => {
    if (datefilter === "Day") {
      date = moment(x.date).format("DD MMM");
    } else {
      date = x.date;
    }
    if (datefilter === "Month") {
      date = moment(x.date).format(" MMM");
    }
    // if (datefilter === "Week") {
    //   x = getWeekRange(x.date);
    // }

    DatesArr.push(date);
  });
  
  return DatesArr;
};

export const extractData = (data, datefilter) => {
  if (datefilter !== "Day") {
    const newData = [];
    data.map(x => {
      const date = moment(x.date);
      newData.push({
        inFlow: x.graphDataSample.inFlow,
        outFlow: x.graphDataSample.outFlow,
        netBalance: x.graphDataSample.netBalance,
        Week: date.week(),
        Month: date.month() + 1,
        Day: date
      });
    });

    return newData;
  }
 
  return data;
};

export const groupBy = (data, key) => {
  if (key !== "Day") {
    const newData = [];

    const groupeddata = groupByData(data, key);
    for (const k in groupeddata) {
      let balsum = 0;
      let inSum = 0;
      let outSum = 0;
      let y = {};
      let d = [];
      const keyObj = {};
      const arr = groupeddata[k];
      for (let i = 0; i < arr.length; i++) {
        y = arr[i];
        balsum += y.netBalance;
        inSum += y.inFlow;
        outSum += y.outFlow;
      }
      keyObj.netBalance = balsum;
      keyObj.inFlow = inSum;
      keyObj.outFlow = outSum;
      if (key === "Month") {
        d = monthData(y[key]);
      }
 
      if (key === "Week") {
       
        d = getWeekRange(y[key]);
      }
      newData.push({
        date: d,
        graphDataSample: keyObj
      });
    }

    return newData;
  }
  
  return data;
};

export const groupByData = (xs, key) => {
  return xs.reduce(function(rv, x) {
    (rv[x[key]] = rv[x[key]] || []).push(x);
    return rv;
  }, {});
};

export const getWeekRange = weekNumber => {
  let range = [];
  const beginningOfWeek = moment()
    .week(weekNumber)
    .startOf("week");
  const endOfWeek = moment()
    .week(weekNumber)
    .startOf("week")
    .add(6, "days");
  range = `${beginningOfWeek.format(" DD MMM")}-${endOfWeek.format(" DD MMM")}`;
  
  return range;
};
