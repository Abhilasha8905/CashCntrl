 import ConvertUnit from './ConvertUnit';
import { faDumbbell } from '@fortawesome/free-solid-svg-icons';

 export default function SumOfAmount(amountArr){

    var sum = amountArr.reduce((a,b)=>a+b,0);
 
 
        return sum;
    
   

}

 