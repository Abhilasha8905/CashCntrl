import moment from "moment";
import uuid from "uuid/v4";
import { groupBy } from "./newutil";

export const FetchDataForPayments = data => {
  const CollectionData = [];
  const PaymentData = [];
  const newData = {};

  data.collections.map(x => {
    CollectionData.push({
      ledgerId: x.id,
      description: x.customer.name,
      id: x.customer.id,
      date: moment(x.invoiceDate).format("DD/MM/YYYY"),
      invoiceNumber: x.invoiceNumber,
      invoiceValue: x.invoiceValue,
      mode: x.ledgerType,
      age: x.ageOfTheInvoice,
      status: x.status,
      subLedgerId: x.subLedgerId,
      uniqueKey: uuid()
    });
  });

  data.payments.map(x => {
    PaymentData.push({
      ledgerId: x.id,
      description: x.vendor.name,
      id: x.vendor.id,
      date: moment(x.invoiceDate).format("DD/MM/YYYY"),
      invoiceNumber: x.invoiceNumber,
      invoiceValue: x.invoiceValue,
      mode: x.ledgerType,
      age: x.ageOfTheInvoice,
      status: x.status,
      subLedgerId: x.subLedgerId,
      uniqueKey: uuid()
    });
  });
  (newData.collection = CollectionData), (newData.payments = PaymentData);
  return newData;
};

export const getDates = startDate => {
  const dateArray = [];
  let currentDate = moment(startDate);
  const stopDate = moment("09/30/2019");

  while (currentDate <= stopDate) {
    dateArray.push(moment(currentDate).format("DD/MM/YYYY"));
    currentDate = moment(currentDate).add(1, "days");
  }
  return dateArray;
};

export const scenarioFilteredData = data => {
  const newData = [];
  data.map(x => {
    console.log(x, "...x");
    newData.push({
      ledgerId: x.id,
      description: x.vendor ? x.vendor.name : x.customer.name,
      id: x.vendor ? x.vendor.id : x.customer.id,
      date: moment(x.invoiceDate).format("DD/MM/YYYY"),
      invoiceNumber: x.invoiceNumber,
      invoiceValue: x.invoiceValue,
      mode: x.ledgerType,
      age: x.ageOfTheInvoice,
      subLedgerId: x.subLedgerId,
      status: x.status,
      uniqueKey: uuid()
    });
  });

  return newData;
};

export const LiquiditySorted = (method, payment, collection) => {
  let m = "";
  const newData = [];
  if (method === "Aging") {
    m = "age";
    const payments = sortedList(m, payment);
    const collections = sortedList(m, collection);
    (newData.payments = payments), (newData.collection = collections);
    return newData;
  }
  m = "description";
  const paymentss = sortedNames(m, payment);
  const collectionss = sortedNames(m, collection);
  (newData.payments = paymentss), (newData.collection = collectionss);
  return newData;
};

export const sortedList = (method, list) => {
  const newList = [...list];
  newList.sort(function(a, b) {
    console.log(a.age, "..........methof=d");
    return a.age - b.age;
  });
  return newList;
};

export const sortedNames = (m, list) => {
  const newList = [...list];
  newList.sort(function(a, b) {
    const nameA = a.description.toLowerCase();
    const nameB = b.description.toLowerCase();
    if (nameA < nameB)
      // sort string ascending
      return -1;
    if (nameA > nameB) return 1;
    return 0; // default return value (no sorting)
  });
  return newList;
};

function getDefaultCustomerValues() {
  return {
    totalPayment: 0,
    totalCollection: 0,
    droppedCollection: 0,
    droppedPayment: 0
  };
}

export function getCustomerLedgerTotals(ledgerData, scenarioData) {
  let data = {};

  data = ledgerData.collection.reduce(function(r, ledger) {
    r[ledger.id] = r[ledger.id] || getDefaultCustomerValues();
    if (ledger.mode === "INFLOW") {
      r[ledger.id].totalCollection += ledger.invoiceValue;
    } else if (ledger.mode === "OUTFLOW") {
      r[ledger.id].totalPayment += ledger.invoiceValue;
    }
    return r;
  }, data);

  data = ledgerData.payments.reduce(function(r, ledger) {
    r[ledger.id] = r[ledger.id] || getDefaultCustomerValues();
    if (ledger.mode === "INFLOW") {
      r[ledger.id].totalCollection += ledger.invoiceValue;
    } else if (ledger.mode === "OUTFLOW") {
      r[ledger.id].totalPayment += ledger.invoiceValue;
    }
    return r;
  }, data);

  data = scenarioData.reduce(function(r, ledger) {
    r[ledger.id] = r[ledger.id] || getDefaultCustomerValues();
    if (ledger.mode === "INFLOW") {
      r[ledger.id].droppedCollection += ledger.invoiceValue;
    } else if (ledger.mode === "OUTFLOW") {
      r[ledger.id].droppedPayment += ledger.invoiceValue;
    }
    return r;
  }, data);

  return data;
}

export function getDroppedValuesPerCustomer(droppedCollections) {}
