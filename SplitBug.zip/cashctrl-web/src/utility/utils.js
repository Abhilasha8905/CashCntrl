import _ from "lodash";
import moment from "moment-timezone";
import datas from "../components/dashboardComponents/data/Customerdata.json";
// export default function groupByWeekResults(dates) {
//      _.groupBy(dates, function (date) {
//         return moment(date).startOf('isoWeek');
//       })
//     }
// let dates=[];
export const groupByWeekResults = dates => {
  const arr = [];
  arr.push(
    _.groupBy(dates, function(date) {
      return moment(date)
        .startOf("isoWeek")
        .format("MM/DD/YYYY z");
    })
  );
  return arr[arr.length - 1];
};
export const groupedByMonthsResults = dates => {
  const datebymonth = [];
  datebymonth.push(
    _.groupBy(dates, function(date) {
      return moment(date)
        .startOf("isoMonth")
        .format("MM/DD/YYYY z");
    })
  );
  
  return datebymonth;
  //     let arr=[];
  //     arr.push(Object.values(d));
  //     var myArray = [];
  // for(var i = 0, len = arr.length; i < len; i++){
  //     for(var j=0;j<arr[0].length;j++) {
  //         myArray.push(arr[i][j][0]);
  //     }

  // }
  // return myArray;
};

export const extractDateRange = (sdt, edt) => {
  let dateArray = [];
  const gdata = extractData();
 
  if (!sdt && !edt) {
    dateArray = gdata
      .map(item => item.date)
      .filter((item, index, array) => array.indexOf(item) == index);
    
  } else {
    let startDate = moment(sdt);
    const endDate = moment(edt);

    while (startDate.isBefore(endDate)) {
      dateArray.push(startDate.format("YYYY-MM-DD"));
      startDate = startDate.add(1, "day");
    }

    dateArray = dateArray.map(d =>
      moment(moment(d).utc())
        .tz("GMT")
        .format("MM/DD/YYYY z")
    );
  }

  dateArray.sort(function(a, b) {
    return a > b ? 1 : a < b ? -1 : 0;
  });

  return dateArray;
};
export const extractData = () => {
  const data = [];
  for (const i in datas.customers) {
    for (const j in datas.customers[i].payment) {
      const date = moment(moment(datas.customers[i].payment[j].date).utc())
        .tz("GMT")
        .format("MM/DD/YYYY z");

      data.push({
        name: datas.customers[i].name,
        amount: datas.customers[i].payment[j].amount,
        date
      });
    }
  }

  return data;
};
export const productTotals = (s, e) => {
  const d = extractDateRange(s, e);
  const data = extractData();
  
  const prodTotal = data.reduce((obj, curr) => {
    if (!obj[curr.name]) {
      obj[curr.name] = [];
    }
    obj[curr.name][d.indexOf(curr.date)] = parseInt(curr.amount);
    return obj;
  }, {});
  
  return prodTotal;
};

export const seriesDataPoints = (s, e) => {
 
  const prodTotals = productTotals(s, e);
  const d = extractDateRange(s, e);
  const series = Object.entries(prodTotals).map(([name, prodArr]) => {
    return {
      name,
      data: d.map((date, dateIndex) => {
        if (!prodArr[dateIndex]) {
          return 0;
        }
        return prodArr[dateIndex];
      })
    };
  });
 

  return series;
};
