import data from "../components/dashboardComponents/data/Clusterdetails.json";

export function extractdata(name) {
  let datas = data;

  datas = datas.find(item => item.name === name);
  
  return datas;
}
