import moment from "moment-timezone";
import _ from "lodash";

let dateArr = [];
let cat = [];
let w = [];
let m = [];
let wnum = [];
let mnum = [];
// Function to create the x-axis values
const setDates = (categories, dateArr, groupByCategory) => {
  if (categories.length > 0) {
    if (groupByCategory === "Day") {
      const days = categories.map(c => moment(c).format("DD MMM"));
      const fullDates = categories.map(c => moment(c).format("DD MMM YYYY"));
      return [days, fullDates];
    }
    if (groupByCategory === "Week") {
      const weeks = dateArr.map(c => getWeekRange(c));
      w = [...new Set(weeks)];
      const weekNum = dateArr.map(c => getWeekNumber(c));
      wnum = [...new Set(weekNum)];
      return [w, wnum];
    }
    if (groupByCategory === "Month") {
      const months = dateArr.map(c => getMonthName(c));
      m = [...new Set(months)];
      const monthNum = dateArr.map(c => getMonthNum(c));
      mnum = [...new Set(monthNum)];
      return [m, mnum];
    }
  }
};

// function to extract data
export const extractData = (datas, cname) => {
  let Newdata = [];
  datas.map(item => {
    const { name } = item.customer;
    const { id } = item.customer;
    item.transactionDetails.map(i => {
      const date = moment(i.transactionDate);
      const d = moment(date).format("MM/DD/YYYY");
      const amount = i.transactionAmount;
      // if (moment(fromDt) <= moment(d) && moment(toDt) >= moment(d)) {
      Newdata.push({
        id,
        name,
        amount,
        date,
        Week: date.week(),
        Month: date.month() + 1,
        Day: i.transactionDate,
        newAmount: 20
      });
      // }
    });
  });

  if (cname.length !== 0) {
    Newdata = Newdata.filter(obj => cname.includes(obj.name));
  }

  return Newdata;
};

// function for grouping data
export const groupBy = (xs, key) => {
  return xs.reduce(function(rv, x) {
    (rv[x[key]] = rv[x[key]] || []).push(x);

    return rv;
  }, {});

  // if (xs.length > 2) {
  //   xs.push({
  //     name: 'Other Collectios',
  //     amount: 1000
  //   })
  // }

  // return xs;
};

// Function to extract dates
export const getDateArray = (start, end) => {
  const arr = new Array();
  const dt = new Date(start);
  while (dt <= end) {
    arr.push(new Date(dt));
    dt.setDate(dt.getDate() + 1);
  }
  return arr;
};

// Function to extract categories for x-axis
export const fetchCategories = (
  data,
  fromDate,
  toDate,
  groupByCategory,
  options,
  amount,
  balone,
  baltwo,
  collections,
  cname
) => {
  let categories = [];
  const startDate = new Date(fromDate); // YYYY-MM-DD
  const endDate = new Date(toDate);
  dateArr = getDateArray(startDate, endDate);

  cat = dateArr.map(c => moment(c).format("MM/DD/YYYY"));

  let grouped_data = {};

  // let full_data = data.sort(function(a, b) {
  //   return a.date > b.date ? 1 : a.date < b.date ? -1 : 0;
  // });
  const newData = sortedList(data);
  const arrangeData = arrangedData(newData);
 
  let full_data = arrangeData.sort(function(a, b) {
    return a.date > b.date ? 1 : a.date < b.date ? -1 : 0;
  });
  switch (options) {
    case "Equals":
      full_data = equalTo(full_data, groupByCategory, amount);

      break;
    case "Does Not Equal":
      full_data = doesNotEqual(full_data, groupByCategory, amount);
      break;
    case "Greater Than":
      full_data = greaterThan(full_data, groupByCategory, amount);
      break;
    case "Greater Than or Equal To":
      full_data = greaterThanorEqual(full_data, groupByCategory, amount);
      break;
    case "Less Than":
      full_data = lessThan(full_data, groupByCategory, amount);
      break;
    case "Less Than or Equal To":
      full_data = lessThanorEqual(full_data, groupByCategory, amount);
      break;
    case "Between":
      full_data = between(full_data, groupByCategory, balone, baltwo);
      break;

    default:
      break;
  }

  grouped_data = groupBy(full_data, groupByCategory);
  switch (collections) {
    case "top_collections":
      grouped_data = topData(grouped_data);
      break;
    case "bottom_collections":
      grouped_data = bottomData(grouped_data);
      break;
      case "80_collections":
        grouped_data = topEightyCollections(grouped_data);
        break;
    default:
      break;
  }
  // const customer_names = Object.keys(groupBy(full_data, "name"));
  // const categories = Object.keys(grouped_data);
  if (groupByCategory === "Day") {
    categories = cat;
  } else if (groupByCategory === "Week") {
    const c = dateArr.map(d => moment(d).week());
    categories = [...new Set(c)];
  } else if (groupByCategory === "Month") {
    const c = dateArr.map(d => moment(d).month() + 1);
    categories = [...new Set(c)];
  }

  const sum = sumOfDates(grouped_data, categories);
  const dates = setDates(cat, dateArr, groupByCategory);

  return [dates, sum];
};

// function for "Equals" Condition
export const equalTo = (fulldata, groupByCategory, amount) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  let equal = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }
    if (parseInt(sum) === parseInt(amount)) {
      a = arr;
    }
    equal = a.map(e => {
      return e;
    });

    sum = 0;
  }

  return equal;
};

// Function for topSeries
export const topData = groupeddata => {
  const obj = {};
  const data = [];

  for (const key in groupeddata) {
    const arr = groupeddata[key];
    arr.sort(function(obj1, obj2) {
      return obj2.amount - obj1.amount;
    });

    Object.assign(obj, { [key]: arr });
  }

  return obj;
};
export const topEightyCollections = groupeddata => {
  const obj = {};
  const data = [];

  for (const key in groupeddata) {
    const arr = groupeddata[key];
    arr.sort(function(obj1, obj2) {
      return obj2.amount - obj1.amount;
    });
    const x=parseInt((arr.length * 80)/100); 
  
    Object.assign(obj, { [key]:arr.slice(0,x) });
  }

  return obj;
};
// Function for bottomSeries
export const bottomData = groupeddata => {
  const obj = {};
  const data = [];

  for (const key in groupeddata) {
    const arr = groupeddata[key];
    arr.sort(function(obj1, obj2) {
      return obj1.amount - obj2.amount;
    });

    Object.assign(obj, { [key]: arr });
  }

  return obj;
};

export const between = (fulldata, groupByCategory, balone, baltwo) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  const range = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }

    if (parseInt(balone) <= parseInt(sum) && parseInt(baltwo) >= parseInt(sum)) {
      a = arr;
    }
    a.map(e => {
      if (!range.includes(e)) {
        range.push(e);
      }
    });

    sum = 0;
  }

  return range;
};

export const greaterThan = (fulldata, groupByCategory, amount) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  const greater = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }
    if (parseInt(sum) > parseInt(amount)) {
      a = arr;
    }
    a.map(e => {
      if (!greater.includes(e)) {
        greater.push(e);
      }
    });

    sum = 0;
  }

  return greater;
};
export const doesNotEqual = (fulldata, groupByCategory, amount) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  const doesNtEqul = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }
    if (parseInt(sum) !== parseInt(amount)) {
      a = arr;
    }
    a.map(e => {
      if (!doesNtEqul.includes(e)) {
        doesNtEqul.push(e);
      }
    });

    sum = 0;
  }

  return doesNtEqul;
};
export const lessThan = (fulldata, groupByCategory, amount) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  const less = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }
    if (parseInt(sum) < parseInt(amount)) {
      a = arr;
    }
    a.map(e => {
      if (!less.includes(e)) {
        less.push(e);
      }
    });

    sum = 0;
  }

  return less;
};
export const greaterThanorEqual = (fulldata, groupByCategory, amount) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  const greaterOrEqual = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }
    if (parseInt(sum) >= parseInt(amount)) {
      a = arr;
    }
    a.map(e => {
      if (!greaterOrEqual.includes(e)) {
        greaterOrEqual.push(e);
      }
    });

    sum = 0;
  }

  return greaterOrEqual;
};
export const lessThanorEqual = (fulldata, groupByCategory, amount) => {
  const groupeddata = groupBy(fulldata, groupByCategory);
  const lessorEqual = [];
  let a = [];
  let sum = 0;
  for (const key in groupeddata) {
    let obj = {};
    const arr = groupeddata[key];
    for (let i = 0; i < arr.length; i++) {
      obj = arr[i];
      sum += obj.amount;
    }
    if (parseInt(sum) <= parseInt(amount)) {
      a = arr;
    }
    a.map(e => {
      if (!lessorEqual.includes(e)) {
        lessorEqual.push(e);
      }
    });

    sum = 0;
  }

  return lessorEqual;
};
export const seriesFun = (
  data,
  groupByCategory,
  options,
  amount,
  balone,
  baltwo,
  collections,
  cname
) => {
  let series = [];
  let categories = [];

  // let full_data = data.sort(function(a, b) {
  //   return a.date > b.date ? 1 : a.date < b.date ? -1 : 0;
  // });
  const newData = sortedList(data);
  const arrangeData = arrangedData(newData);
  
  let full_data = arrangeData.sort(function(a, b) {
    return a.date > b.date ? 1 : a.date < b.date ? -1 : 0;
  });
  switch (options) {
    case "Equals":
      full_data = equalTo(full_data, groupByCategory, amount);

      break;
    case "Does Not Equal":
      full_data = doesNotEqual(full_data, groupByCategory, amount);
      break;
    case "Greater Than":
      full_data = greaterThan(full_data, groupByCategory, amount);
      break;
    case "Greater Than or Equal To":
      full_data = greaterThanorEqual(full_data, groupByCategory, amount);
      break;
    case "Less Than":
      full_data = lessThan(full_data, groupByCategory, amount);
      break;
    case "Less Than or Equal To":
      full_data = lessThanorEqual(full_data, groupByCategory, amount);
      break;
    case "Between":
      full_data = between(full_data, groupByCategory, balone, baltwo);
      break;
  }
  const byname = groupBy(full_data, "name");

  let grouped_data = groupBy(full_data, groupByCategory);
  switch (collections) {
    case "top_collections":
      grouped_data = topData(grouped_data);
      break;
    case "bottom_collections":
      grouped_data = bottomData(grouped_data);
      break;
    case "80_collections":
      grouped_data = topEightyCollections(grouped_data);
        break;

    default:
      break;
  }
  const obj = {};
  for (const key in grouped_data) {
    const arr = grouped_data[key];
    const sum = 0;
    const group = groupBy(arr, "name");
    obj[key] = group;
  }
  const newObj = {};
  const newNames = {};
  for (const key in obj) {
    const sample = [];
    for (const k in obj[key]) {
      sample.push(
        obj[key][k].reduce((a, b) => ({
          name: a.name,
          id: a.id,
          date: a.date,
          Day: a.Day,
          Week: a.Week,
          Month: a.Month,
          amount: a.amount + b.amount,
          newAmount: a.newAmount 
          
        }))
      );
      Object.assign(newNames, {
        [k]: [
          obj[key][k].reduce((a, b) => ({
            name: a.name,
            id: a.id,
            date: a.date,
            Day: a.Day,
            Week: a.Week,
            Month: a.Month,
            amount: a.amount + b.amount,
            newAmount: a.newAmount 
            
          }))
        ]
      });
    }
    newObj[key] = sample;
  }
  const newObject = {};
  
  for (const key in newObj) {
    if (newObj[key].length > 2) {
      const values = Object.values(newObj[key]).slice(0, 2);
      // let result1 = Object.values(newObj[key][values[0]][name])
      // let result2 = Object.values(newObj[key][values[1]][name])
      // let b = [];
      //Object.assign(newObject, { [values[i].name]: b });
      for (let i = 0; i < values.length; i++) {
        // Object.assign(newObject, { [values[i].name]: [...values[i], values[i]] });
        // console.log(values[i],b,"//values")
        if (newObject.hasOwnProperty(values[i].name)) {
          Object.assign(newObject, { [values[i].name]: [...newObject[values[i].name], values[i]]});
        } else {
          Object.assign(newObject, { [values[i].name]: [values[i]]});
        }
        
      }
      
    } else {
      const values = Object.values(newObj[key]);
      // let b = [];
      // Object.assign(newObject, { [values[i].name]: b });
      for (let i = 0; i < values.length; i++) {
        // Object.assign(newObject, { [values[i].name]: [...values[i], values[i]] });
        if (newObject.hasOwnProperty(values[i].name)) {
          Object.assign(newObject, { [values[i].name]: [...newObject[values[i].name], values[i]]});
        } else {
          Object.assign(newObject, { [values[i].name]: [values[i]]});
        }
      }
    }
  }
 
  // Object.assign(newNames, {'Other Collections': [{name: 'Other Collections', amount: 1000}]})

  const b = [];
  let i = 0;

  for (const key in newObj) {
    if (newObj[key].length > 2) {
      const date = key;
      let newDate = key;
      if (groupByCategory === "Day") {
        newDate = moment(date).format("MM/DD/YYYY");
      } else if (groupByCategory === "Month") {
        newDate = getMonthName(date);
      } else if (groupByCategory === "Week") {
        const beginningOfWeek = moment()
          .week(key)
          .startOf("week");
        const endOfWeek = moment()
          .week(key)
          .startOf("week")
          .add(6, "days");
        newDate = `${beginningOfWeek.format(" DD MMM")}-${endOfWeek.format(" DD MMM")}`;
      }
      b.push({
        name: `OtherCollections${i}`,
        id: "Other",
        amount: 100000,
        date: newDate,
        Week: key,
        Month: moment(date).month() + 1,
        Day: newDate,
        data: newObj[key].slice(2, newObj[key].length),
        newAmount: 10
      });
      i++;
    }
  }
  Object.assign(newNames, { OtherCollections: [...b] });
  Object.assign(newObject, { OtherCollections: [...b] });

  if (groupByCategory === "Day") {
    categories = cat;
  } else if (groupByCategory === "Week") {
    const c = dateArr.map(d => moment(d).week());
    categories = [...new Set(c)];
  } else if (groupByCategory === "Month") {
    const c = dateArr.map(d => moment(d).month() + 1);
    categories = [...new Set(c)];
  }

  Object.entries(newObject).map(([key, arr]) => {
    const d = [];
    const amt = [];
    const n = {};
    const m = {};
    const name = key;
    series.push({
      name: `${key}`,
      data: d,
      amount: amt
    });

    Object.entries(groupBy(arr, groupByCategory)).map(([key, arr]) => {
      const v = arr
        .map(a => a.newAmount)
        .reduce((a, b) => {
          return a + b;
        });
      m[key] = v;
      const f = arr
      .map(a => a.amount)
      .reduce((a, b) => {
        return a + b;
      });
    n[key] = f;
    });
   
    categories.map(c => {
      if (!m[c]) {
        
        d.push(0);
        amt.push(0);
      } else {
        
        d.push(m[c]);
        amt.push(n[c]);
      }
    });
  });
 

  return [series, newNames.OtherCollections, grouped_data];
};

export const getWeekRange = date => {
  let range = [];
  const d = moment(date);
  const weekNumber = d.week();
  const beginningOfWeek = moment()
    .week(weekNumber)
    .startOf("week");
  const endOfWeek = moment()
    .week(weekNumber)
    .startOf("week")
    .add(6, "days");
  range = `${beginningOfWeek.format(" DD MMM")}-${endOfWeek.format(" DD MMM")}`;

  return range;
};
export const getWeekNumber = date => {
  const range = [];
  const d = moment(date);
  const weekNumber = d.week();
  return weekNumber;
};
export const getMonthName = date => {
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "June",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  const monthnum = moment(date).month() + 1;
  return months[monthnum - 1];
};
export const getMonthNum = date => {
  const monthnum = moment(date).month() + 1;
  return monthnum;
};

export const sumOfDates = (groupeddata, categories) => {
  const sum = 0;
  const sumOfDates = [];

  Object.entries(groupeddata).map(([key, arr]) => {
    if( arr.length != 0) {
      const v = arr
      .map(a => a.amount)
      .reduce((a, b) => {
        return a + b;
      });
    m[key] = v;
    }
  });
    
   
  categories.map(c => {
    if (!m[c]) {
      sumOfDates.push(0);
    } else {
      sumOfDates.push(parseInt(m[c]));
    }
  });

  return sumOfDates;
};
export const getNames = (data, cname = []) => {
  const names = [];
  const ids = [];
  for (let i = 0; i < data.length; i++) {
    const obj = data[i];
    names.push({
      name: obj.name,
      id: obj.id
    });
  }
  const uniqueNames = Array.from(new Set(names.map(n => n.id))).map(id => {
    return {
      id,
      name: names.find(s => s.id === id).name
    };
  });

  const list = [];
  uniqueNames.map(n => {
    return list.push({
      name: n.name,
      id: n.id,
      isAdded: cname.includes(n.name) === true
    });
  });
console.log(list,"from getNames")
  return list;
};
export const getCustomerClusterNames = data => {
  const cids = [];
  let customers = [];
  const customerCluster = data.filter(item => item.type === "CUSTOMER");

  customerCluster.map(i => {
    customers = i.customers ? i.customers.map(c => c.name) : [];
    cids.push({
      id: i.id,
      title: `${i.name}(${customers.length})`,
      description: customers,
      customerlist: getCClusterNames(i)
    });
  });

  return cids;
};
export const getVendorClusterNames = data => {
  const cids = [];
  let vendors = [];
  const customerCluster = data.filter(item => item.type === "VENDOR");

  customerCluster.map(i => {
    vendors = i.vendors ? i.vendors.map(c => c.name) : [];
    cids.push({
      id: i.id,
      title: `${i.name}(${vendors.length})`,
      description: vendors,
      customerlist: getVClusterNames(i)
    });
  });

  return cids;
};

export const getCustomerNames = data => {
  const list = [];
  data.customers.map(d => {
    list.push({
      name: d.name,
      id: d.id,
      isAdded: false
    });
  });

  return list;
};
export const getCClusterNames = data => {
  const customers = [];
  if (data.hasOwnProperty("customers")) {
    data.customers.map(d => {
      customers.push({
        name: d.name,
        id: d.id,
        isAdded: true
      });
    });
  } else {
    data.customers = [];
  }

  return customers;
};
export const getVClusterNames = data => {
  const vendors = [];

  if (data.hasOwnProperty("vendors")) {
    data.vendors.map(d => {
      vendors.push({
        name: d.name,
        id: d.id,
        isAdded: true
      });
    });
  } else {
    data.vendors = [];
  }

  return vendors;
};
export const vendorClusterNames = data => {
  const vendors = [];

  data.map(d => {
    if (d.type === "VENDOR") {
      vendors.push({
        name: d.name,
        id: d.id,
        isAdded: false
      });
    }
  });

  return vendors;
};
export const customerClusterNames = data => {
  const customers = [];

  data.map(d => {
    if (d.type === "CUSTOMER") {
      customers.push({
        name: d.name,
        id: d.id,
        isAdded: false
      });
    }
  });

  return customers;
};
export const extractCustomerIdsFromCluster = data => {
  const ids = [];
  data.map(d => {
    if (d.type === "CUSTOMER") {
      if (d.hasOwnProperty("customers")) {
        ids.push(d.id);
      }
    }
  });
  return ids;
};
export const extractDataForCluster = (data, ids) => {
  data = data.filter(obj => ids.includes(obj.customer.id));

  return data;
};

export const extractDatatoShowTenCustomers = data => {
  data.map;
};

export const sortedList = list => {
  const keysSorted = list.sort(function(a, b) {
    return a.amount - b.amount;
  });
  return keysSorted;
};

export const arrangedData = ndata => {
  for (let i in ndata) {
    i = parseInt(i);
    let j = i;
    if (i < ndata.length - 1) {
      j += 1;
    }
    if (ndata[i].amount < ndata[j].amount) {
      ndata[j].newAmount = parseInt(ndata[i].newAmount) + 2;
    } else {
      ndata[j].newAmount = ndata[i].newAmount;
    }
  }
  return ndata;
};