import moment from "moment";
import datas from "../components/dashboardComponents/data/Customerdata.json";
import { extractData, groupBy } from "./newutil";

export const extractDays = dates => {
  //
  let data = [];
  const collections = [];
  data = datas.customers[datas.customers.length - 1].payment;

  for (let i = 0; i < data.length; i++) {
    const date = moment(data[i].date);
    const d = date.format("MM/DD/YYYY");
    collections.push({
      name: data[i].name,
      amount: parseInt(data[i].amount),
      date,
      Week: date.week(),
      Month: date.month() + 1,
      Day: data[i].date
    });
  }
  const coll = [];
  
  const ocollections = groupBy(collections, "Day");
 
  for (const key in ocollections) {
    const arr = ocollections[key];
    for (let i = 0; i < arr.length; i++) {
      const obj = arr[i];
      const dateOne = new Date(dates);
      const dateTwo = new Date(obj.Day);

      if (dateOne - dateTwo === 0) {
        coll.push(obj);
      }
    }
  }
 
  return coll;
};
export const categoryData = dates => {
  // const data = extractDays(dates);
  // const names = groupBy(data, "name");
  const customers = dates.map((i) => i);

  return customers;
};
export const seriesData = dates => {
  const data = extractDays(dates);
  const series = data.map(c => {
    return c.amount;
  });
  return series;
};
