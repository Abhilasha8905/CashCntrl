export const BASE_URL =
  "https://api-dev.cashcntrl.com/";

export const DATE = "01/10/2019";
export const FROM_DATE = "04/01/2019";
export const TO_DATE = "04/30/2019";
