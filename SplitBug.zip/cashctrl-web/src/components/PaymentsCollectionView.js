import React, { Component } from "react";
import styled from "styled-components";
import { ButtonGroup } from "react-bootstrap";

const TabButton = styled.button`
  padding: 8px 30px !important;
  outline: none !important;
  font-family: Montserrat;
  font-size: 12px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  background-color: #fff;
  border: none;
  margin-top: 0.5rem;
  &:active {
    color: #c94593;
  }
  &:focus {
    color: #c94593;
  }
`;
const ButtonGroupComponent = styled(ButtonGroup)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  color: black;
  float: left;
`;
const TabBody = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-bottom: 2%;
  padding-top: 1%;
`;

class PaymentCollection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tabSelected: "Payment"
    };
    this.onTabClick = this.onTabClick.bind(this);
  }

  onTabClick(event) {
    this.setState({
      tabSelected: event.target.id
    });
    this.props.selectedView(event.target.id);
  }

  render() {
    return (
      <TabBody>
        <ButtonGroupComponent>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="Payment"
            style={{
              borderBottom: this.state.tabSelected === "Payment" ? "4px solid #C94593" : null,
              color: this.state.tabSelected === "Customer" ? "#C94593" : "#2e2e2e",
              padding: "0px, 14px"
            }}
          >
            Payment
          </TabButton>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="Collection"
            style={{
              borderBottom: this.state.tabSelected === "Collection" ? "4px solid #C94593" : null,
              color: this.state.tabSelected === "Collection" ? "#C94593" : "#2e2e2e",
              padding: "0px, 14px"
            }}
          >
            Collection
          </TabButton>
        </ButtonGroupComponent>
      </TabBody>
    );
  }
}
export default PaymentCollection;
