import React from "react";
import { Draggable } from "react-drag-and-drop";
import styled from "styled-components";
import PropTypes from "prop-types";
import ListMenu from "../images/liquidity/ListMenu.png";
import ListMenuDragged from "../images/liquidity/ListMenuDragged.png";

const ListMenuIcon = styled.img.attrs({
  src: ListMenu
})`
  width: 14px;
  height: 14px;
  margin-left: 10px;
`;

const ListMenuDraggedIcon = styled.img.attrs({
  src: ListMenuDragged
})`
  width: 14px;
  height: 17px;
  margin-left: 10px;
`;

const Li = styled.li`
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
`;

export default class List extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedView: this.props.selectedView,
      isDragged: false,
      droppableStyle: {
        border: "solid",
        borderColor: "#FBFBFB",
        display: "flex",
        backgroundColor: "#fff",
        // marginTop: "-17px",
        flexDirection: "",
        // display: "none",
        marginBottom: "0px"
      },
      draggedDivStyle: {
        border: "solid",
        borderColor: "#FBFBFB",
        height: "40px",
        width: "100%",
        borderStyle: "",
        position: "absolute",
        top: "0px",
        zIndex: "2"
      },
      draggableData: this.props.items,
      dragged: false,
      dragEnter: false,
      liStyle: {
        border: "none",
        display: "",
        padding: ""
      }
    };
  }

  setDragImage() {
    return <ListMenuIcon />;
  }

  handleDrag() {
    this.setState({ isDragged: true });
  }

  onDragEnter() {
    this.setState({
      droppableStyle: {
        ...this.state.droppableStyle,
        display: "none"
      },
      dragged: true,
      dragEnter: true
    });
  }

  onDragStart(e) {
    const borderColor = this.state.selectedView === "Payment" ? "#FD8584" : "#419BF9";
    const color = this.state.selectedView === "Payment" ? "#FD8584" : "#419BF9";

    e.dataTransfer.setData("id", "1");

    this.setState({
      draggableData: { ...this.state.draggableData, date: "" },
      droppableStyle: {
        display: "contents",
        flexDirection: ""
      },
      // draggedDivStyle: {
      //   // height: "",
      //   // width: "90px",
      //   borderStyle: "dashed",
      //   borderWidth: "1.4px",

      //   borderColor: "green",
      //   opacity:1,
      // },
      liStyle: {
        display: "none",
        border: "none",

        padding: "0.5rem"
      }
    });
  }

  onDragOver() {
    this.setState({
      droppableStyle: {
        ...this.state.droppableStyle
        // display: "none"
      },

      draggableData: ""
    });
  }

  render() {
    const { items } = this.props;

    const draggableItems = this.state.draggableData;
    return (
      <div style={{ position: "relative" }}>
        <div style={{ backgroundColor: "red", position: "" }}>
          <ul
            className="list-group-horizontal"
            style={{
              border: "solid",
              borderColor: "#FBFBFB",
              display: "flex",
              backgroundColor: "#fff",
              marginBottom: "0px",
              border: items.status === "PARTIAL" && "1px solid #98999a",
              cursor: items.status !== "COMPLETE" && "pointer"

              // marginTop: "-17px"
            }}
          >
            <Li className="list-group-item" style={{ border: "none" }}>
              {items.status === "COMPLETE" ? <ListMenuDraggedIcon /> : <ListMenuIcon />}
            </Li>
            <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
              {items.age}
            </Li>
            <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
              {items.description}
            </Li>
            <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
              {items.amount} INR
            </Li>

            <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
              {items.invoiceNumber}
            </Li>
            <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
              {items.invoiceValue}
            </Li>
          </ul>
        </div>

        {items.status !== "COMPLETE" && (
          <Draggable
            type="row_item"
            data={JSON.stringify(items)}
            onDragEnd={this.handleDrag.bind(this)}
            onDragEnter={this.onDragEnter.bind(this)}
            onDragStart={this.onDragStart.bind(this)}
            draggable={this.state.dragged}
            onDragOver={this.onDragOver.bind(this)}
            style={this.state.draggedDivStyle}
            // wrapperComponent = {DraggableWrapper}
          >
            <ul className=" list-group-horizontal invisibleU" style={this.state.droppableStyle}>
              <Li className="list-group-item" draggable="false" style={this.state.liStyle}>
                {items.status === "COMPLETE" ? <ListMenuDraggedIcon /> : <ListMenuIcon />}
              </Li>
              <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
                {items.age}
              </Li>
              <Li className="list-group-item" draggable="false" style={{ border: "none" }}>
                {draggableItems.description}
              </Li>
              <Li className="list-group-item" draggable="false" style={this.state.liStyle}>
                {draggableItems.amount} INR
              </Li>
              <Li className="list-group-item" style={this.state.liStyle}>
                {draggableItems.invoiceNumber}
              </Li>
              <Li className="list-group-item" enabled="false" style={{ border: "none" }}>
                {draggableItems.invoiceValue}
              </Li>
            </ul>
          </Draggable>
        )}
      </div>
    );
  }
}

List.propTypes = {
  selectedView: PropTypes.bool.isRequired,
  elementDropped: PropTypes.bool.isRequired,
  items: PropTypes.array.isRequired
};
