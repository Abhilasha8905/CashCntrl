import React, { Component } from "react";
import styled from "styled-components";

import Modal from "./dashboardComponents/Modals/Modal";

const CalenderContainer = styled.div`
  position: absolute;
  width: 100%;
`;
const BackDrop = styled.div`
  background-color: rgba(42, 41, 41, 0.2),
  height: 100vh,
  position: fixed,
  top: 0,
  left: 0,
  width: 100%;
  
`;

class CreateNewScenario extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: ""
    };
  }

  addedScenarioName() {
    this.props.addedScenarioName(this.state.name);
  }

  render() {
    return (
      <CalenderContainer style={{ zIndex: "2" }}>
        <BackDrop style={{ zIndex: "2" }}>
          <Modal
            className="modal"
            title="Enter Scenario Name"
            show={this.props.isShowingModal}
            close={this.props.closeModalHandler}
            width="626px"
            height="100px"
            Customer
            Details
          >
            <input
              style={{ marginLeft: "0px" }}
              type="text"
              className="form-control"
              value={this.state.name}
              onChange={e => {
                this.setState({
                  name: e.target.value
                });
              }}
              placeholder="Enter Scenario Name"
            />
            <input type="submit" value="Submit" onClick={() => this.addedScenarioName()} />
          </Modal>
        </BackDrop>
      </CalenderContainer>
    );
  }
}
export default CreateNewScenario;
