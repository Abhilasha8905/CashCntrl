import React, { Component } from "react";
import styled from "styled-components";
import PropTypes from "prop-types";
import ExpandableList from "./ExpandableList";
import DropdownIcon from "../images/header/DropDownIcon.png";


const DropDownIcon = styled.img.attrs({
  src: DropdownIcon
})`
  width: 8px;
  height: 4.7px;
  margin-left: 10px;
  opacity: 0.5;
`;

const Li = styled.li`
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
`;
class ExpandableListView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isExpndable: false,
      selectedView: this.props.selectedView
    };
  }

  handleRowClick() {
    this.setState({ isExpndable: !this.state.isExpndable });
  }

  render() {
    return (
      <div style={{height:"100%"}}>
        <ul
          className="list-group list-group-horizontal"
          style={{
            boxShadow: " 0 4px 4px 0 rgba(0, 0, 0, 0.05)",
            borderRadius: "2px",
            border: "solid",
            borderColor: "#FBFBFB",
            listStyle: "none",
            display: "flex",
            backgroundColor: "white",
            marginTop: "-13px"
          }}
          onClick={this.handleRowClick.bind(this)}
        >
          {/* <li className="list-group-item" style={{ border: "none" }}>
            <DropDownIcon />
          </li>
          <Li className="list-group-item" style={{ border: "none" }}>
          </Li> */}
        </ul>
        {/* {this.state.isExpndable && ( */}
        <ExpandableList
          data={this.props.data}
          selectedView={this.state.selectedView}
          elementDropped={this.props.elementDropped}
        />
        {/* )} */}
      </div>
    );
  }
}

export default ExpandableListView;

ExpandableListView.propTypes = {
  selectedView: PropTypes.bool.isRequired,
  elementDropped: PropTypes.bool.isRequired,
  data: PropTypes.array.isRequired,
  aging: PropTypes.array.isRequired
};
