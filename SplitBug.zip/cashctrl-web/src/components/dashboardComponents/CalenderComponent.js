import React, { Component } from "react";
import styled from "styled-components";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faRupeeSign } from "@fortawesome/free-solid-svg-icons";

import Modal from "./Modals/Modal";
import "react-big-calendar/lib/css/react-big-calendar.css";
import "./style.css";

const localizer = momentLocalizer(moment);

const CalenderContainer = styled.div`
  position: fixed;
  width: 100%;
  left: 0px;
  right: 0px;
  margin: 0 auto;
  top: 0px;
  height: 100%;
  display: flex;
  z-index: 9999999;
  background: rgba(0, 0, 0, 0.4);
`;

const BackDrop = styled.div`
  background-color: rgba(42, 41, 41, 0.2),
  height: 100vh,
  position: fixed,
  top: 0,
  left: 0,
  width: 100% !important,
`;

class CalenderComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <CalenderContainer>
        <BackDrop className="calenderView">
          <Modal
            className="modal"
            show={this.props.isShowingModal}
            close={this.props.closeModalHandler}
            width="63%"
            height="auto"
            title="Calender"
            titleBorder
          >
            <Calendar
              style={{ height: 500, backgroundColor: "#ffffff" }}
              localizer={localizer}
              events={this.props.events}
              startAccessor="start"
              endAccessor="end"
              views={["month", "day", "week"]}
              eventPropGetter={(event, start, end, isSelected) => {
                const newStyle = {
                  backgroundColor: "lightgrey",
                  color: "black",
                  borderRadius: "0px",
                  border: "none"
                };
                if (event.isDue) {
                  newStyle.backgroundColor = "rgba(201, 69, 147, 0.5)";
                }
                return {
                  className: "",
                  style: newStyle
                };
              }}
              titleAccessor={event => {
                return (
                  <div>
                    <div>
                      <FontAwesomeIcon icon={faRupeeSign} /> {event.title}
                    </div>
                  </div>
                );
              }}
            />
          </Modal>
        </BackDrop>
      </CalenderContainer>
    );
  }
}

export default CalenderComponent;
