import React, { Component } from "react";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes, faCommentsDollar } from "@fortawesome/free-solid-svg-icons";
import FilterCheckList from "./ClusterInflowFilter";

const ModalContainer = styled.div`
  display: flex;
  justify-content: center;
`;

const ModalHeading = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 2%;
  border-bottom: 1px solid #eaf0f3;
  border-radius: 3px;
`;

const ModalContent = styled.div`
  flex-direction: row;
  display: -webkit-box;
  margin: 1%;
`;

const FilterContainer = styled.div`
  width: 50%;
  border-right: 1px solid #eaf0f3;
`;

const DisplayCluster = styled.div`
  position: relative;
  width: 50%;
  flex-direction: column;
  padding: 1%;
`;

const ClusterContainer = styled.div`
  position: absolute;
  width: 65%;
  background-color: #ffffff;
  box-shadow: 4px 5px 7px 0 rgba(0, 0, 0, 0.3);
  height: auto;
`;

const Button = styled.button`
  position: absolute;
  bottom: 10px;
  background-color: ${props => (props && props.color ? props.color : "")};
  width: 40%;
  border: none;
  color: white;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  float: left;
`;

const StyledInput = styled.input`
  font-size: 14px;
  padding: 12px 20px 12px 40px;
  border: none;
  margin-bottom: 12px;
  outline: none;
  border: 1px solid lightgrey;
  width: 100%;
  margin-left: 1%;
`;

const Title = styled.span`
  height: 17px;
  font-family: Montserrat;
  font-size: 14px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.21;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

const SelectedClusterDisplay = styled.div`
  background-color: rgba(234, 240, 243, 0.5);
  padding: 12px 20px 35px 40px;
  margin: 1%;
  width: 100%;
`;
const Input = styled.input`
  border: none;
  width: 100%;
  padding: 0px 25px;
  outline: none !important;
`;
const SubHeading = styled.p`
  font-family: Montserrat;
  font-size: 13px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: black;
  opacity: 1;
`;

const Description = styled.span`
  opacity: 0.5;
  font-family: Montserrat;
  font-size: 12px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  margin: 1%;
`;

const ClusterList = styled.span`
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.5;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

class CreateCluster extends Component {
  constructor(props) {
    super(props);
    this.state = {
      customerlist: this.props.itemSelected
        ? this.props.itemSelected.customerlist
        : this.props.customerlist,
      clusterName: this.props.itemSelected ? this.props.itemSelected.description : [],
      name: this.props.itemSelected ? this.props.itemSelected.title.split("(")[0] : []
    };
    this.updateName = this.updateName.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
  }

  updateName(event) {
    this.setState({ name: event.target.value });
  }

  clusterCreation() {
    if (!this.props.itemSelected) {
      if (this.props.tabSelected === "Customer") {
        this.props.createNewCustomerCluster(this.props.customerIds, this.state.name);
      } else {
        this.props.createNewVendorCluster(this.props.customerIds, this.state.name);
      }
    } else if (this.props.tabSelected === "Customer") {
      this.props.editCustomerCluster(
        this.props.itemSelected.id,
        this.state.name,
        this.props.customerIds
      );
    } else {
      this.props.editVendorCluster(
        this.props.itemSelected.id,
        this.state.name,
        this.props.customerIds
      );
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.customer.isAdded) {
      this.setState({
        clusterName: [...this.state.clusterName, nextProps.customer.name]
      });
    } else if (!nextProps.customer.isAdded) {
      const newCluster = this.state.clusterName.filter(x => {
        return x != nextProps.customer.name;
      });
      this.setState({
        clusterName: newCluster
      });
    }
   
    if (
      this.state.customerlist.length === 0 ||
      this.state.customerlist.length !== nextProps.customerlist.length
    ) {
      this.setState({
        customerlist: nextProps.customerlist
      });
    }
  }

  handleClose() {
    this.setState({
      clusterName: []
    });
    this.props.clearCustomers();
    this.props.closeModalHandler();
  }

  handleCreate() {
    this.setState({
      clusterName: []
    });
    this.props.clearCustomers();
    this.props.closeModalHandler();
    this.clusterCreation();
  }

  render() {
    return (
      <ModalContainer>
        <ClusterContainer>
          <ModalHeading>
            <Title>Create Customer Cluster</Title>
            <span onClick={() => this.handleClose()}>
              <FontAwesomeIcon icon={faTimes} />
            </span>
          </ModalHeading>
          <ModalContent>
            <FilterContainer>
              <FilterCheckList
                customerListInflow={this.props.customerListInflow}
                showButton={false}
                customerlist={
                  this.props.itemSelected
                    ? [...this.props.itemSelected.customerlist, ...this.props.customerlist]
                    : this.props.customerlist
                }
                selectedItems={
                  this.props.itemSelected ? [...this.props.itemSelected.customerlist] : []
                }
                customer={this.props.customer}
                removeExistingIds={this.props.removeExistingIds}
              />
            </FilterContainer>
            <DisplayCluster>
              <SubHeading>Cluster Name</SubHeading>
              <Input
                value={this.state.name}
                placeholder="Cluster Name"
                onChange={this.updateName.bind(this)}
              />
              <Description>
                {this.state.clusterName.length}{" "}
                {this.props.tabSelected === "Customer" ? "Customers selected" : "vendors selected"}{" "}
              </Description>
              <SelectedClusterDisplay>
                {this.state.clusterName.map(c => (
                  <ClusterList> {c} </ClusterList>
                ))}
              </SelectedClusterDisplay>
              <div style={{ marginLeft: "1%" }}>
                <Button
                  disabled={
                    !(
                      (!this.props.itemSelected && this.state.clusterName.length > 0) ||
                      (this.props.itemSelected &&
                        this.state.clusterName.length > 0 &&
                        JSON.stringify(this.props.itemSelected.description) !==
                          JSON.stringify(this.state.clusterName))
                    )
                  }
                  color={
                    (!this.props.itemSelected && this.state.clusterName.length > 0) ||
                    (this.props.itemSelected &&
                      this.state.clusterName.length > 0 &&
                      JSON.stringify(this.props.itemSelected.description) !==
                        JSON.stringify(this.state.clusterName))
                      ? "mediumvioletred"
                      : ""
                  }
                  onClick={() => this.handleCreate()}
                >
                  Create
                </Button>
              </div>
            </DisplayCluster>
          </ModalContent>
        </ClusterContainer>
      </ModalContainer>
    );
  }
}

export default CreateCluster;
