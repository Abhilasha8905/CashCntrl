import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";
import { connect } from "react-redux";

class WrapperChartInflow extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      position: "relative",
      isTrue: true,
      dates: [],
      series: [],
      options: {
        chart: {
          stacked: true,
          toolbar: {
            show: false
          },
          zoom: {
            enabled: true
          }
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              legend: {
                position: "bottom",
                offsetX: -10,
                offsetY: 0
              }
            }
          }
        ],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "30%"
          }
        },
        stroke: {
          width: 1
        },
        grid: {
          show: true,
          borderColor: "#90A4AE",
          strokeDashArray: 0,
          position: "front",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          },
          padding: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
          }
        },
        dataLabels: {
          enabled: false,
          hideOverflowingLabels: true
        },

        xaxis: {
          axisTicks: {
            show: false
          },
          axisBorder: {
            show: false
          },
          labels: {
            formatter(value) {
              return value;
            },
            style: {
              color: "#87CEEB"
            }
          },
          categories: [...this.props.sum]
        },
        legend: {
          show: false
        },
        fill: {
          opacity: 1
        },
        colors: [
          "#003f5c",
          "rgba(0, 63, 92, 0.7)",
          "#58508d",
          "#c94593",
          "rgba(200,68,146,0.5)",
          "#ff6361",
          "#ffa600",
          "#707070"
        ],
        yaxis: {
          show: true,

          tickAmount: 6,
          min: 0,
          max: 60,
          labels: {
            formatter(value) {
              return `${value}K`;
            },
            style: {
              opacity: 0,
              color: "#ffffff"
            }
          },
          axisBorder: {
            show: false,
            color: "#78909C",
            offsetX: -8,
            offsetY: 3
          }
        },

      },

      series: []
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState(prevState => ({
      ...prevState,
      options: {
        ...prevState.options,
        xaxis: {
          ...prevState.options.xaxis,
          categories: nextProps.sum
        }
      }
    }));
  }

  render() {
    const chartWidth = this.props.sum.length > 25 ? 100 * this.props.sum.length : "100%";

    return (
      <div
        id="chart"
        style={{ transform: "translateY(-27%)", marginTop: "-13px", marginLeft: "0px",position:"relative",background:"white" }}
      >
        <ReactApexChart
          options={this.state.options}
          series={this.state.series}
          type="bar"
          height="40"
          width={chartWidth}
        />
      </div>
    );
  }
}
export default WrapperChartInflow;
