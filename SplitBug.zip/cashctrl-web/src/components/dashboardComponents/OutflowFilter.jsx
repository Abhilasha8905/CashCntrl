import React from "react";
import styled from "styled-components";
import { Container, Row, Col } from "react-bootstrap";
import CustomerExpenseComponent from "./CustomerExpenseComponentOutflow";
// import { ButtonGroup, Button } from 'react-bootstrap';

const ButtonStyle = styled.button`
  background-color: #ffffff;
  border: 1px solid transparent;
  box-sizing: border-box;
  box-shadow: none;
  font-size: 12px;
  font-weight: 500;
  padding: 5px 10px;
  border-radius: 2px;
  white-space: nowrap;
  text-align: center;
  &:focus {
    outline: none !important;
  }
  &:active {
    -webkit-transition: 0.5s all ease;
    transition: 0.5s all ease;
  }
`;
const ColNoPadding = styled.div`
padding-right:0;
padding-left:0;
}`;
/* const ActiveClass=styled.div`
content: '';
display: block;
border:1px solid rgb(0,0,0)
&:active {
    -webkit-transition: 1s all ease;
        transition: 1s all ease;
}
` */
const Line = styled.div`
  opacity: 0.04;
  border: solid 1px var(--black);
  margin-left: -14%;
  margin-top: 1.5%;
  margin-right: -5%;
`;

class OutflowFilter extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      tabSelected: props.buttonOne

      // second:false,
    };
    this.onTabClick = this.onTabClick.bind(this);
  }

  onTabClick(event) {
    this.setState({
      tabSelected: event.target.id
    });
    if (event.target.id === "Cluster View") {
      this.props.getClusterData();
    } else {
      this.props.outflowUpdate();
    }
  }

  render() {
    return (
      <Container fluid style={{ border:"1px solid rgb(235, 235, 235)",borderBottom:"0" }}>
        <Row
          style={{
            backgroundColor: "rgb(248, 249, 251)",
            display: "flex",
            flexFlow: "row nowrap",
            paddingBottom: "11px",
            paddingTop: "11px",
            justifyContent: "center",
            borderBottom: "1px solid rgb(235, 235, 235)"
          }}
        >
          <ColNoPadding>
            <ButtonStyle
              type="button"
              onClick={event => this.onTabClick(event)}
              id={this.props.buttonOne}
              style={{
                backgroundColor:
                  this.state.tabSelected === this.props.buttonOne ? "#ffffff" : "#fbfcfe",
                border:
                  this.state.tabSelected === this.props.buttonOne
                    ? "solid 1px rgb(201,69,147,0.6)"
                    : "",
                color:
                  this.state.tabSelected === this.props.buttonOne ? "#c94593" : "rgb(0,0,0,0.5)"
              }}
            >
              {this.props.buttonOne}
            </ButtonStyle>
          </ColNoPadding>
          <ColNoPadding>
            <ButtonStyle
              type="button"
              onClick={event => this.onTabClick(event)}
              id={this.props.buttonTwo}
              style={{
                backgroundColor:
                  this.state.tabSelected === this.props.buttonTwo ? "#ffffff" : "#fbfcfe",
                border:
                  this.state.tabSelected === this.props.buttonTwo
                    ? "solid 1px rgb(201,69,147,0.6)"
                    : "",
                color:
                  this.state.tabSelected === this.props.buttonTwo ? "#c94593" : "rgb(0,0,0,0.5)"
              }}
            >
              {this.props.buttonTwo}
            </ButtonStyle>{" "}
            <br />
          </ColNoPadding>
        </Row>
        <CustomerExpenseComponent
          tabSelected={this.state.tabSelected}
          buttonOne={this.props.buttonOne}
          buttonTwo={this.props.buttonTwo}
          customerFilterOutflow={this.props.customerFilterOutflow}
          data={this.props.data}
          fromDate={this.props.fromDate}
          toDate={this.props.toDate}
          datefilter={this.props.datefilter}
          cname={this.props.cname}
          productsList={this.props.productsList}
          initialList={this.props.initialList}
          vendorclusterNames={this.props.vendorclusterNames}
          outflowUpdate={this.props.outflowUpdate}
          vendorClusterData={this.props.vendorClusterData}
        />
      </Container>
    );
  }
}
export default OutflowFilter;
