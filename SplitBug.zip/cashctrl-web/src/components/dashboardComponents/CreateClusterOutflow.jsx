import React, { Component } from "react";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes } from "@fortawesome/free-solid-svg-icons";

import FilterCheckList from "./FilterCheckListOutflow";

const ModalContainer = styled.div`
  display: flex;
  justify-content: center;
`;

const ModalHeading = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 2%;
  border-bottom: 1px solid #eaf0f3;
  border-radius: 3px;
`;

const ModalContent = styled.div`
  flex-direction: row;
  display: -webkit-box;
  margin: 1%;
`;

const FilterContainer = styled.div`
  width: 50%;
  border-right: 1px solid #eaf0f3;
`;

const DisplayCluster = styled.div`
  width: 50%;
  flex-direction: column;
  padding: 1%;
`;

const ClusterContainer = styled.div`
  position: absolute;
  width: 65%;
  background-color: #ffffff;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
  height: auto;
`;

const Button = styled.button`
  background-color: mediumvioletred;
  width: 40%;
  border: none;
  color: white;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  float: left;
`;

const StyledInput = styled.input`
  font-size: 14px;
  padding: 12px 20px 12px 40px;
  border: none;
  margin-bottom: 12px;
  outline: none;
  border: 1px solid lightgrey;
  width: 100%;
  margin-left: 1%;
`;

const Title = styled.span`
  height: 17px;
  font-family: Montserrat;
  font-size: 14px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.21;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

const SelectedClusterDisplay = styled.div`
  background-color: rgba(234, 240, 243, 0.5);
  padding: 12px 20px 35px 40px;
  margin: 1%;
  width: 100%;
`;

const SubHeading = styled.p`
  font-family: Montserrat;
  font-size: 13px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: black;
  opacity: 1;
`;

const Description = styled.span`
  opacity: 0.5;
  font-family: Montserrat;
  font-size: 12px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  margin: 1%;
`;

const ClusterList = styled.span`
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.5;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

class CalenderComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    // this.displaySelectedCluster = this.displaySelectedCluster.bind(this);
  }

  render() {
    // const ClusterList = 
    return (
      <ModalContainer>
        <ClusterContainer>
          <ModalHeading>
            <Title>Create Vendor Cluster</Title>
            <span onClick={() => this.props.closeModalHandler()}>
              <FontAwesomeIcon icon={faTimes} />
            </span>
          </ModalHeading>
          <ModalContent>
            <FilterContainer>
              <FilterCheckList boxShadow="none" showButton={false} height="35vh" />
            </FilterContainer>
            <DisplayCluster>
              <SubHeading>Cluster Name</SubHeading>
              <StyledInput id="myInput" placeholder="" title="Type in a name" />
              <Description>3 vendors selected</Description>
              <SelectedClusterDisplay>
                <ClusterList>Joseph Enterprises, {" "}</ClusterList>
                <ClusterList>Joseph Enterprises, {" "}</ClusterList>
                <ClusterList>Joseph Enterprises</ClusterList>
              </SelectedClusterDisplay>
              <div style={{ marginLeft: "1%" }}>
                <Button>Create</Button>
              </div>
            </DisplayCluster>
          </ModalContent>
        </ClusterContainer>
      </ModalContainer>
    );
  }
}

export default CalenderComponent;
