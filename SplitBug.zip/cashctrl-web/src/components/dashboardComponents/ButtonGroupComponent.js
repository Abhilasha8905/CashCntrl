import React, { Component } from "react";
import styled from "styled-components";
import { Row, Col } from "react-bootstrap";

const Button = styled.button`
  background-color: #eaf0f3;
  border: none;
  border-radius: 0;
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.36;
  letter-spacing: normal;
  text-align: center;
  color: var(--black);
  opacity: 0.7;
  padding: 7px;
  width: ${props => (props && props.width ? props.width : "60px")};
  border-radius: 2px;
  outline: none !important;
  &:hover ${Button} {
    background-color: #fbfcfe;
    border: 2px solid #c94593;
    color: #c94593;
    border-radius: 2px;
  }
  &:active ${Button} {
    background-color: #ffffff;
    border: 2px solid #c94593;
    color: #c94593;
    border-radius: 2px;
  }
  &:focus ${Button} {
    background-color: #ffffff;
    border: 2px solid #c94593;
    color: #c94593;
    border-radius: 2px;
  }
`;

class ButtonGroupComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedItem: this.props.datefilter
    };
    this.handleButtonClick = this.handleButtonClick.bind(this);
  }

  handleButtonClick(event) {
    this.setState({
      selectedItem: event.target.id
    });
    this.props.onButtonSelect(event.target.id);
  }

  render() {
    const { values, width } = this.props;
    const showButtons = values.map(value => {
      return (
        <Button
          type="button"
          id={value}
          width={width}
          style={{
            border: this.state.selectedItem === value ? "2px solid #c94593" : "none",
            backgroundColor: this.state.selectedItem === value ? "#ffffff" : " #eaf0f3"
          }}
          onClick={() => this.handleButtonClick(event)}
        >
          {" "}
          {value}{" "}
        </Button>
      );
    });
    return (
      <Row>
        <Col
          style={{
            display: "flex",
            flexFlow: "row",
            flexWrap: "nowrap",
            paddingLeft: "0px",
            paddingRight: "0px"
          }}
        >
          {showButtons}
        </Col>
      </Row>
    );
  }
}

export default ButtonGroupComponent;
