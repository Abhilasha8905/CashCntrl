import React from "react";

import styled from "styled-components";
import { connect } from "react-redux";
import FilterCheckListOutflow from "./FilterCheckListOutflow";

import { getNames } from "../../utility/newutil";
import { customerFilterOutflow, filterList } from "../../actions/OutFlowActions";

const Paragraph = styled.p`
  margin-top: 15px;
  margin-bottom: 15px;
  opacity: 1;
  padding: 10px 0px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  margin-left: 0px;
`;
class CustomerExpenseComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      productList: []
    };
  }

  render() {
    return (
      <div className="filtertable">
        {this.props.tabSelected === this.props.buttonOne ? (
          <div className="filterlist">
            {" "}
            <Paragraph>
              <img
                src={require("../.././images/dashboard/filter.svg")}
                style={{ marginLeft: "0", marginRight: "7px", height: "14px", opacity: "1" }}
              />
              Filter by {this.props.buttonOne}
            </Paragraph>
            <FilterCheckListOutflow
              initialList={this.props.initialList}
              showButton
              customerFilterOutflow={this.props.customerFilterOutflow}
              data={this.props.data}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              datefilter={this.props.datefilter}
              cname={this.props.cname}
              productsList={this.props.productsList}
              initialList={this.props.initialList}
              outflowUpdate={this.props.outflowUpdate}
              customerClusterData={this.props.vendorClusterData}
            />{" "}
          </div>
        ) : (
          <div className="filterlist">
            {" "}
            <Paragraph>
              <img
                src={require("../.././images/dashboard/filter.svg")}
                style={{ marginLeft: "0", marginRight: "6px", opacity: "1", height: "14px" }}
              />
              Filter by {this.props.buttonTwo}
            </Paragraph>{" "}
            <FilterCheckListOutflow
              productList={this.state.productList}
              showButton
              customerFilterOutflow={this.props.customerFilterOutflow}
              data={this.props.data}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              datefilter={this.props.datefilter}
              cname={this.props.cname}
              tabSelected={this.props.tabSelected}
              outflowUpdate={this.props.outflowUpdate}
              productsList={this.props.vendorclusterNames}
              initialList={this.props.initialList}
              customerClusterData={this.props.vendorClusterData}
            />
          </div>
        )}
      </div>
    );
  }
}

export default CustomerExpenseComponent;
