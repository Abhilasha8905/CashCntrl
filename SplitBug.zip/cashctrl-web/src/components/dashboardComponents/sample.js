import { connect } from "react-redux";
import React, { Component } from "react";
import { Button } from "react-bootstrap";
import TestComponent from "./InflowFilter";
import Dashboard from "./DashboardScreen";
// Presentational component
class MyComponent extends Component {
  render() {
    return <Dashboard />;
  }
}
// state: our state is passed as the first argument here
const mapStateToProps = (state, ownProps) => {};
// actions: Redux's dispatch function is passed as the first argument here
const mapDispatchToProps = (dispatch, ownProps) => {};
// defining the Container component, passing the above 2 functions into Redux's connect().
export const MyComponentContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(MyComponent);
export default MyComponentContainer;
