import React from "react";
import styled from "styled-components";

const Button = styled.button`
  width: 159px;
  height: 31px;
  border: none;
  background-color: var(--darkish-pink);
  font-family: Nunito;
  font-size: 13px;
  font-weight: 400;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  color: #ffffff;
  border: none;
  box-shadow: none;
  cursor: pointer;
  visibility: ${props =>
    props.tabSelected === "inflows" || props.tabSelected === "outflows" ? "visible" : "hidden"};
`;

class ClusterButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.sayHello = this.sayHello.bind(this);
  }

  sayHello(event) {
    this.props.clustorView();
  }

  render() {
    return (
      <Button
        className="button"
        tabSelected={this.props.tabSelected}
        onClick={this.sayHello}
        style={{ float: "right" }}
      >
        {!this.props.buttonName && (
          <img src={this.props.image} style={{ marginLeft: "0", marginRight: "0.5rem" }} />
        )}
        {this.props.buttonName ? this.props.buttonName : this.props.name}
      </Button>
    );
  }
}
export default ClusterButton;
