import "./table.css";
import React from "react";
import data from "../data/data.json";
class Tabledata extends React.Component {
  constructor(props) {
    super(props); //since we are extending class Table so we have to use super in order to override Component class constructor
    this.state = {
      //state is by default an object
      jsondata: data
    };
  }
  renderTableData() {
    return this.state.jsondata.map((data, index) => {
      const {
        Slno,
        Checkno,
        Drawn_on,
        In_Favour_of,
        bank,
        Amount,
        Currency
      } = data; //destructuring
      return (
        <tr key={Slno}>
          <td>{Slno}</td>
          <td>{Checkno}</td>
          <td>{Drawn_on}</td>
          <td>{In_Favour_of}</td>
          <td>{bank}</td>
          <td>{Amount}</td>
          <td>{Currency}</td>
        </tr>
      );
    });
  }
  renderTableHeader() {
    let header = Object.keys(this.state.jsondata[0]);
    return header.map((key, index) => {
      return <th key={index}>{key.toUpperCase()}</th>;
    });
  }

  render() {
    return (
      <div>
        <h1 id="title">React Dynamic Table</h1>
        <table id="students" className="table">
          <tbody>
            <tr>{this.renderTableHeader()}</tr>
            {this.renderTableData()}
          </tbody>
        </table>
      </div>
    );
  }
}

export default Tabledata;
