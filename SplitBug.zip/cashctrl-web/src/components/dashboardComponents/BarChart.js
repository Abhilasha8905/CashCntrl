import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";
import _ from "lodash";
import moment from "moment-timezone";
import datas from "./data/Customerdata.json";
import { categoryData, seriesData } from '../../utility/OtherCollectionsutility';

class BarChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      options: {
        chart: {
          type: "bar",
          stacked: true,
          toolbar: {
            show: false
          },
          events: {
            dataPointSelection: (event, chartContext, config) => {
              const seriesName = config.w.config.series[config.seriesIndex];
              const dateIndex = config.w.config.xaxis.categories[config.dataPointIndex];
              const i = moment(dateIndex).format("MM/DD/YYYY");
              // let ids=seriesName.name.split('/');
              // let id= ids[1] === "Other" ? ids[1] : parseInt(ids[ids.length-1])
              // this.props.openModalHandler(id);
              this.handleDataClick(dateIndex);
            }
          }
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              legend: {
                position: "bottom",
                offsetX: -10,
                offsetY: 0
              }
            }
          }
        ],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '20%',
            dataLabels: {
              position: "top",
            }
          }
        },
        dataLabels: {
          enabled: false,
          textAnchor: "middle",
          offsetY: '-1px',
          style: {
            colors: ["#58508d"],
            fontSize:'14px',
            fontWeight:'600'
          },
          formatter(val, opt) {
            return parseFloat(val).toFixed(2) + 'Lacs';
          },
          dropShadow: {
            enabled: false
          }
        },
        stroke: {
          width: 1
        },
        grid: {
          show: true,
          borderColor: "#fffff",
          strokeDashArray: 0,
          position: "back",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          }
        },
        

        xaxis: {
          show: true,
          axisBorder: {
            show: false,
            color: "#78909C",
            height: 1,
            width: "100%",
            offsetX: 0,
            offsetY: 0
          },
          labels: {
            formatter(value) {
              return `${value}`;
            }
          },
          axisTicks: {
            show: false
          },

          categories: [...this.props.name] 
          // formatter: function(value, timestamp) {
          //   return new Date(timestamp); // The formatter function overrides format property
          // }
        },
        legend: {
          show: false
        },
        fill: {
          opacity: 1
        },
        colors: "#58508d",

        yaxis: {
          show: true,

          labels: {
            formatter(value) {
              return `${parseFloat(value).toFixed(2)}`;
            }
          },
          axisBorder: {
            show: true,
            color: "#78909C",
            offsetX: -8,
            offsetY: 4
          }
        },
      }
  }
  this.handleDataClick = this.handleDataClick.bind(this);
}
  componentWillReceiveProps(nextProps) {
    this.setState(prevState => ({
      ...prevState,
      options: {
        ...prevState.options,
        xaxis: {
          ...prevState.options.xaxis,
          categories: nextProps.name
        }
      }
    }));
    
  }
  
  handleDataClick(seriesName) {
    let data = this.props.data[0].data.filter((i) => i.name === seriesName);
    this.props.closeModalHandler(false, data[0].id);
  }

  render() {
    const series = [{
      name: 'Collections',
      data: [...this.props.series]
    }];
    return (
      <div id="chart" style={{height:"80%",overflowY:"auto"}}>
        <ReactApexChart
          options={this.state.options}
          series={series}
          type="bar"
          height="400"
        />
      </div>
    );
  }
}

export default BarChart;