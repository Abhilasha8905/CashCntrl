import React, { Component } from "react";
import { Container, Row, Col, CardDeck } from "react-bootstrap";
import CardComponent from "./CardComponent";

class CardContainer extends Component {
  render() {
    const cashData = {
      banks: {
        title: "Bank Balance",
        amount: this.props.bankBalance,
        linkTitle: "Accounts linked"
      },
      cheques: {
        title: "Cheques not cleared",
        amount: this.props.ciClear - this.props.cnClear,
        linkTitle: "( click here for details )"
      },
      pdcs: {
        title: "PDCs issued",
        amount: this.props.pdcIssue,
        linkTitle: "( click here for details )"
      },
      cashbalance: {
        title: "Cash Balance",
        amount: this.props.cashBalance,
        linkTitle: ""
      }
    };

    return (
      <Row
        style={{
          marginBottom: "20px",
          marginLeft: "-10px",
          marginRight: "-10px"
        }}
      >
        <CardComponent
          openModalHandler={() => {
            this.props.openModalHandler("bankBalance", "Accounts Linked", "rgba(201, 69, 147)");
          }}
          cashData={cashData.banks}
          color="rgba(201, 69, 147, 0.5)"
          image={require("../../images/dashboard/bank-building.svg")}
        />
        <CardComponent
          openModalHandler={() => {
            this.props.openModalHandler("cnClear", "Cheques not cleared", "rgba(255, 166, 0)");
          }}
          cashData={cashData.cheques}
          color="rgba(255, 166, 0, 0.4)"
          image={require("../../images/dashboard/cheque.svg")}
          opacity="1"
          width="40%"
        />
        <CardComponent
          openModalHandler={() => {
            this.props.openModalHandler("pdcIssue", "PDC's Issued", "rgba(46, 172, 255)");
          }}
          cashData={cashData.pdcs}
          color="rgba(46, 172, 255, 0.4)"
          image={require("../../images/dashboard/cheque.svg")}
          opacity="1"
          width="40%"
        />
        <CardComponent
          openModalHandler={() => {
            this.props.openModalHandler("cashBalance");
          }}
          cashData={cashData.cashbalance}
          color="rgba(32, 225, 45, 0.4)"
          image={require("../../images/dashboard/funds.svg")}
        />
      </Row>
    );
  }
}

export default CardContainer;
