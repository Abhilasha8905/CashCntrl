import React, { Component } from "react";
import styled from "styled-components";
import Modal from "./Modals/Modal";
import Bar from "./BarChart";

const CalenderContainer = styled.div`
position: fixed;
width: 100%;
left: 0;
right: 0;
margin: 0 auto;
top: 0px;
background: rgba(0,0,0,0.4);
z-index: 9999999;
height: 100%;
`;
const BackDrop = styled.div`
  background-color: rgba(42, 41, 41, 0.2),
  height: 100vh,
  position: fixed,
  top: 0,
  left: 0,
  width: 100%
`;
const Headerline = styled.h3`
  font-family: Nunito;
  font-size: 13px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  margin-left: 0px;
  text-align: left;
  letter-spacing: normal;
  color: #2e2e2e;
`;
class CustomerGraph extends Component {
  constructor(props) {
    super(props);
    this.state = {
      series: [],
      names: []
    };
  }

  componentDidMount () {
      let n = this.props.otherCollections[0].data.map((i) => i.name);
      let a = this.props.otherCollections[0].data.map((i) => i.amount);
      this.setState({
        series: a,
        names: n
      })
  }

  render() {
    return (
      <CalenderContainer>
        <BackDrop style={{width:"100%",display:"flex",height:"100%"}}>
          <Modal
            className="modal"
           title="Collections"
            show={this.props.isShowingModal}
            close={this.props.closeModalHandler}
            width="60%"
            height="auto"
            Customer Details
          >
            <Headerline>
              <span style={{ opacity: "0.5",marginRight: "5px" }}>Period:</span>
              {this.props.otherCollections[0].Day}
            </Headerline>
            <Bar name={this.state.names} series={this.state.series} data={this.props.otherCollections} closeModalHandler={this.props.closeModalHandler}/>
          </Modal>
        </BackDrop>
      </CalenderContainer>
    );
  }
}
export default CustomerGraph;
