import React, { Component } from "react";
import styled from "styled-components";
import { Container, Row, Col, Image } from "react-bootstrap";
import { connect } from "react-redux";
import Modal from "./Modals/Modal";
import NavBar from "./CusomerDetailsNavBar";
import { extractdata } from "../../utility/customerdetailsutil";

const CalenderContainer = styled.div`
position: fixed;
width: 100%;
left: 0;
right: 0;
margin: 0 auto;
top: 0px;
background: rgba(0,0,0,0.4);
z-index: 9999999;
height: 100%;
`;
const BackDrop = styled.div`
  background-color: rgba(42, 41, 41, 0.2),
  height: 100vh,
  position: fixed,
  top: 0,
  left: 0,
  width: 100%;
  
`;
const HeaderLine = styled.h3`
  font-family: Nunito;
  font-size: 13px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  text-align: left;
  letter-spacing: normal;
  padding: 10px;
  color: #2e2e2e;
`;
const Labels = styled.h3`
  font-family: Nunito;
  font-size: 15px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.33;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;
class CustomerDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      customerDataFromId: this.props.customerDataFromId,
      date: [],
      amount: [],
      name: "",
      clusterName: "",
      total: "",
      propName: window.location.pathname === "/outflows" ? "vendor" : "customer"
    };
    this.totalNetOutstanding = this.totalNetOutstanding.bind(this);
  }

  totalNetOutstanding(data) {
    let total = 0;
    if (data.hasOwnProperty("netOutstanding")) {
      total = data.netOutstanding
        .map(a => a.transactionAmount)
        .reduce((a, b) => {
          return a + b;
        });
    }
    return parseInt(total);
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      customerDataFromId: nextProps.customerDataFromId,
      name: nextProps.customerDataFromId[this.state.propName].name,
      clusterName: nextProps.customerDataFromId[this.state.propName].clusters
        ? nextProps.customerDataFromId[this.state.propName].clusters.name
        : ""
    });
    this.setState({
      total: this.totalNetOutstanding(nextProps.customerDataFromId)
    });
  }

  render() {
    return (
      <CalenderContainer>
        <BackDrop style={{width:"100%",display:"flex",height:"100%"}} >
          <Modal 
            className="modal"
            title="Customer Details"
            show={this.props.isShowingModal}
            close={this.props.closeModalHandler}
            width="60%"
            height="auto"
            titleBorder
          >
            <Container>
              <Container>
                <Row>
                  <Col>
                    <HeaderLine>
                      <span style={{ opacity: "0.5",marginRight: "5px" }}>Name:</span>
                      {this.state.name}
                    </HeaderLine>
                  </Col>
                  <Col>
                    <HeaderLine>
                      <span style={{ opacity: "0.5",marginRight: "5px"  }}>Credit Period:</span>
                      60 days
                    </HeaderLine>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <HeaderLine>
                      <span style={{ opacity: "0.5",marginRight: "5px"  }}>Cluster Name:</span>
                      {this.state.clusterName}
                    </HeaderLine>
                  </Col>
                  <Col>
                    <HeaderLine style={{ color: "#c94593" }}>
                      <span style={{ opacity: "0.5", color: "#2e2e2e",marginRight: "5px"  }}>Net Outstanding:</span>
                      INR {this.state.total}
                    </HeaderLine>
                  </Col>
                </Row>
              </Container>

              <NavBar customerDataFromId={this.props.customerDataFromId} />
            </Container>
          </Modal>
        </BackDrop>
      </CalenderContainer>
    );
  }
}
export default CustomerDetail;
