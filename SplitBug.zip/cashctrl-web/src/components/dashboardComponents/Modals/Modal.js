/* eslint-disable no-undef */
import React from "react";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes } from "@fortawesome/free-solid-svg-icons";
import TabButtons from "../TabButtons";
import "./Modal.css";

const ModalWrapper = styled.div`
  background: white;
  border: 1px solid #d0cccc;
  box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 7px 20px 0 rgba(0, 0, 0, 0.17);
  margin: 0 auto;
  transition: all 0.8s;
  width: ${props => (props && props.width ? props.width : "60%")};
  transform: ${props => (props && props.show ? "translateY(0vh)" : "translateY(-10vh)")};
  opacity: ${props => (props && props.show ? "1" : "0")};
`;

const ModalBody = styled.div`
  padding: 10px 15px;
  text-align: center;
  height: ${props => (props && props.height ? props.height : null)};
`;

const CloseButton = styled.div`
  color: black;
  cursor: pointer;
  float: right;
  font-size: 25px;
  margin-right: 20px;
  boder: none;
  background-color: #ffffff;
  opacity: ${props => (props && props.opacity ? props.opacity : "0.6")};
`;

const TiltleBorder = styled.hr`
  width: 30px;
  height: 5px;
  background-color: ${props => (props && props.color ? props.color : "#c94593")};
  margin: 10px;
`;

const Modal = props => {
  function onTabClick(type) {
    props.onTabClick(type === "Cheques not cleared received" ? "CNCI" : "CNCR");
  }

  return (
    <ModalWrapper
      className="align-self-center"
      show={props.show}
      width={props.width}
      onHide={props.close}
    >
      <div className="modal-content" style={{ border: "none" }}>
        {props.title === "Cheques not cleared" && (
          <div className="modalheader" style={{ padding: "10px" }}>
            <TabButtons
              buttonOne="Cheques not cleared received"
              buttonTwo="Cheques not issued cleared"
              onTabClick={onTabClick}
            />
            <CloseButton onClick={props.close} opacity={props.opacity}>
              <FontAwesomeIcon icon={faTimes} />
            </CloseButton>{" "}
          </div>
        )}
        {props.title !== "Cheques not cleared" && (
          <div className="modalheader" style={{ padding: "10px" }}>
            <h5 className="Accounts-Linked">{props.title}</h5>
            <CloseButton onClick={props.close} opacity={props.opacity}>
              <FontAwesomeIcon icon={faTimes} />
            </CloseButton>{" "}
            <br />
            <TiltleBorder color={props.titleColor} height={props.height} width={props.width} />
          </div>
        )}
        <ModalBody height={props.height}>{props.children}</ModalBody>
        <div className="modal-footer" />
      </div>
    </ModalWrapper>
  );
};

export default Modal;
