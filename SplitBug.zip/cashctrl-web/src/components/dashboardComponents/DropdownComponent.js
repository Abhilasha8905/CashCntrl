import React, { Component } from "react";
import { Dropdown } from "react-bootstrap";
import styled from "styled-components";
import "./style.css";

class DropdownComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      scenarioNames: this.props.scenarioNames,
      currentScenario: "Select Scenario",
      savedData: ""
    };
  }

  SelectedScenario(e) {
    let splitted = [];
    splitted = e.split(",");
    const id = splitted[1];
    const name = splitted[0];
    this.props.SelectedScenario(name, id);

    this.props.UpdateScenarioData(id);
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      currentScenario: nextProps.currentScenario,
      scenarioNames: nextProps.scenarioNames
    });
  }

  render() {
    return (
      <Dropdown>
        <Dropdown.Toggle
          id="dropdown-basic"
          style={{
            minWidth: "135px",
            userSelect: "none !important",
            backgroundColor: "#ffffff",
            color: "rgba(0,0,0,0.6)",
            border: "solid 1px rgba(0,0,0,0.6)",
            fontSize: "14px",
            fontWeight: "normal"
          }}
        >
          {this.state.currentScenario}
        </Dropdown.Toggle>
        <Dropdown.Menu>
          {this.state.scenarioNames.map(x => {
            return (
              <Dropdown.Item
                onSelect={eventKey => {
                  this.SelectedScenario(eventKey);
                }}
                eventKey={[x.name, x.id]}
                id={x.id}
              >
                {x.name}
              </Dropdown.Item>
            );
          })}
        </Dropdown.Menu>
      </Dropdown>
    );
  }
}

export default DropdownComponent;
