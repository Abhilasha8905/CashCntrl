import React, { Component } from "react";
import styled from "styled-components";
import Modal from "./Modals/Modal";
import NewData from "./NewData";

const AccountDetailContainer = styled.div`
  position: fixed;
  width: 100%;
  left: 0px;
  right: 0px;
  margin: 0 auto;
  top: 0px;
  height: 100%;
  display: flex;
  z-index: 9999999;
  background: rgba(0, 0, 0, 0.4);
`;
class AccountDetailComponent extends Component {
  constructor(props) {
    super(props);
    this.onTabClick = this.onTabClick.bind(this);
  }

  onTabClick(type) {
    this.props.addPDCOrClearIssue(type);
  }

  render() {
    return (
      <AccountDetailContainer>
        {this.props.isShowingModal ? (
          <div onClick={this.props.closeModalHandler} className="back-drop" />
        ) : null}
        <Modal
          className="modal"
          title={this.props.modalTitle}
          show={this.props.isShowingModal}
          close={this.props.closeModalHandler}
          titleColor={this.props.titleColor}
          onTabClick={this.onTabClick}
          titleBorder
        >
          <NewData
            dasboardTypeData={this.props.dasboardTypeData}
            dashboardTypeDataCnci={this.props.dashboardTypeDataCnci}
            dashboardTypeDataCncr={this.props.dashboardTypeDataCncr}
            cnClear={this.props.cnClear}
            ciClear={this.props.ciClear}
            pdcIssue={this.props.pdcIssue}
            dashboardType={this.props.dashboardType}
            bankBalance={this.props.bankBalance}
            titleColor={this.props.titleColor}
          />
        </Modal>
      </AccountDetailContainer>
    );
  }
}

export default AccountDetailComponent;
