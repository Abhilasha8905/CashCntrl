import { connect } from "react-redux";
import React, { Component } from "react";
import { ListGroup } from "react-bootstrap";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleDoubleRight } from "@fortawesome/free-solid-svg-icons";

const myEventsList = [
  {
    title: "540000.0 DJ Vission Enterprise",
    allDay: true,
    start: new Date(2019, 9, 6),
    end: new Date(2019, 9, 6),
    isDue: true
  },
  {
    title: "265000.0 Future Lifestyle",
    start: new Date(2019, 8, 7),
    end: new Date(2019, 8, 10),
    isDue: true
  },

  {
    title: "1000000.0 Cyclo Cycling Pvt Ltd",
    start: new Date(2019, 9, 1, 0, 0, 0),
    end: new Date(2019, 9, 2, 0, 0, 0),
    isDue: true
  },
  {
    title: "5000.0 DTS",
    start: new Date(2019, 9, 1, 0, 0, 0),
    end: new Date(2019, 9, 2, 0, 0, 0)
  },
  {
    title: "560098.0 Cyclo Pvt Ltd",
    start: new Date(2019, 9, 1, 0, 0, 0),
    end: new Date(2019, 9, 2, 0, 0, 0)
  },
  {
    title: "24587.0 DTS ENDS",
    start: new Date(2019, 9, 4, 0, 0, 0),
    end: new Date(2019, 9, 4, 0, 0, 0)
  },
  {
    title: "345700.0 Pay",
    start: new Date(2019, 9, 4, 0, 0, 0),
    end: new Date(2019, 9, 4, 0, 0, 0)
  },
  {
    title: "45620.8 Some Event",
    start: new Date(2019, 7, 9, 0, 0, 0),
    end: new Date(2019, 7, 10, 0, 0, 0)
  },
  {
    title: "4356409.0 Conference",
    start: new Date(2019, 9, 11),
    end: new Date(2019, 9, 11),
    desc: "Big conference for important people"
  }
];

const Collection = styled.button`
  border: solid 1px #ac2776;
  padding: 12px;
  width: 50%;
  border-radius: none;
  font-family: Nunito;
  font-size: 13px;
  outline: none !important;
  background-color: ${props =>
    props && props.buttonType === "Collections" ? "#c94593" : "#fbfcfe"};
  color: ${props => (props && props.buttonType === "Collections" ? "white" : "grey")};
  border-color: white;
`;

const Payment = styled.button`
  border: solid 1px #dd3636;
  padding: 12px;
  width: 50%;
  border-color: none;
  outline: none !important;
  border-radius: none;
  font-family: Nunito;
  font-size: 13px;
  background-color: ${props => (props && props.buttonType === "Payments" ? "#FF6361" : "#fbfcfe")};
  color: ${props => (props && props.buttonType === "Payments" ? "white" : "grey")};
  border-color: white;
`;

const Reminders = styled.div`
  background-color: white;
  padding: 12px;
  width: 100%;
  border-radius: none;
  font-family: Nunito;
  outline: none !important;
  font-size: 15px;
  border: none;
  text-align: left;
`;

const ListGroupComponent = styled(ListGroup)`
  font-size: 13px;
  color: black;
`;

const LinkView = styled.div`
  cursor: pointer;
`;

const ListText = styled.span`
  color: ${props => (props && props.buttonType === "Collections" ? "#c94593" : "#FF6361")};
`;

class ReminderComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      buttonType: "Collections",
      data:this.props.reminderCollections
    };
    this.handleButtonClick = this.handleButtonClick.bind(this);
  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      data: nextProps.reminderCollections
    });
  }
  handleButtonClick(event) {
    this.setState({
      buttonType: event.target.value
    });
  }

  openCalender() {
    this.props.openCalenderView(myEventsList);
  }
componentWillMount() {
  this.props.getReminderData();
}
  render() {

    return (
      <div className="h-100" style={{background:"white"}}>
        <div >
          <Reminders>
            <img
              style={{ marginLeft: "0px" }}
              src={require("../.././images/dashboard/bell-ring-alarm.png")}
            />
            <span style={{ paddingLeft: "10px" }}>Reminders</span>{" "}
          </Reminders>
          <Collection
            buttonType={this.state.buttonType}
            value="Collections"
            onClick={() => this.handleButtonClick(event)}
            size="lg"
          >
            Collections
          </Collection>
          <Payment
            buttonType={this.state.buttonType}
            value="Payments"
            onClick={() => this.handleButtonClick(event)}
            size="lg"
          >
            Payments
          </Payment>
        </div>
        <ListGroupComponent style={{height:"59vh",overflow:"auto"}}>
          {this.state.buttonType ==="Collections" && this.state.data.map(item => {
          return (<ListGroup.Item style={{ border: "none", borderBottom: "2px solid #eaf0f3", width: "100%",maxWidth: "100%" }}>
            <ListText buttonType={this.state.buttonType}>INR {item.amount} </ListText>
            <span>due from {item.name} on</span>{" "}
            <ListText buttonType={this.state.buttonType}>{item.date}</ListText>
          </ListGroup.Item>)
          })}

          <ListGroup.Item style={{ border: "none", position: "absolute", bottom: "0px" }}>

            <LinkView onClick={() => this.openCalender()}>
              Calender View{" "}
              <ListText buttonType={this.state.buttonType}>
                <FontAwesomeIcon icon={faAngleDoubleRight} />
              </ListText>
            </LinkView>
          </ListGroup.Item>
        </ListGroupComponent>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {};
const mapDispatchToProps = (dispatch, ownProps) => {};
export default ReminderComponent;
