import React, { Component } from "react";
import { Col } from "react-bootstrap";
import styled from "styled-components";

const CardContainer = styled.div`
  height: 155px;
  padding-left: 6%;
  padding-top: 10%;
  border-radius: 3px;
  position: relative;
  box-shadow: 0 5px 20px 0 rgba(0, 0, 0, 0.1);
  overflow: hidden;
  background-color: ${props => (props && props.color ? props.color : "rgba(201, 69, 147, 0.5)")};
`;

const CardTitle = styled.span`
  opacity: 0.6;
  font-family: Nunito;
  font-size: 15px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.33;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

const IconRupee = styled.span`
  width: 8.4px;
  height: 12.6px;
  color: "#2e2e2e";
  opacity: 0.6;
`;

const CardAmount = styled.span`
  font-family: Nunito;
  font-size: 20px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.35;
  letter-spacing: normal;
  text-align: left;
  display: inline-block;
  margin-bottom: 5%;
  color: #2e2e2e;
`;

const CardLink = styled.span`
  font-family: Nunito;
  font-size: 13px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
  border-bottom: 1px solid black;
  cursor: pointer;
`;

const CardImg = styled.img.attrs({
  src: props => props.imageURL
})`
  opacity: ${props => (props && props.opacity ? props.opacity : "0.5")};
  width: ${props => (props && props.width ? props.width : "40%")};
  position: absolute;
  bottom: -1px;
  right: 0;
  object-fit: contain;
`;

class CardComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { props } = this;
    const { cashData, color, image, width, opacity, left } = props;
    return (
      <Col xl={3} lg={3} md={3} xs={12} style={{ paddingRight: "8px", paddingLeft: "8px" }}>
        <CardContainer color={color}>
          <CardTitle>{cashData.title}</CardTitle>
          <br />
          <IconRupee>&#x20b9; </IconRupee>
          <CardAmount>{cashData.amount}</CardAmount>
          <br />
          <CardLink onClick={() => this.props.openModalHandler()}>{cashData.linkTitle}</CardLink>
          <CardImg imageURL={image} width={width} opacity={opacity} />
        </CardContainer>
      </Col>
    );
  }
}

export default CardComponent;
