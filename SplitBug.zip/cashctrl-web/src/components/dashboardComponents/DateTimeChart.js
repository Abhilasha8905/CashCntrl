import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";
import _ from "lodash";
import moment from "moment-timezone";
import datas from "./data/Customerdata.json";

const data = [];
function extractData() {
  for (const i in datas.customers) {
    for (const j in datas.customers[i].payment) {
      const date = moment(moment(datas.customers[i].payment[j].date).utc())
        .tz("IST")
        .format("MM/DD/YYYY z");
      data.push({
        name: datas.customers[i].name,
        amount: datas.customers[i].payment[j].amount,
        date: datas.customers[i].payment[j].date
      });
    }
  }

  return data;
}
const gdata = extractData();

const dates = gdata
  .map(item => item.date)
  .filter((item, index, array) => array.indexOf(item) == index);
dates.sort(function(a, b) {
  a = a
    .split("/")
    .reverse()
    .join("");
  b = b
    .split("/")
    .reverse()
    .join("");
  return a > b ? 1 : a < b ? -1 : 0;

});


const productTotals = data.reduce((obj, curr) => {
  if (!obj[curr.name]) {
    obj[curr.name] = [];
  }

  obj[curr.name][curr.date] = parseInt(curr.amount);
  return obj;
}, {});

const series = Object.entries(productTotals).map(([name, prodArr]) => {
  return {
    name,
    data: dates.map(date => {
      if (!prodArr[date]) {
        return 0;
      }
      return prodArr[date];
    })
  };
});

class DateTimeChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      options: {
        chart: {
          type: "bar",
          stacked: true,
          columnWidth: "20%",
          toolbar: {
            show: false
          }
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              legend: {
                position: "bottom",
                offsetX: -10,
                offsetY: 0
              }
            }
          }
        ],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "20%"
          }
        },
        stroke: {
          width: 1
        },
        grid: {
          show: true,
          borderColor: "#fffff",
          strokeDashArray: 0,
          position: "back",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          }
        },
        dataLabels: {
          enabled: false,
          hideOverflowingLabels: true
        },

        xaxis: {
          axisBorder: {
            show: true,
            color: "#78909C",
            height: 1,
            width: "100%",
            offsetX: 0,
            offsetY: 0
          },
          axisTicks: {
            show: false
          },
          type: "datetime",
          categories: [...dates]
        },
        legend: {
          show: false
        },
        fill: {
          opacity: 1
        },
        colors: [
          "#003f5c",
          "rgba(0, 63, 92, 0.7)",
          "#58508d",
          "#c94593",
          "rgba(200,68,146,0.5)",
          "#ff6361",
          "#ffa600",
          "#707070"
        ],
        yaxis: {
          show: true,

          tickAmount: 12,
          min: 0,
          max: 60,
          labels: {
            formatter(value) {
              return `${value}K`;
            }
          },
          axisBorder: {
            show: true,
            color: "#78909C",
            offsetX: -8,
            offsetY: 4
          }
        },

      },

      series: [...series]
    };
  }

  render() {
    return (
      <div id="chart">
        <ReactApexChart
          options={this.state.options}
          series={this.state.series}
          type="bar"
          height="400"
        />
      </div>
    );
  }
}

export default DateTimeChart;
