import React, { Component } from "react";
import DatePicker from "react-datepicker";
import styled from "styled-components";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";

const CalendarText = styled.input`
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.36;
  -webkit-letter-spacing: normal;
  -moz-letter-spacing: normal;
  -ms-letter-spacing: normal;
  letter-spacing: normal;
  text-align: left;
  display: inline-block;
  color: #2e2e2e;
  border: none;
  background: #f7f7f9;
  outline: none;
  white-space: nowrap;
  width: 69%;
`;

const CalendarImg = styled.img.attrs({
  src: props => props.imageURL
})`
  width: 16.6px;
`;

const DatepickerContainer = styled.div`
  padding: 8px 10px;
  margin-right: 0px;
  padding-bottom: 8px;
  background: #f7f7f9;
  border-right: 1px solid #dedee0;
  display: FLEX;
  white-space: nowrap;
  width: 100%;
  justify-content: space-between;
  /* MIN-HEIGHT: 24PX; */
  align-items: center;
`;

const format = "DD MMM YYYY";

class DatepickerComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      date: this.props.date ? this.props.date : new Date(),
      startDate: "",
      selectedValue: this.props.date
    };
    this.handleChangeRaw = this.handleChangeRaw.bind(this);
  }

  componentDidUpdate(prevProps, prevStates) {
    if (prevProps.date !== this.props.date) {
      this.setState({date: this.props.date})
    }
  }

  handleChangeRaw(date) {
    date.currentTarget.value = moment(this.props.input.value).format("DD/MM/YYYY");
  }

  handleChangeRaw(value) {
    this.setState({ startDate: value });
  }

  handleChange(date) {
    this.setState({ selectedValue: date });
  }

  focousOut(value) { //ValidateDate function is not defined anywhere
    // if (!validateDate(value)) {
    //   this.setState({ startDate: "" });
    //   this.setState({ selectedValue: moment() });
    // }
  }

  render() {
    return (
      <DatePicker
        className="dateeepick"
        style={{
          display: "inline-block",
          padding: "0",
          border: "0",
          /* DISPLAY: INLINE-FLEX; */
          WIDTH: "36%"
        }}
        minDate={this.props.minDate}
        selected={new Date(this.state.date)}
        value={this.state.startDate}
        onChange={this.handleChange}
        onChangeRaw={event => this.handleChangeRaw(event.target.value)}
        onBlur={event => this.focousOut(event.target.value)}
        customInput={
          <DatepickerContainer>
            <CalendarText
              className="date-text"
              value={moment(this.state.date).format(format)}
              
              readonly
            />
            <CalendarImg
              imageURL={require("../.././images/dashboard/calendar.svg")}
              className="date-img"
            />
          </DatepickerContainer>
        }
        onChange={date => {
          this.setState({ date });
          this.props.onDateSelect(date);
        }}
      />
    );
  }
}

export default DatepickerComponent;
