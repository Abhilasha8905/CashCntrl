import { connect } from "react-redux";
import React, { Component } from "react";
import { Navbar, Nav, ButtonGroup } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import "./style.css";
import styled from "styled-components";
import CustomerClusterButton from "../CustomerClusterButton";
import Bar from "./TabBarChart";

const TabButton = styled.button`
  padding: 8px 15px !important;
  opacity: 0.6;
  font-family: Nunito;
  font-size: 15px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.33;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  outline: none !important;
  background-color: #fff;
  border: none;
  margin-top: 0.5rem;
  &:active {
    color: #2e2e2e;
    opacity: 1;
  }
  &:focus {
    color: #2e2e2e;
    opacity: 1;
  }
`;
const ButtonGroupComponent = styled(ButtonGroup)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  color: black;
  float: left;
`;
const TabBody = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-bottom: 2%;
  padding-top: 1%;
`;
const TotalDiv = styled.div`
  width: 184px;
  height: 39px;
  border-radius: 3px;
  background-color: #cdcdcd;
  position: absolute;
  padding-top: 0.5rem;
  top: 0;
  right: 0;
`;
const TotalStyle = styled.span`
  width: 36px;
  height: 18px;
  opacity: 0.5;
  font-family: Nunito;
  font-size: 13px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: right;
  color: #2e2e2e;
`;
const TotalAmountStyle = styled.span`
  font-family: Nunito;
  font-size: 13px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.33;
  letter-spacing: normal;
  text-align: left;
  color: #58508d;
`;
const TabContent = styled.div`
  margin: 2%;
  background: #ffffff;
  height: 40vh;
  border-radius: 2px;
  position: relative;
  overflow: hidden;
`;

class NavBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tabSelected: "sales",
      customerDataFromId:this.props.customerDataFromId,
      date: [],
      amount: [],
      total: "",
      modalGraph: {
        currentPage: 0,
        numberOfPages: 1
      }
    };
    this.modalParentRef = React.createRef();

    this.onTabClick = this.onTabClick.bind(this);
    this.getDate = this.getDate.bind(this);
    this.totalAmount = this.totalAmount.bind(this);
    this.modalPrevPage = this.modalPrevPage.bind(this);
    this.modalNextPage = this.modalNextPage.bind(this);

  }
  componentWillReceiveProps(nextProps) {
    if (this.props.customerDataFromId !== nextProps.customerDataFromId) {
      this.setState({
        customerDataFromId:nextProps.customerDataFromId
      })
      this.getDate(this.state.tabSelected, nextProps.customerDataFromId);
    }
  }

  componentDidUpdate(prevProps, prevStates) {
    console.log(this.state.modalGraph.currentPage, prevStates)
    if (prevProps.customerDataFromId !== this.props.customerDataFromId) {
    this.initializeModalGraphState();
    }
    if (prevStates.modalGraph.currentPage !== this.state.modalGraph.currentPage) {
      this.scrollModalGraph();
    } 
  }


  initializeModalGraphState(){

    const modalParent = this.modalParentRef.current;
    const parentWidth = modalParent.clientWidth;
    console.log("initial",this.state.date.length)
    const graphWidth = (this.state.customerDataFromId.sales.length > 25) ? 100 * this.state.customerDataFromId.sales.length : parentWidth;
    const numberOfPages = Math.ceil(graphWidth / parentWidth);
    this.setState({
      modalGraph: {
        currentPage: 0,
        numberOfPages
      }
    });
  }
  scrollModalGraph(){
    console.log("scroll");
    const modalParent = this.modalParentRef.current;
    console.log("modalParent",modalParent);

    const parentWidth = modalParent.clientWidth;
    console.log("parentWidth",parentWidth);

    console.log("parentWidth",parentWidth * this.state.modalGraph.currentPage);

    modalParent.scrollLeft = parentWidth * this.state.modalGraph.currentPage;
  }
  modalPrevPage(){
    console.log(this.state);

    this.setState((state) => {
      if (state.modalGraph.currentPage > 0) {
        return {
          ...state,
          modalGraph: { ...state.modalGraph, currentPage: state.modalGraph.currentPage - 1 }

        }
      };
      this.scrollModalGraph();

      return state;
    });

  }
  modalNextPage(){
    console.log("clicked next")
    console.log(this.state);
    this.setState((state) => {
      if (state.modalGraph.currentPage < state.modalGraph.numberOfPages - 1) {
        return {
          ...state,
          modalGraph: { ...state.modalGraph, currentPage: state.modalGraph.currentPage + 1 }

        };
      }
      return state;
    });

  }
  onTabClick(event) {
    this.setState({
      tabSelected: event.target.id
    });
    this.getDate(event.target.id, this.props.customerDataFromId);
  }

  totalAmount(data) {
    if (data.length > 0) {
      const total = data.reduce((a, b) => {
        return a + b;
      });
      return parseInt(total);
    }
    return 0;
  }

  getDate(tabName, data) {
    let a = [];
    let b = [];

    if (data.hasOwnProperty(tabName)) {
      a = data[tabName].map(i => i.transactionDate);
      b = data[tabName].map(i => i.transactionAmount);
    }

    this.setState({
      date: a,
      amount: b
    });
    this.setState({
      total: this.totalAmount(b)
    });
  }

  
  render() {
    return (
      <TabBody>
        <ButtonGroupComponent style={{ border: "1px solid rgb(0,0,0,0.2)" }}>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="sales"
            style={{
              borderBottom: this.state.tabSelected === "sales" ? "4px solid #C94593" : null,
              padding: "0px, 14px"
            }}
          >
            Sales
          </TabButton>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="creditNoteForReturns"
            style={{
              borderBottom:
                this.state.tabSelected === "creditNoteForReturns" ? "4px solid #C94593" : null,
              padding: "0px, 14px"
            }}
          >
            Credit Note For Returns
          </TabButton>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="Credit Schemes"
            style={{
              borderBottom:
                this.state.tabSelected === "Credit Schemes" ? "4px solid #C94593" : null,

              padding: "0px, 14px"
            }}
          >
            Credit Note For Schemes
          </TabButton>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="payment"
            style={{
              borderBottom: this.state.tabSelected === "payment" ? "4px solid #C94593" : null,

              padding: "0px, 14px"
            }}
          >
            Payment Made
          </TabButton>
          <TabButton
            onClick={event => this.onTabClick(event)}
            id="netOutstanding"
            style={{
              borderBottom:
                this.state.tabSelected === "netOutstanding" ? "4px solid #C94593" : null,

              padding: "0px, 14px"
            }}
          >
            Net Outstanding
          </TabButton>

          <div
            style={{
              paddingRight: "0",
              position: " absolute",
              right: "0",
              paddingRight: "0.5rem",
              paddingTop: "1rem"
            }}
          >
            {/* <FontAwesomeIcon
              icon={faEllipsisV}
              style={{ fontSize: "18", color: "#2e2e2e", opacity: "0.5", textAlign: "center" }}
            /> */}
          </div>
        </ButtonGroupComponent>
        <TabContent ref={this.modalParentRef}>
          {this.state.tabSelected === "sales" && (
            <Bar date={this.state.date} amount={this.state.amount} />
          )}
          {this.state.tabSelected === "creditNoteForReturns" && (
            <Bar date={this.state.date} amount={this.state.amount} />
          )}
          {this.state.tabSelected === "Credit Schemes" && (
            <Bar date={this.state.date} amount={this.state.amount} />
          )}
          {this.state.tabSelected === "payment" && (
            <Bar date={this.state.date} amount={this.state.amount} />
          )}
          {this.state.tabSelected === "netOutstanding" && (
            <Bar date={this.state.date} amount={this.state.amount} />
          )}

          <TotalDiv>
            <TotalStyle>
              Total: INR <TotalAmountStyle>{this.state.total}</TotalAmountStyle>
{" "}
            </TotalStyle>
          </TotalDiv>

        </TabContent>
        <div style=
              {{width:"30px",height:"30px",background:"white",position:"absolute",bottom:"32px",border:"1px solid #ebebeb",
                textAlign:"center",borderRadius:"5px"}}>
              <img
                src={require("../../images/flowChart/arrow-left.png")}
                style={{marginLeft:"0px"}}
                onClick={this.modalPrevPage}
                disabled={this.state.modalGraph.currentPage === 0}
              />
             </div>
            <div style=
             {{width:"30px",height:"30px",background:"white",position:"absolute",bottom:"32px",border:"1px solid #ebebeb",
             textAlign:"center",borderRadius:"5px",right:"15px"}}>
             <img
                src={require("../../images/flowChart/arrow-right.png")}
                style={{ marginLeft:"0px"}}
                onClick={this.modalNextPage}
                disabled={this.state.modalGraph.currentPage === this.state.modalGraph.numberOfPages - 1}
              />
            </div>
      </TabBody>
    );
  }
}
// state: our state is passed as the first argument here
const mapStateToProps = (state, ownProps) => {};
// actions: Redux's dispatch function is passed as the first argument here
const mapDispatchToProps = (dispatch, ownProps) => {};
// defining the Container component, passing the above 2 functions into Redux's connect().

export default NavBar;
