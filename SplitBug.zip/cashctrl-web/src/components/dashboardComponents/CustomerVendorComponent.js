import "./CustomerVendorComponent.css";
import React from "react";
import FilterCheckList from "./FilterCheckListInflow";

class CustomerVendorComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      tabSelected: props.buttonOne

      // second:false,
    };
    this.onTabClick = this.onTabClick.bind(this);
  }

  onTabClick(event) {
    this.setState({
      tabSelected: event.target.id
    });
    
  }

  render() {
    return (
      <div className="tab-body">
        <div className="btn">
          <div className="views">
            <button
              className="normalStyle"
              onClick={event => this.onTabClick(event)}
              id={this.props.buttonOne}
              style={{
                border: this.state.tabSelected === this.props.buttonOne ? "solid 2px #c94593" : "",
                color: this.state.tabSelected === this.props.buttonOne ? "#c94593" : ""
              }}
            >
              {this.props.buttonOne}
            </button>
            <button
              className="normalStyle"
              onClick={event => this.onTabClick(event)}
              id={this.props.buttonTwo}
              style={{
                border: this.state.tabSelected === this.props.buttonTwo ? "solid 2px #c94593" : "",
                color: this.state.tabSelected === this.props.buttonTwo ? "#c94593" : ""
              }}
            >
              {this.props.buttonTwo}
            </button>{" "}
            <br />
          </div>
          <div className="tab-content">
            {this.state.tabSelected === this.props.buttonOne ? (
              <div className="filterlist">
                <p>
                  {" "}
                  <img src={require("../.././images/dashboard/filter.svg")} />
                  Filter by {this.props.buttonOne}
                </p>
                <div className="content">
                  <FilterCheckList />{" "}
                </div>{" "}
              </div>
            ) : (
              <div className="filterlist">
                {" "}
                <p>
                  <img src={require("../.././images/dashboard/filter.svg")} />
                  Filter by {this.props.buttonTwo}
                </p>{" "}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
}
export default CustomerVendorComponent;
