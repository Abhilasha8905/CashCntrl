import React from "react";
import styled from "styled-components";
import { connect } from "react-redux";
import { enteredAmountOutflow } from "../../actions/OutFlowActions";

const OuterBox = styled.div`
  padding: 0;
  color: #2e2e2e;
  border-radius: 5px;
  margin-top: 2px;
  cursor: pointer;
  display: block;
  font-size: 12px;
  font-weight: 500;
  line-height: 15px;
  background: #fff;
  position: absolute;
  left: auto;
  margin-left: -100px;
  z-index: 30;
  width: ${props => (props.width ? props.width : "100%")};
  max-height: 300px;
  margin-top: 17px;
`;
const FilterBox = styled.div`
  width: 260px;
  height: 170px;
  box-shadow: 0 5px 20px 0 rgba(0, 0, 0, 0.05);
  border: solid 1px rgba(46, 46, 46, 0.13);
  background-color: #ffffff;
`;
const Input = styled.input`
  width: 100%;
  padding: 12px 20px;
  opacity: 1;
  border: 1px solid #ebebeb;
  background-color: #ffffff;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 400;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
  margin-left: 0px;
  margin-top: 15px;
`;
const Block = styled.button`
  width: 100%;
  padding: 5px 10px;
  font-size: 14px;
  font-weight: 500;
  color: #c94593;
  cursor: pointer;
  text-align: center;
  border: solid 1px #c94593;
  background-color: #ffffff;
  margin-left: 0px;
  margin-top: 20px;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.16);
`;
const ApplyButton = styled.div`
  width: 100%;
  padding: 10px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;
class EqualsFilterComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      values: this.props.options,
      amount: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({
      amount: event.target.value
    });
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      values: nextProps.options
    });
  }

  handleSubmit() {
    if (this.state.amount !== "") {
      this.props.enteredAmountOutflow(this.state.amount);
    }

    event.preventDefault();
    this.props.hideDIalog(event);
  }

  render() {
    return (
      <OuterBox width={this.props.width}>
        <FilterBox>
          {" "}
          <ApplyButton>
            {this.state.values}
            ...
            <br />
            <form onSubmit={this.handleSubmit}>
              <Input
                type="number"
                placeholder="Enter amount"
                value={this.state.amount}
                onChange={this.handleChange}
              />
              <br />
              <Block>Apply</Block>
            </form>
          </ApplyButton>
        </FilterBox>
      </OuterBox>
    );
  }
}

export default EqualsFilterComponent;
