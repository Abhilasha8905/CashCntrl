import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";
import moment from "moment";
import { getDaysInMonth } from "../../utility/newutil";

class WeekInflowChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isTrue: true,
      dates: [],
      series: [],
      options: {
        chart: {
          stacked: true,
          toolbar: {
            show: false
          },
          zoom: {
            enabled: true
          }
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              legend: {
                position: "bottom",
                offsetX: -10,
                offsetY: 0
              }
            }
          }
        ],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "30%"
          }
        },
        stroke: {
          width: 1
        },
        grid: {
          show: true,
          borderColor: "#90A4AE",
          strokeDashArray: 0,
          position: "front",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          },
          padding: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
          }
        },
        dataLabels: {
          enabled: false,
          hideOverflowingLabels: true
        },

        xaxis: {
          axisTicks: {
            show: false
          },
          labels: {
            format: "dd MMM"
          },
          categories: []
        },
        legend: {
          show: false
        },
        fill: {
          opacity: 1
        },
        colors: [
          "#003f5c",
          "rgba(0, 63, 92, 0.7)",
          "#58508d",
          "#c94593",
          "rgba(200,68,146,0.5)",
          "#ff6361",
          "#ffa600",
          "#707070"
        ],
        yaxis: {
          show: true,

          tickAmount: 6,
          min: 0,
          max: 60,
          labels: {
            formatter(value) {
              return `${value}K`;
            }
          },
          axisBorder: {
            show: true,
            color: "#78909C",
            offsetX: -8,
            offsetY: 3
          }
        },

      },

      series: []
    };
    // this.extractDateRange=this.extractDateRange.bind(this);
    // this.extractData=this.extractData.bind(this);
    // this.seriesData=this.seriesData.bind(this);
    // this.productTotals=this.productTotals.bind(this);
    // this.sortDate=this.sortData.bind(this);
    // this.groupedByWeekResults=groupedByWeekResults.bind(this);
  }

  trying() {
    // let d=extractDateRange(this.props.fromDate,this.props.toDate);
    const date = new Date();
    const xdates = getDaysInMonth(date.getMonth() + 1, date.getFullYear());
    const ddd = xdates.map(d => moment(d).format("DD MMM"));

    // this.props.dateValues(date);
    //  let series=seriesDataPoints(this.props.fromDate,this.props.toDate);
    //  this.props.seriesData(series);
    // this.sortData();
    // this.productTotals();
    // this.seriesData();
    //  this.state.options.xaxis.categories = this.props.dates
    // var someProperty = {...this.state.options};
    // someProperty.xaxis.categories = this.props.dates;
    // this.setState({someProperty});
    //    this.setState(prevState => ({
    //      ...prevState,
    //     options: {
    //          ...prevState.options,
    //          xaxis: {
    //              ...prevState.options.xaxis,
    //              categories:this.props.dates
    //          }
    //      }
    //  }))
  }

  //  componentWillReceiveProps(){
  //    this.trying();
  //  }
  componentDidMount() {
    this.trying();
  }

  render() {
    return (
      <div id="chart" style={{ padding: "25px" }}>
        <ReactApexChart
          options={this.state.options}
          dates={this.props.dates}
          series={this.props.series}
          type="bar"
          height="600"
        />
      </div>
    );
  }
}
export default WeekInflowChart;
