import "./ExportButton.css";
import React from "react";

class ExportButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.sayHello = this.sayHello.bind(this);
  }

  sayHello(event) {

  }
  render() {
    return (
      <div className="container">
        <div className="buttonclass" onClick={this.sayHello}>
          <img src={require("../.././images/dashboard/export.svg")} /> Export
          Data
        </div>
      </div>
    );
  }
}
export default ExportButton;
