import React from "react";

import styled from "styled-components";
import { connect } from "react-redux";
import FilterCheckListInflow from "./FilterCheckListInflow";

import { getNames } from "../../utility/newutil";
import { customerFilterInflow, filterList } from "../../actions/InflowActions";

const Paragraph = styled.p`
  margin: 0;
  opacity: 0.6;
  padding: 15px 0px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
`;
class CustomerExpenseComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      productList: []
    };
  }

  render() {
    return (
      <div className="filtertable" style={{ paddingLeft: "0" }}>
        {this.props.tabSelected === this.props.buttonOne ? (
          <div className="filterlist">
            {" "}
            <Paragraph>
              <img
                src={require("../.././images/dashboard/filter.svg")}
                style={{ marginLeft: "0", marginRight: "7px", opacity: "1", height: "14px" }}
              />
              Filter by {this.props.buttonOne}
            </Paragraph>
            <FilterCheckListInflow
              initialList={this.props.initialList}
              showButton
              customerFilterInflow={this.props.customerFilterInflow}
              data={this.props.data}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              datefilter={this.props.datefilter}
              cname={this.props.cname}
              productsList={this.props.productsList}
              inflowUpdate={this.props.inflowUpdate}
              tabSelected={this.props.tabSelected}
            />{" "}
          </div>
        ) : (
          <div className="filterlist">
            {" "}
            <Paragraph>
              <img
                src={require("../.././images/dashboard/filter.svg")}
                style={{ marginLeft: "0", marginRight: "7px", opacity: "1", height: "14px" }}
              />
              Filter by {this.props.buttonTwo}
            </Paragraph>{" "}
            <FilterCheckListInflow
              productList={this.state.productList}
              showButton
              customerFilterInflow={this.props.customerFilterInflow}
              data={this.props.data}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              datefilter={this.props.datefilter}
              cname={this.props.cname}
              productsList={this.props.customerclusterNames}
              tabSelected={this.props.tabSelected}
              inflowUpdate={this.props.inflowUpdate}
              customerClusterData={this.props.customerClusterData}
            />
          </div>
        )}
      </div>
    );
  }
}

export default CustomerExpenseComponent;
