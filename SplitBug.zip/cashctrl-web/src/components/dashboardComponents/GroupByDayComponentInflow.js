import React from "react";
import ReactApexChart from "react-apexcharts";
import _ from "lodash";
import moment from "moment-timezone";

class GroupByDayComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      category: [],
      options: {
        chart: {
          events: {
            dataPointSelection: (event, chartContext, config) => {
              const seriesName = config.w.config.series[config.seriesIndex];
              this.props.openModalHandler(this.state.outside[config.dataPointIndex], seriesName);
            }
          },
          type: "bar",
          stacked: true,

          toolbar: {
            show: false
          }
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              legend: {
                position: "bottom",
                offsetX: -10,
                offsetY: 0
              }
            }
          }
        ],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "10%"
          }
        },
        stroke: {
          width: 1
        },
        grid: {
          show: true,
          borderColor: "#fffff",
          strokeDashArray: 0,
          position: "back",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          }
        },
        dataLabels: {
          enabled: false,
          hideOverflowingLabels: true
        },

        xaxis: {
          axisBorder: {
            show: true,
            color: "#78909C",
            height: 1,
            width: "100%",
            offsetX: 0,
            offsetY: 0
          },
          axisTicks: {
            show: false
          },

          categories: [...this.props.dates]
        },
        legend: {
          show: false
        },
        fill: {
          opacity: 1
        },
        colors: [
          "#003f5c",
          "rgba(0, 63, 92, 0.7)",
          "#58508d",
          "#c94593",
          "rgba(200,68,146,0.5)",
          "#ff6361",
          "#ffa600",
          "#707070"
        ],
        yaxis: {
          show: false,
      //     tickAmount: 8,
      // min: 20,
      // max: 300,
          labels: {
            formatter(value) {
              return `${value}`;
            }
          },
          axisBorder: {
            show: true,
            color: "#78909C",
            offsetX: 1,
            offsetY: 0
          }
        },

      },
      // series: [this.props.series]
      series: [
        {
          data: [this.props.series]
        },
        {
          data: [42, 12, 43, 53, 44]
        }
      ],
      outside: [...this.props.fullDates]
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState(prevState => ({
      ...prevState,
      options: {
        ...prevState.options,
        xaxis: {
          ...prevState.options.xaxis,
          categories: nextProps.dates
        }
      }
    }));
    this.setState({
      outside: nextProps.fullDates
    });
  }

  
  render() {
    var chartWidth = (this.props.dates.length>25) ? 100 * this.props.dates.length : "100%";
    return (     
      <ReactApexChart
        options={this.state.options}
        series={this.props.series}
        type="bar"
        width={chartWidth}
        height="100%" 
      />
    );
  }
}
export default GroupByDayComponent;
