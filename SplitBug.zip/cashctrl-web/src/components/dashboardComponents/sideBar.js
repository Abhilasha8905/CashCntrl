import React, { Component } from "react";

import styled from "styled-components";
const SideBarContainer = styled.div`
  background: white;
  width: 5%;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
`;

//Presentational component
class SideBar extends Component {
  render() {
    return (
      <SideBarContainer>
        <h4>helooo</h4>
      </SideBarContainer>
    );
  }
}
//state: our state is passed as the first argument here
constmapStateToProps = (state, ownProps) => {};
//actions: Redux's dispatch function is passed as the first argument here
constmapDispatchToProps = (dispatch, ownProps) => {};
//defining the Container component, passing the above 2 functions into Redux's connect().

export default SideBar;
