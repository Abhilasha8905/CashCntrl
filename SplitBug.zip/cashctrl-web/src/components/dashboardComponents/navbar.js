import React, { Component } from "react";
import { Navbar, Nav } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./style.css";
import CustomerClusterButton from "../CustomerClusterButton";

class NavBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      tabSelected: window.location.pathname.split("/")[1]
    };
    this.clustorView = this.clustorView.bind(this);
  }

  clustorView() {
    this.setState({
      modalVisible: true
    });
  }

  render() {
    return (
      <div>
        <Navbar
          className="navbar navbar-default"
          collapseOnSelect
          expand="lg"
          variant="dark"
          style={{ backgroundColor: "#f8f9fb", padding: "0" }}
        >
          <Navbar.Toggle
            aria-controls="responsive-navbar-nav"
            style={{ backgroundColor: " #c94593" }}
          />
          <Navbar.Collapse id="responsive-navbar-nav ">
            <Nav
              className="nav navbar-nav navbar-right w-100 "
              style={{ marginBottom: "8px", paddingLeft: "6px" }}
            >
              <li className="list" style={{ marginLeft: "20px" }}>
                <Link
                  to="/dashboard"
                  onClick={() => this.setState({ tabSelected: "dashboard" })}
                  className={
                    window.location.pathname === "/dashboard" || window.location.pathname == "/"
                      ? "active"
                      : "inactive"
                  }
                >
                  {" "}
                  Dashboard{" "}
                </Link>
              </li>
              <li className="list-spacing">
                <Link
                  to="/inflows"
                  onClick={() => this.setState({ tabSelected: "inflows" })}
                  className={window.location.pathname === "/inflows" ? "active" : "inactive"}
                >
                  {" "}
                  Inflows{" "}
                </Link>
              </li>
              <li className="list-spacing">
                <Link
                  to="/outflows"
                  onClick={() => this.setState({ tabSelected: "outflows" })}
                  className={window.location.pathname === "/outflows" ? "active" : "inactive"}
                >
                  {" "}
                  Outflows{" "}
                </Link>
              </li>
              <li className="list-spacing">
                <Link
                  to="/liquidity"
                  onClick={() => this.setState({ tabSelected: "liquidity" })}
                  className={window.location.pathname === "/liquidity" ? "active" : "inactive"}
                >
                  {" "}
                  Liquidity Predictor{" "}
                </Link>
              </li>
              <div
                className="col-lg-8"
                style={{
                  paddingRight: "0",
                  float: "right",
                  position: "absolute",
                  right: "0",
                  top: "-7px"
                }}
              >
                <Link to="/clusterview">
                  <CustomerClusterButton
                    clustorView={this.clustorView}
                    tabSelected={this.state.tabSelected}
                  />
                </Link>
              </div>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        {
          //  this.state.modalVisible &&
          //   <div style={{margin: '2%'}}>
          //     <CustomerVendorview />
          //   </div>
        }
      </div>
    );
  }
}

export default NavBar;
