import React, { Component } from "react";
import styled from "styled-components";
import { Container } from "react-bootstrap";
import { connect } from "react-redux";
import CreateCluster from "./CreateClusterInflow";
import {
  clusterData,
  clusterFilter,
  getCustomersList,
  customerListInflow,
  createNewCustomerCluster,
  createNewVendorCluster,
  editCustomerCluster,
  editVendorCluster
} from "../../actions/InflowActions";
import { getVendorsList } from "../../actions/OutFlowActions";

const Description = styled.div`
  align-items: center;
  width: auto;
  height: 53vh;
`;

const ButtonGroupComponent = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  color: black;
`;

const DescriptionText = styled.div`
  color: black;
  text-decoration: none;
  background: white !important;
  padding: 15px;
  font-size: 14px;
  border-bottom: 1px solid #ebebeb;
`;

const TabBody = styled.div`
  position: relative;
  max-width: 100%;
`;

const PencilImg = styled.img.attrs({
  src: props => props.imageURL
})`
  height: ${props => (props.height ? props.height : "15px")};
  width: ${props => (props.width ? props.width : "15px")};
  background-size: ${props => (props.backgroundSize ? props.backgroundSize : "100px")};
  vertical-align: middle;
  float: right;
  @media screen and (max-width: 750px) {
    height: 20px;
    width: 20px;
    background-size: 20px;
  }
`;

const TabContent = styled.div`
  margin: 0px;
  background: #ffffff;
  height: 75vh;
  overflow-y: scroll;
  border-radius: 2px;
`;

const Header = styled(DescriptionText)`
  font-family: Montserrat;
  font-size: 14px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.21;
  letter-spacing: normal;
  text-align: left;
  color: black;
`;

const TabButton = styled.button`
  padding: 10px 25px !important;
  outline: none !important;
  background-color: #ffffff;
  border: 1px solid #ffffff;
  color: black;
  cursor: pointer;
  float: left;
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  border-bottom: ${props =>
    props && props.tabSelected === "Customer" ? "4px solid #C94593" : null};
  color: ${props => (props && props.tabSelected === "Customer" ? "#C94593" : "#2e2e2e")};
  padding: 0px, 14px;
  &:active {
    color: #c94593;
  }
  &:focus {
    color: #c94593;
  }
`;

const SubHeader = styled.span`
  font-family: Montserrat;
  font-size: 14px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.21;
  letter-spacing: normal;
  text-align: left;
  color: black;
`;

const AddIconCircle = styled.div`
  position: fixed;
  width: 52px;
  height: 52px;
  border-radius: 27px;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.1);
  background-color: #20e12d;
  float: right;
  cursor: pointer;
  bottom: 40px;
  right: 10px;
`;

const ItemDescription = styled.span`
  opacity: 0.5;
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

const AddIcon = styled.span`
  font-size: 35px;
  opacity: 1;
  color: #ffffff;
  font-weight: bold;
  text-align: center;
  display: block;
`;

class TabView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tabSelected: "Vendor",
      showClusterView: false,
      showEditCluster: false,
      customerlist: this.props.customerlist,
      vendorlist: this.props.vendorlist,
      customerClusterData: this.props.customerClusterData,
      vendorClusterData: this.props.vendorClusterData,
      itemSelected: null
    };
    this.onTabClick = this.onTabClick.bind(this);
    this.showDescription = this.showDescription.bind(this);
    this.showCluster = this.showCluster.bind(this);
    this.showEditCluster = this.showEditCluster.bind(this);
    this.closeClusterView = this.closeClusterView.bind(this);
    this.closeEditCluster = this.closeEditCluster.bind(this);
  }

  componentWillMount() {
    this.props.clusterData();
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      customerlist: nextProps.customerlist,
      vendorlist: nextProps.vendorlist,
      customerClusterData: nextProps.customerClusterData,
      vendorClusterData: nextProps.vendorClusterData
    });
  }

  onTabClick(event) {
    this.setState({
      tabSelected: event.target.id
    });
  }

  clusterFilter(ccustomers) {
    this.props.clusterFilter(ccustomers);
  }

  customerListInflow(customer) {
    this.props.customerListInflow(customer);
  }

  createNewCustomerCluster(customerids, name) {
    this.props.createNewCluster(customerids, name);
  }

  editCustomerCluster(clusterId, name, customerIds) {
    this.props.editCustomerCluster(clusterId, name, customerIds);
  }

  editVendorCluster(clusterId, name, customerIds) {
    this.props.editVendorCluster(clusterId, name, customerIds);
  }

  createNewVendorCluster(customerids, name) {
    this.props.createNewCluster(customerids, name);
  }

  showEditCluster() {
    this.setState({
      showEditCluster: true
    });
  }

  closeEditCluster() {
    this.setState({
      showEditCluster: false
    });
  }

  showCluster() {
    this.setState({
      itemSelected: null,
      showClusterView: true
    });
    if (this.props.customerlist.length === 0) {
      this.state.tabSelected === "Customer"
        ? this.props.getCustomersList()
        : this.props.getVendorsList();
    }
  }

  closeClusterView() {
    this.setState({
      showClusterView: false
    });
  }

  onEditItem(e, item) {
    const ids = item.customerlist.map(i => ({ id: i.id }));
    this.props.addExistingIds(ids);
    this.setState({
      itemSelected: item,
      showClusterView: true
    });
    if (this.props.customerlist.length === 0) {
      this.state.tabSelected === "Customer"
        ? this.props.getCustomersList()
        : this.props.getVendorsList();
    }
  }

  showDescription(data) {
    let listItem = [];
    listItem = data.map(item => (
      <DescriptionText>
        <SubHeader> {item.title} </SubHeader>
        <br />
        <PencilImg
          imageURL={require("../../images/dashboard/pencil-edit-button.svg")}
          onClick={e => {
            this.onEditItem(e, item);
          }}
        />
        {/* {this.state.showCluster && (
          <CreateCluster
            tabSelected={this.state.tabSelected}
            customerListInflow={this.props.customerListInflow.bind(this)}
            createNewCustomerCluster={this.props.createNewCustomerCluster.bind(this)}
            createNewVendorCluster={this.props.createNewVendorCluster.bind(this)}
            title={item.title}
            customer={this.props.customer}
            customerlist={item.customerlist}
            closeModalHandler={this.closeClusterView}
            isShowingModal={this.state.showClusterView}
          />
        )} */}

        <ItemDescription>{item.description}</ItemDescription>
        <br />
      </DescriptionText>
    ));
    return listItem;
  }

  render() {
    const data = this.state.customerClusterData;
    const vdata = this.state.vendorClusterData;
    return (
      <Container fluid style={{ position: "relative" }}>
        <TabBody>
          <div
            style={{
              position: "absolute",
              width: "100%",
              height: "55vh",
              filter: this.state.showClusterView ? "blur(4px)" : null
            }}
          >
            <ButtonGroupComponent>
              <TabButton
                onClick={event => this.onTabClick(event)}
                id="Customer"
                tabSelected="customer"
                style={{
                  borderBottom: this.state.tabSelected === "Customer" ? "4px solid #C94593" : null,
                  color: this.state.tabSelected === "Customer" ? "#C94593" : "#2e2e2e",
                  padding: "0px, 14px"
                }}
              >
                Customer
              </TabButton>
              <TabButton
                onClick={event => this.onTabClick(event)}
                id="Vendor"
                style={{
                  borderBottom: this.state.tabSelected === "Vendor" ? "4px solid #C94593" : null,
                  color: this.state.tabSelected === "Vendor" ? "#C94593" : "#2e2e2e",
                  padding: "0px, 14px"
                }}
              >
                Vendor
              </TabButton>
            </ButtonGroupComponent>
            <TabContent>
              <div>
                <Description>
                  <Header>
                    Total {this.state.tabSelected === "Customer" ? data.length : vdata.length}
{" "}
                  </Header>
                  {this.state.tabSelected === "Vendor" && this.showDescription(vdata)}
                  {this.state.tabSelected === "Customer" && (
                    <DescriptionText>
                      <SubHeader>{this.showDescription(data)} </SubHeader>
                    </DescriptionText>
                  )}
                </Description>
              </div>
              <AddIconCircle onClick={() => this.showCluster()}>
                <AddIcon>&#x271B;</AddIcon>
              </AddIconCircle>
            </TabContent>
          </div>
          {this.state.showClusterView && (
            <CreateCluster
              tabSelected={this.state.tabSelected}
              customerListInflow={this.props.customerListInflow.bind(this)}
              createNewCustomerCluster={this.props.createNewCustomerCluster.bind(this)}
              createNewVendorCluster={this.props.createNewVendorCluster.bind(this)}
              editCustomerCluster={this.props.editCustomerCluster.bind(this)}
              editVendorCluster={this.props.editVendorCluster.bind(this)}
              customer={this.props.customer}
              customerIds={this.props.customerIds}
              clusterFilter={this.props.clusterFilter}
              itemSelected={this.state.itemSelected}
              customerlist={
                this.state.tabSelected === "Customer"
                  ? this.state.customerlist
                  : this.state.vendorlist
              }
              closeModalHandler={this.closeClusterView}
              isShowingModal={this.state.showClusterView}
              clearCustomers={this.props.clearCustomers}
              removeExistingIds={this.props.removeExistingIds}
            />
          )}
        </TabBody>
      </Container>
    );
  }
}
const mapStateToProps = state => ({
  ccustomers: state.inflow.ccustomers,
  customerClusterData: state.inflow.customerClusterData,
  vendorClusterData: state.inflow.vendorClusterData,
  customerlist: state.inflow.customerlist,
  customer: state.inflow.customer,
  customerIds: state.inflow.customerIds,
  vendorlist: state.outflow.vendorlist
});
const mapDispatchToProps = dispatch => {
  return {
    clusterFilter: ccustomers => dispatch(clusterFilter(ccustomers)),
    clusterData: () => dispatch(clusterData()),
    getCustomersList: () => dispatch(getCustomersList()),
    getVendorsList: () => dispatch(getVendorsList()),
    customerListInflow: customer => dispatch(customerListInflow(customer)),
    createNewCustomerCluster: (customerids, name) =>
      dispatch(createNewCustomerCluster(customerids, name)),
    createNewVendorCluster: (customerids, name) =>
      dispatch(createNewVendorCluster(customerids, name)),
    editCustomerCluster: (clusterId, name, customerids) =>
      dispatch(editCustomerCluster(clusterId, name, customerids)),
    editVendorCluster: (clusterId, name, customerids) =>
      dispatch(editVendorCluster(clusterId, name, customerids)),
    clearCustomers: () => dispatch({ type: "CLEAR_CUSTOMERS" }),
    addExistingIds: ids => dispatch({ type: "ADD_EXISTING_IDS", ids }),
    removeExistingIds: customerIds => dispatch({ type: "REMOVE_EXISTING_IDS", customerIds })
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TabView);
