import React, { Component } from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import ButtonGroupComponent from "./ButtonGroupComponent";

import DatePickerApply from "../DatepickerApply";

const Title = styled.span`
  font-family: Nunito;
  font-size: 15px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.33;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;

class SubHeaderComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fromDate: "",
      toDate: ""
    };
  }

  render() {
    return (
      <Container
        fluid
        style={{
          backgroundColor: "#ffffff",
          padding: "10px 16px",
          borderBottom: "solid 1px #ebebeb",
          display: "flex"
        }}
      >
        <Row className="w-100">
          <Col className="align-self-center" xl={2} lg={2} md={2} sm={2} xs={2}>
            <Title>Total cashflow</Title>
          </Col>
          <Col xl={7} lg={6} md={6} sm={7} xs={7}>
            <DatePickerApply
              applyDatePicker={this.props.applyDatePicker}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
            />
          </Col>

          <Col
            xl={3}
            lg={4}
            md={4}
            sm={3}
            xs={3}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-evenly",
              textAlign: "center"
            }}
          >
            <ButtonGroupComponent
              values={["Day", "Week", "Month"]}
              onButtonSelect={this.props.onButtonSelectDashboard}
              datefilter={this.props.datefilter}
            />
            {/* <FontAwesomeIcon
              icon={faEllipsisV}
              style={{ fontSize: "18", color: "#2e2e2e", opacity: "0.5", textAlign: "center" }}
            /> */}
          </Col>
        </Row>
      </Container>
    );
  }
}

export default SubHeaderComponent;
