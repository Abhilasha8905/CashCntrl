import React from "react";
import "./FilterCheckList.css";
import styled from "styled-components";
import SearchIcon from "../../images/search/search.png";

const Input = styled.input`
  border: none;
  width: 100%;
  padding: 0px 25px;
  margin-left: 18px;
  outline: none !important;
`;
const CheckDataList = styled.div`
  height: ${props => (props && props.height ? props.height : "45vh")};
  overflow-y: scroll;
  margin-left: 10px;
`;
const SearchItem = styled.div`
  position: relative;
  padding: 5px 10px;
  border-bottom: 1px solid rgb(0, 0, 0, 0.16);
  margin: 8px 13px;
`;
const SearchItemImg = styled.img.attrs({
  src: SearchIcon
})`
  position: absolute;
  margin-left: 8px;
  padding-top: 5px;
  opacity: 0.5;
`;
const ApplyButton = styled.div`
  width: 100%;
  padding: 10px;
`;
const Block = styled.button`
  width: 100%;
  padding: 5px 10px;
  font-size: 12px;
  opacity: 0.6;
  cursor: pointer;
  text-align: center;
  border: solid 1px var(--black);
  background-color: #ffffff;
  margin-left: 0px;
  margin-top: 10px;
`;

const ListLabel = styled.label`
  font-family: Nunito;
  font-size: 13px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: rgba(0, 0, 0);
`;

class ClusterInflowFilter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      search: "",
      checked: false,
      customerlist: this.props.customerlist,
      searchList: [],
      addedProducts: [],
      addedIds: [],
      count: 0
    };

    this.filterList = this.filterList.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.state.customerlist.length === 0 ||
      this.state.customerlist.length !== nextProps.customerlist.length
    ) {
      this.setState({
        customerlist: nextProps.customerlist
      });
    }
  }

  updateSearch(event) {
    this.setState({ search: event.target.value });
    this.filterList(event.target.value);
  }

  filterList(searchitem) {
    const data = this.state.customerlist;

    const dd = data.filter(d => {
      if (d.name.toLowerCase().search(searchitem.toLowerCase()) !== -1) {
        return d;
      }
    });

    this.setState({
      searchItem: dd,
      searchList: dd
    });
  }

  onAddingItem(item) {
    const isChecked = item.target.checked;
    const { value } = item.target;
    const { id } = item.target;
    if (this.state.searchList.length != 0) {
      this.setState(prevState => ({
        searchList: prevState.searchList.map(product =>
          product.name === value ? { ...product, isAdded: !this.state.checked } : product
        )
      }));
    }
    const customers = this.state.customerlist.map(product => {
      return product.name === value ? { ...product, isAdded: isChecked } : product;
    });
    console.log(customers);
    this.setState({
      customerlist: customers
    });
    const customer = {
      id: parseInt(id),
      name: value,
      isAdded: isChecked
    };
    this.props.customerListInflow(customer);
  }

  applyFilter() {
    this.setState({
      searchList: "",
      search: ""
    });
  }

  render() {
    console.log(this.state.customerlist, this.props.customerlist, "from filterchecklist");
    const search = this.state.searchList;
    let list = [];
    if (search.length != 0) {
      list = search;
    } else {
      list = this.state.customerlist;
    }

    const outputCheckboxes = list.map(function(index, i) {
      return (
        <div
          className="custom-control custom-checkbox"
          key={i}
          style={{ marginLeft: "0.85rem", marginBottom: "3px !important" }}
        >
          <ul className="list-group list-group-flush">
            <li className="list-item">
              <input
                type="checkbox"
                className="custom-control-input"
                id={list[i].id}
                value={index.name}
                checked={list[i].isAdded}
                onClick={this.onAddingItem.bind(this)}
              />
              <label
                className="custom-control-label listLabel"
                htmlFor={list[i].id}
                style={{ paddingTop: "4px" }}
              >
                {index.name}
              </label>
            </li>
          </ul>
        </div>
      );
    }, this);
    return (
      <div
        className="container"
        style={{
          maxWidth: "100%",
          paddingLeft: "0",
          paddingRightt: "0",
          paddingTop: "0",
          boxShadow: this.props.boxShadow
            ? this.props.boxShadow
            : "0 5px 10px 0 rgba(0, 0, 0, 0.04)"
        }}
      >
        <SearchItem>
          <SearchItemImg className="search-1" />
          <Input
            value={this.state.search}
            onChange={this.updateSearch.bind(this)}
            placeholder="Search"
          />
        </SearchItem>
        {/* <div class="topnav">
  <input type="text" placeholder="Search.." />
    <a href="#" class="search_icon"><i class="fas fa-search"></i></a>
</div> */}

        <CheckDataList>{outputCheckboxes}</CheckDataList>
        {/* <ApplyButton>
          <Block onClick={this.applyFilter.bind(this)}>Apply </Block>
        </ApplyButton> */}
      </div>
    );
  }
}

export default ClusterInflowFilter;
