import React from "react";
import "./tooltip.css";

class ToolTip extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { state } = this;

    return (
      <div id="tooltip" className="on top">
        <div className="tooltip-arrow" />
        <div className="tooltip-inner">"Entered data doesnt exist"</div>
      </div>
    );
  }

  componentDidMount() {}

  componentWillUnmount() {}
}
export default ToolTip;
