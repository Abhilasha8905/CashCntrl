import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";

import Header from "../../containers/Header/header";
import Navbar from "./navbar";

class ContainerComponent extends Component {
  render() {
    return (
      <Container fluid className="container-fluid custom-nav-container">
        <Row>
          <Col lg={1}>
            <h4 className="page-header">My</h4>
          </Col>
          <Col lg={11} style={{ backgroundColor: "#fbfcfe" }}>
            <Header />
            <Navbar />
          </Col>
        </Row>
      </Container>
    );
  }
}

export default ContainerComponent;
