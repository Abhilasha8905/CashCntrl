import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";
import _ from "lodash";
import moment from "moment-timezone";
import datas from "./data/Customerdata.json";

class BarChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      options: {
        chart: {
          toolbar: {
            show: false
          }
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "30%"
          }
        },
        dataLabels: {
          enabled: false
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              legend: {
                position: "bottom",
                offsetX: -10,
                offsetY: 0
              }
            }
          }
        ],
        grid: {
          show: true,
          borderColor: "#fffff",
          strokeDashArray: 0,
          position: "back",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          }
        },

        dataLabels: {
          enabled: false,
          hideOverflowingLabels: true
        },
        xaxis: {
          categories: [...this.props.date]
        }
      },
      series: [
        {
          data: [...this.props.amount]
        }
      ]
    };
  }
  componentWillReceiveProps(nextProps) {
    this.setState(prevState => ({
      ...prevState,
      options: {
        ...prevState.options,
        xaxis: {
          ...prevState.options.xaxis,
          categories: nextProps.date
        }
      }
    }));
    this.setState(prevState => ({
      ...prevState,
      series:[
        {
          data: nextProps.amount
        }
      ]
      
    }));
    
  }
  render() {
    var chartWidth = (this.props.date.length>25) ? 100 * this.props.date.length : "100%";
    return (
      
        <ReactApexChart
          options={this.state.options}
          series={this.state.series}
          type="bar"
          width={chartWidth}
          height="100%"
        />
      
    );
  }
}

export default BarChart;
