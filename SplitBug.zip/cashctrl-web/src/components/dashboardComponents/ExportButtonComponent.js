import "./button.css";
import React from "react";

class ExportButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.sayHello = this.sayHello.bind(this);
  }

  sayHello(event) {
  }
  render() {
    return (
      <button onClick={this.sayHello}>
        <img src={require("./images/export.png")} /> Export Data
      </button>
    );
  }
}
export default ExportButton;
