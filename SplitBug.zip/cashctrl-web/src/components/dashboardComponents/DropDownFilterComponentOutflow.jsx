import React, { Component } from "react";
import ReactDOM from "react-dom";
import styled from "styled-components";
import EqualsFilterComponentOutflow from "./EqualsFilterComponentOutflow";
import RangeAmount from "./RangeAmountOutflow";

const Container = styled.div`
  display: inline-block;
  width: 100%;
  min-width: 150px;
`;
const DropDownContainer = styled.div`
  width: auto;
  display: flex;
  line-height: 15px;
  overflow: hidden;
  width: 123px;
  opacity: 0.5;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  cursor: ${props => (props.showCursor ? `pointer` : `default`)};
`;
const DropDownTitle = styled.div`
  display: inline-flex;
  width: auto;
  font-weight: bold;
`;
const DropIcon = styled.div`
  display: inline-flex;
  float: right;
  align-items: center;
`;

const ListContainer = styled.ul`
  list-style: none;
  padding: 0;
  color: #2e2e2e;
  border-radius: 0px;
  margin-top: 17px;
  cursor: pointer;
  display: block;
  font-size: 12px;
  line-height: 15px;
  background: #fff;
  position: fixed;
  margin-left: -100px;
  z-index: 30;
  width: ${props => (props.width ? props.width : "100%")};
  border-top: 1px solid #ebebeb;
  overflow-y: auto;
  border: 2px solid #ebebeb;
  max-height: 186px;
`;
const ListElement = styled.li`
  padding: 3px 10px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  text-transform: capitalize;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;
const SelectedValue = styled.span`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-right: 10px;
  text-transform: capitalize;
`;

const CalendarImg = styled.img.attrs({
  src: props => props.imageURL
})`
  width: 10px;
  justify-content: flex-end;
`;

const list = [
  {
    title: "Equals"
  },
  {
    title: "Does Not Equal"
  },
  {
    title: "Greater Than"
  },
  {
    title: "Greater Than or Equal To"
  },
  {
    title: "Less Than"
  },
  {
    title: "Less Than or Equal To"
  },
  {
    title: "Between"
  }
];

const List = props => {
  return (
    <ListContainer width={props.width}>
      {props.list.map((value, index, array) => {
        return (
          <ListElem key={index} value={value} handleChange={props.handleChange} type={props.type} />
        );
      })}
    </ListContainer>
  );
};
const ListElem = props => {
  const { title } = props.value;
  const onclick = e => {
    e.stopPropagation();
    const { value } = props;
    props.handleChange(value);
  };

  return (
    <ListElement title={title} onClick={onclick}>
      <span>{title}</span>
    </ListElement>
  );
};
class DropDown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showList: false,
      showDailog: false,
      selectedValue: props.selectedValue
    };
    this.onclick = this.onclick.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
  }

  onclick() {
    const val = !this.state.showList;
    this.setState(
      {
        showList: val
      },
      () => {
        if (val) {
          document.addEventListener("mousedown", this.handleClickOutside);
        } else {
          document.removeEventListener("mousedown", this.handleClickOutside);
        }
      }
    );
  }

  handleChange(value) {
    this.setState({
      selectedValue: value.title,
      showDailog: true
    });
    this.props.setValues(value.title);
    this.onclick();
    // this.props.changeMethod(value.handle || value.title);
  }

  componentDidMount() {
    document.addEventListener("click", this.handleClickOutside, true);
  }

  componentWillUnmount() {
    document.removeEventListener("click", this.handleClickOutside, true);
  }

  handleClickOutside(event) {
    const domNode = ReactDOM.findDOMNode(this);
    if (!domNode || !domNode.contains(event.target)) {
      this.setState({
        showList: false,
        showDailog: false
      });
    }
  }

  hideDIalog(event) {
    this.setState({
      showDailog: false,
      showList: false
    });
  }

  render() {
    return (
      <Container>
        <DropDownContainer onClick={this.onclick} showCursor={this.list}>
          Set Filters
          <DropIcon>
            <CalendarImg imageURL={require("../../images/header/DropDownIcon.png")} />
          </DropIcon>
        </DropDownContainer>
        {this.state.showList && !this.state.showDailog && list && (
          <List handleChange={this.handleChange} list={list} width={this.props.width} />
        )}
        {this.state.showDailog && this.props.options !== "Between" && (
          <EqualsFilterComponentOutflow
            width="250px"
            hideDIalog={event => this.hideDIalog(event)}
            options={this.props.options}
            enteredAmountOutflow={this.props.enteredAmountOutflow}
          />
        )}
        {this.state.showDailog && this.props.options === "Between" && (
          <RangeAmount
            width="250px"
            hideDIalog={event => this.hideDIalog(event)}
            rangeOutflow={this.props.rangeOutflow}
            options={this.props.options}
          />
        )}
      </Container>
    );
  }
}
DropDown.defaultProps = {
  selectedValue: "None",
  children: (props, val) => {
    return (
      <DropDownTitle>
        <SelectedValue>{val}</SelectedValue>
      </DropDownTitle>
    );
  }
};

export default DropDown;
