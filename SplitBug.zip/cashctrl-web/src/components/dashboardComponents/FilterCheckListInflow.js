import React from "react";
import "./FilterCheckList.css";
import styled from "styled-components";
import SearchIcon from "../../images/search/search.png";
import { getNames } from "../../utility/newutil";

const Input = styled.input`
  border: none;
  width: 100%;
  padding: 0px 25px;
  margin-left: 18px;
  outline: none !important;
`;
const CheckDataList = styled.div`
  height: ${props => (props && props.height ? props.height : "45vh")};
  overflow-y: auto;
  margin-left: 10px;
`;
const SearchItem = styled.div`
  position: relative;
  padding: 5px 10px;
  border-bottom: 1px solid rgb(0, 0, 0, 0.16);
  margin: 8px 13px;
`;
const SearchItemImg = styled.img.attrs({
  src: SearchIcon
})`
  position: absolute;
  margin-left: 8px;
  padding-top: 5px;
  opacity: 0.5;
`;
const ApplyButton = styled.div`
  width: 100%;
  padding: 10px;
`;
const Block = styled.button`
  width: 100%;
  padding: 5px 10px;
  font-size: 12px;
  opacity: 1;
  cursor: pointer;
  text-align: center;
  border: solid 1px var(--black);
  background-color: #ffffff;
  margin-left: 0px;
  margin-top: 10px;
`;

const ListLabel = styled.label`
  font-family: Nunito;
  font-size: 13px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: rgba(0, 0, 0);
`;

class FilterCheckListInflow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      search: "",
      checked: false,
      productsList: this.props.productsList,
      initialList: [],
      searchList: [],
      addedProducts: [],
      addedClusters: [],
      addedIds: [],
      count: 0,
      buttonTitle: "Apply"
    };
    this.applyFilter = this.applyFilter.bind(this);
    this.handleButtonClick = this.handleButtonClick.bind(this);
    this.filterList = this.filterList.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      productsList: nextProps.productsList
    });
  }

  updateSearch(event) {
    this.setState({ search: event.target.value });
    this.filterList(event.target.value);
  }

  filterList(searchitem) {
    const data = this.state.productsList;

    const dd = data.filter(d => {
      if (d.name.toLowerCase().search(searchitem.toLowerCase()) !== -1) {
        return d;
      }
    });

    this.setState({
      searchItem: dd,
      searchList: dd
    });
  }

  onAddingItem(item) {
    const isChecked = item.target.checked;
    let valueSelected = [];
    if (this.props.tabSelected === "Cluster View") {
      const listItems = this.props.customerClusterData.filter(
        i => i.title.split("(")[0] === item.target.value
      );
      valueSelected = listItems[0].customerlist.map(v => v.name);
    }
    const { value } = item.target;
    const { id } = item.target;
    const { count } = this.state;
    if (this.state.searchList.length != 0) {
      this.setState(prevState => ({
        searchList: prevState.searchList.map(product =>
          product.name === value ? { ...product, isAdded: isChecked } : product
        )
      }));
    }
    this.setState(prevState => ({
      productsList: prevState.productsList.map(product =>
        product.name === value ? { ...product, isAdded: isChecked } : product
      )
    }));

    if (isChecked) {
      if (this.props.tabSelected === "Cluster View") {
        this.setState(prevState => ({
          addedProducts: [...prevState.addedProducts, ...valueSelected]
        }));
        this.setState(prevState => ({ addedClusters: [...prevState.addedClusters, value] }));
      } else {
        this.setState(prevState => ({ addedProducts: [...prevState.addedProducts, value] }));
        this.setState(prevState => ({ addedIds: [...prevState.addedIds, id] }));
        this.setState({
          count: this.state.addedProducts.length + 1
        });
      }
    } else {
      let newAddedProducts = [];
      let newAddedClusters = [];
      if (this.props.tabSelected === "Cluster View") {
        newAddedProducts = this.state.addedProducts.filter(function(el) {
          return valueSelected.indexOf(el) < 0;
        });
        newAddedClusters = this.state.addedClusters.filter(product => product !== value);
        this.setState({ addedClusters: newAddedClusters });
      } else {
        newAddedProducts = this.state.addedProducts.filter(product => product !== value);
        this.setState({ addedProducts: newAddedProducts });
        const newAddedIds = this.state.addedIds.filter(product => product !== id);
        this.setState({ addedIds: newAddedIds });
      }
    }
  }

  // updateSearch(event) {
  //   this.setState({ search: event.target.value });
  //   this.filterList(this.state.productsList,this.state.search)
  // }

  applyFilter() {
    if (this.props.tabSelected === "Cluster View") {
      this.props.customerFilterInflow(this.state.addedProducts, this.state.addedClusters);
    } else {
      this.props.customerFilterInflow(this.state.productsList);
    }
    this.setState({
      searchList: "",
      search: ""
    });
  }

  handleButtonClick() {
    if (this.state.buttonTitle === "Apply" && this.state.addedProducts.length > 0) {
      this.setState({
        initialList: this.props.initialList,
        buttonTitle: "Clear"
      });
      this.applyFilter();
    } else {
      this.setState({
        buttonTitle: "Apply",
        productsList: this.state.initialList,
        addedProducts: [],
        addedClusters: []
      });
      this.props.inflowUpdate();
    }
  }

  render() {
    console.log("from filterchecklist",this.state.productsList)
    const search = this.state.searchList;
    let list = [];
    if (search.length != 0) {
      list = search;
    } else {
      if (this.props.tabSelected === "Cluster View" && this.state.buttonTitle === "Clear") {
        list = this.props.productsList.filter((i) => this.state.addedClusters.indexOf(i.name) !== -1)
      } else {
        list = this.state.productsList;
      }
      
    }

    const outputCheckboxes = list.map(function(index, i) {
      return (
        <div
          className="custom-control custom-checkbox"
          key={i}
          style={{ marginLeft: "0.85rem", marginBottom: "3px !important" }}
        >
          <ul className="list-group list-group-flush">
            <li className="list-item">
              <input
                type="checkbox"
                className="custom-control-input"
                id={list[i].id}
                value={index.name}
                checked={this.state.addedClusters.indexOf(index.name) !== -1 ? true : list[i].isAdded}
                onChange={this.onAddingItem.bind(this)}
              />
              <label
                className="custom-control-label listLabel"
                htmlFor={list[i].id}
                style={{ paddingTop: "4px" }}
              >
                {index.name}
              </label>
            </li>
          </ul>
        </div>
      );
    }, this);
    return (
      <div
        className="container"
        style={{
          maxWidth: "100%",
          paddingLeft: "0",
          paddingRightt: "0",
          paddingTop: "5px",
          background: "white"
        }}
      >
        <SearchItem>
          <SearchItemImg className="search-1" />
          <Input
            value={this.state.search}
            onChange={this.updateSearch.bind(this)}
            placeholder="Search"
          />
        </SearchItem>
        {/* <div class="topnav">
  <input type="text" placeholder="Search.." />
    <a href="#" class="search_icon"><i class="fas fa-search"></i></a>
</div> */}

        <CheckDataList>{outputCheckboxes}</CheckDataList>
        <ApplyButton>
          <Block onClick={() => this.handleButtonClick()}>{this.state.buttonTitle} </Block>
        </ApplyButton>
      </div>
    );
  }
}

export default FilterCheckListInflow;
