import React from "react";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes } from "@fortawesome/free-solid-svg-icons";

const OuterBox = styled.div`
  padding: 0;
  color: #2e2e2e;
  border-radius: 5px;
  margin-top: 2px;
  cursor: pointer;
  display: block;
  font-size: 12px;
  font-weight: 500;
  line-height: 15px;
  background: #fff;
  position: absolute;
  bottom: 60px;
  right: 0;
  z-index: 30;
  width: 165px;
  height: 138.2px;
  box-shadow: 0 10px 20px 0 rgba(0, 0, 0, 0.1);
  border: solid 2px #ffffff;
  background-color: #ffffff;
`;
const FilterBox = styled.div`
  box-shadow: 0 5px 20px 0 rgba(0, 0, 0, 0.05);
  border: solid 1px rgba(46, 46, 46, 0.13);
  background-color: #ffffff;
`;
const Input = styled.input`
  width: 100%;
  padding: 0.25rem;
  opacity: 0.5;
  border: solid 1px rgba(0, 0, 0, 0.1);
  background-color: #f7f7f9;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 400;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;
const Block = styled.button`
  width: 50%;
  padding: 5px 10px;
  font-size: 14px;
  font-weight: 500;
  color: #c94593;
  cursor: pointer;
  text-align: center;
  border: solid 1px #c94593;
  background-color: #ffffff;
  margin-left: 0px;

  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.16);
`;
const ApplyButton = styled.div`
  width: 100%;
  padding: 10px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: #2e2e2e;
`;
const CloseButton = styled.div`
  color: black;
  cursor: pointer;
  margin-top: -10px;
  object-fit: contain;
  opacity: 0.5;
  float: right;
  font-size: 25px;
  margin-right: 20px;
  boder: none;
  background-color: #ffffff;
  opacity: "0.6";
`;
class EqualsFilterComponentInflow extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      customer: "Customer 2",
      amount: this.props.invoiceValue
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.onclick = this.onclick.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.invoiceValue !== nextProps.invoiceValue)
      this.setState({
        amount: nextProps.invoiceValue
      });
  }

  onclick(event) {
    this.props.hideDIalog(event);
  }

  handleChange(event) {
    this.setState({
      amount: event.target.value
    });
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      values: nextProps.options
    });
  }

  handleSubmit(e) {
    e.preventDefault();

    this.props.splitUpdate(this.state.amount);
    this.setState({ amount: this.props.invoiceValue });
    this.props.hideDIalog(event);
  }

  render() {
    return (
      <OuterBox>
        <FilterBox>
          {" "}
          <ApplyButton>
            {this.state.customer}
            <CloseButton onClick={() => this.onclick()}>
              <FontAwesomeIcon icon={faTimes} style={{ width: "15px", height: "15px" }} />
            </CloseButton>
            <br />
            <form onSubmit={this.handleSubmit}>
              <Input
                type="number"
                placeholder="Enter amount"
                value={this.state.amount}
                onChange={this.handleChange.bind(this)}
              />
              <br />
              <div style={{ paddingTop: "0.5rem" }}>
                <input type="checkbox" />
                <span style={{ opacity: "0.5" }}>Set Reminder</span>
              </div>
              <br />
              <Block>Update</Block>
            </form>
          </ApplyButton>
        </FilterBox>
      </OuterBox>
    );
  }
}

export default EqualsFilterComponentInflow;
