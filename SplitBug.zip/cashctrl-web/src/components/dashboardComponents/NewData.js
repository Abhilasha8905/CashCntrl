import React from "react";

import "./table.css";

class NewData extends React.Component {
  constructor() {
    super();
    this.state = {
      jsondata: [1, 2, 3, 4],
      dashboardType: "CNC",
      totalAmount: ""
    };
  }

  componentWillReceiveProps(nextProps) {
    let totalAmount;
    if (nextProps.dashboardType === "CNCI") {
      totalAmount = this.props.ciClear ? this.props.ciClear : 0;
    } else if (nextProps.dashboardType === "CNCR") {
      totalAmount = this.props.cnClear ? this.props.cnClear : 0;
    } else if (nextProps.dashboardType === "PDC") {
      totalAmount = this.props.pdcIssue;
    } else {
      totalAmount = this.props.bankBalance;
    }

    
      this.setState({
        jsondata: nextProps.dasboardTypeData,
        dashboardType: nextProps.dashboardType,
        totalAmount
      });
    
  }

  renderTableData() {

    return this.state.jsondata.map((data, i) => {
      const td = [];
      {
        for (const x in data) {
          td.push(<td key={x}>{data[x]}</td>);
        }
      }
      return <tr>{td}</tr>;
    });
  }

  renderTableHeader() {
    let header;
    if (this.state.jsondata.length > 0) {
      header = Object.keys(this.state.jsondata[0]);
      return header.map((key, index) => {
        return <th key={index}>{key}</th>;
      });
    }
  }

  render() {
    return (
      <div
        className="table-responsive table-borderless"
        style={{
          overflowY: "auto",
          height: "400px"
        }}
      >
        <table id="students" className="table">
          <tbody>
            <tr>{this.renderTableHeader()}</tr>
            {this.renderTableData()}
          </tbody>
          <tfoot>
            <tr>
              <td className="right" colSpan="6">
                <p style={{ display: "inline" }}>Total:</p>
                <span style={{ display: "inline", color:this.props.titleColor, opacity: 1 }}>&#x20B9;&nbsp;

                {this.state.totalAmount}</span>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    );
  }
}
export default NewData;
