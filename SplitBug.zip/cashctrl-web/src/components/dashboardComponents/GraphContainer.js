import React, { Component } from "react";
import Chart from "react-apexcharts";
import _ from "lodash";

class GraphContainer extends Component {
  constructor(props) {
    super(props);

    this.state = {
      options: {
        chart: {
          toolbar: {
            show: false
          }
        },

        legend: {
          display: false
        },

        stroke: {
          curve: "straight",
          colors: ["#20e12d", "#ffa600", "#c94593"],
          width: 2,
          dashArray: 0
        },
        markers: {
          size: 4,
          colors: ["#20e12d", "#ffa600", "#c94593"],

          strokeOpacity: 0.9,
          fillOpacity: 0,
          discrete: [],
          shape: "circle",
          radius: 2,
          offsetX: 0,
          offsetY: 0,
          onClick: undefined,
          onDblClick: undefined,
          hover: {
            size: undefined,
            sizeOffset: 3
          }
        },

        grid: {
          show: true,
          borderColor: "#90A4AE",
          strokeDashArray: 0,
          position: "front",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          }
        },

        tooltip: {
          shared: false,
          intersect: true
        },
        legend: {
          show: false
        },
        xaxis: {
          type: "category",
          categories: [...this.props.dates],
          tickPlacement: "between"
        },
        yaxis: {
          show: true,
          labels: {
            formatter(value) {
              return `${value}`;
            }
          },
          show: true,
          axisBorder: {
            show: true,
            color: "#78909C",
            offsetX: 1,
            offsetY: 1
          }
        }
      },

      series: [
        {
          name: "Net Bank Balance",
          data: [...this.props.balanceData]
        },
        {
          name: "Inflows",
          data: [...this.props.inFlowData]
        },
        {
          name: "Outflow",
          data: [...this.props.outFlowData]
        }
      ]
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState(prevState => ({
      ...prevState,
      options: {
        ...prevState.options,
        xaxis: {
          ...prevState.options.xaxis,
          categories: nextProps.dates
        }
      },
      series: [
        {
          name: "Net Bank Balance",
          data: nextProps.balanceData
        },
        {
          name: "Inflows",
          data: nextProps.inFlowData
        },
        {
          name: "Outflow",
          data: nextProps.outFlowData
        }
      ]
    }));
  }

  render() {

    const chartWidth = this.props.dates.length > 25 ? 100 * this.props.dates.length : "100%";
   

    return (
      <Chart
        options={this.state.options}
        series={this.state.series}
        type="line"
        width={chartWidth}
        height="100%"
      />
    );
  }
}

export default GraphContainer;
