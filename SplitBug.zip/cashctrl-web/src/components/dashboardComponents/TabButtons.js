import React, { Component } from "react";
import styled from "styled-components";
import { connect } from "react-redux";

const ButtonGroupComponent = styled.div`
  display: block;
  flex-direction: row;
  justify-content: center;
  color: black;
`;

const TabBody = styled.div`
  position: relative;
  max-width: 100%;
`;

const TabContent = styled.div`
  margin: 2%;
  background: #ffffff;
  border-radius: 2px;
`;

const TabButton = styled.button`
  padding: 10px 25px !important;
  outline: none !important;
  background-color: #ffffff;
  border: 1px solid #ffffff;
  color: black;
  cursor: pointer;
  float: left;
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: ${props => (props && props.tabSelected === "Customer" ? "rgba(255, 166, 0)" : "#2e2e2e")};
  padding: 0px, 14px;
  &:active {
    color: rgba(255, 166, 0);
  }
  &:focus {
    color: rgba(255, 166, 0);
  }
`;

class TabButtons extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tabSelected: this.props.buttonOne
    };
    this.onTabClick = this.onTabClick.bind(this);
  }

  onTabClick(event) {
    this.setState({
      tabSelected: event.target.id
    });
    this.props.onTabClick(event.target.id);
  }

  render() {
    return (
      <ButtonGroupComponent>
        <TabButton
          onClick={event => this.onTabClick(event)}
          id={this.props.buttonOne}
          tabSelected={this.state.tabSelected}
          style={{
            borderBottom:
              this.state.tabSelected === this.props.buttonOne
                ? "4px solid rgba(255, 166, 0)"
                : null,
            color:
              this.state.tabSelected === this.props.buttonOne ? "rgba(255, 166, 0)" : "#2e2e2e",
            padding: "0px, 14px"
          }}
        >
          {this.props.buttonOne}
        </TabButton>
        <TabButton
          onClick={event => this.onTabClick(event)}
          id={this.props.buttonTwo}
          tabSelected={this.state.tabSelected}
          style={{
            borderBottom:
              this.state.tabSelected === this.props.buttonTwo
                ? "4px solid rgba(255, 166, 0)"
                : null,
            color:
              this.state.tabSelected === this.props.buttonTwo ? "rgba(255, 166, 0)" : "#2e2e2e",
            padding: "0px, 14px"
          }}
        >
          {this.props.buttonTwo}
        </TabButton>
      </ButtonGroupComponent>
    );
  }
}
const mapStateToProps = state => ({});
const mapDispatchToProps = dispatch => {
  return {};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TabButtons);
