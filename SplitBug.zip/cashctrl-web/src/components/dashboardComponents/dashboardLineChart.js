import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";

class LineChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      options: {
        stroke: {
          curve: "straight",
          colors: ["#c94593", "#20e12d", "#ffa600"],
          width: 2,
          dashArray: 0
        },
        markers: {
          size: 4,
          colors: ["#c94593", "#20e12d", "#ffa600"],

          strokeOpacity: 0.9,
          fillOpacity: 0,
          discrete: [],
          shape: "circle",
          radius: 2,
          offsetX: 0,
          offsetY: 0,
          onClick: undefined,
          onDblClick: undefined,
          hover: {
            size: undefined,
            sizeOffset: 3
          }
        },
        grid: {
          show: true,
          borderColor: "#90A4AE",
          strokeDashArray: 0,
          position: "front",
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            colors: undefined,
            opacity: 0.5
          },
          column: {
            colors: undefined,
            opacity: 0.5
          }
        },

        tooltip: {
          shared: false,
          intersect: true
        },
        legend: {
          show: false
        },
        xaxis: {
          categories: ["06 Jan", "07 Jan", "08 Jan", "09 Jan", "10 Jan", "11 Jan", "12 Jan"]
        },
        yaxis: {
          show: true,
          axisBorder: {
            show: true,
            color: "#78909C",
            offsetX: 3,
            offsetY: 0
          }
        }
      },
      series: [
        {
          name: "Net Bank Balance",
          data: [30, 40, 25, 50, 49, 21, 70]
        },
        {
          name: "Inflows",
          data: [40, 35, 20, 39, 15, 60]
        },
        {
          name: "Outflow",
          data: [25, 30, 60, 75, 20, 10, 35]
        }
      ]
    };
  }

  render() {
    return (
      <div id="chart">
        <ReactApexChart options={this.state.options} series={this.state.series} type="line" />
      </div>
    );
  }
}

export default LineChart;
