import React from "react";
import ClusterButton from "./dashboardComponents/ClusterComponent";

class CustomerCluster extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {

    return (
      <ClusterButton
        buttonName={this.props.buttonName ? this.props.buttonName : null}
        tabSelected={this.props.tabSelected}
        clustorView={this.props.clustorView}
        name={
          this.props.tabSelected === "inflows"
            ? "Customer Cluster"
            : "Vendor Cluster"
        }
        image={
          this.props.tabSelected === "inflows"
            ? require("./../images/dashboard/meeting.svg")
            : require("./../images/dashboard/vendor.svg")
        }
        style={{ float: "right" }}
      />
    );
  }
}
export default CustomerCluster;
