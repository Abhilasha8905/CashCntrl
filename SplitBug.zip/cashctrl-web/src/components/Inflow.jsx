import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import styled from "styled-components";
import moment from "moment-timezone";
import SubHeaderInflow from "./SubHeaderInflow";
import CustomerView from "./CustomerView";
import GroupByDayComponentInflow from "./dashboardComponents/GroupByDayComponentInflow";
import InflowFilter from "./dashboardComponents/InflowFilter";
import WrapperChartInflow from "./dashboardComponents/WrapperChartInflow";
import CustomerDetailsGraph from "./dashboardComponents/CustomerDetailsGraph";
import CollectionsGraph from "./dashboardComponents/CollectionsGraph";
import EqualsFilter from "./dashboardComponents/EqualsFilterComponentInflow";

// import CustomerVendorView from '../../CustomerVendorView';

const GraphDiv = styled.div`
  background-color: white;
  height: calc(100vh - 230px);
  overflow: hidden;

`;
const ParentDiv = styled.div`
  background-color: white;
  height: calc(100vh - 230px);`
  ;

const GraphImg = styled(Image).attrs({
  src: props => props.imageURL
})`
  margin: 0%;
`;
const RowContainer = styled(Row)`
  margin-left: -1px;
  margin-right: -1px;
`;

const Div = styled.div`
  display: flex;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
  flex-direction: column;
`;

class Inflow extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isShowingModal: false,
      data: "",
      inflowGraph: {
        currentPage: 0,
        numberOfPages: 1
      }
    };

    this.inflowGraphParentRef = React.createRef();

    this.openModalHandler = this.openModalHandler.bind(this);
    this.closeModalHandler = this.closeModalHandler.bind(this);
    this.getWeekRangeFromWeekNum = this.getWeekRangeFromWeekNum.bind(this);
    this.inflowGraphNextPage = this.inflowGraphNextPage.bind(this);
    this.inflowGraphPrevPage = this.inflowGraphPrevPage.bind(this);
    this.initializeInflowGraphState = this.initializeInflowGraphState.bind(this);
  }

  componentDidMount() {
    this.initializeInflowGraphState();
    this.scrollInflowGraph();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.dates !== this.props.dates) {
      this.initializeInflowGraphState();
    }

    if (prevState.inflowGraph.currentPage !== this.state.inflowGraph.currentPage) {
      this.scrollInflowGraph();
    }
  }

  scrollInflowGraph() {
    const inflowGraphParent = this.inflowGraphParentRef.current;
    const parentWidth = inflowGraphParent.clientWidth;
    inflowGraphParent.scrollLeft = parentWidth * this.state.inflowGraph.currentPage;
  }

  initializeInflowGraphState() {
    const inflowGraphParent = this.inflowGraphParentRef.current;
    const parentWidth = inflowGraphParent.clientWidth;
    const graphWidth = (this.props.dates.length > 25) ? 100 * this.props.dates.length : parentWidth;
    const numberOfPages = Math.ceil(graphWidth / parentWidth);
    this.setState({
      inflowGraph: {
        currentPage: 0,
        numberOfPages
      }
    });
  }

  inflowGraphNextPage() {
    this.setState((state) => {
      if (state.inflowGraph.currentPage < state.inflowGraph.numberOfPages - 1) {
        return {
          ...state,
          inflowGraph: { ...state.inflowGraph, currentPage: state.inflowGraph.currentPage + 1 }
        };
      }
      return state;
    });
  }

  inflowGraphPrevPage() {
    this.setState((state) => {
      if (state.inflowGraph.currentPage > 0) {
        return {
          ...state,
          inflowGraph: { ...state.inflowGraph, currentPage: state.inflowGraph.currentPage - 1 }
        }
      };
      return state;
    });
  }

  getWeekRangeFromWeekNum(weekNumber) {
    let range;
    const beginningOfWeek = moment()
      .week(weekNumber)
      .startOf("week");
    const endOfWeek = moment()
      .week(weekNumber)
      .startOf("week")
      .add(6, "days");
    range = `${beginningOfWeek.format(" DD MMM")}-${endOfWeek.format(" DD MMM")}`;
    return range;
  }

  openModalHandler(datePoint, seriesName, id = "") {
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "June",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];
    let date = datePoint;
    if (this.props.datefilter === "Day") {
      date = moment(datePoint).format("MM/DD/YYYY")
    }
    if (datePoint) {
      const point = this.props.groupedData[date].filter(i => i.name === seriesName.name);
      this.props.dataPointInflow(point.length > 0 ? point[0].id : "Other");
    } else {
      this.props.dataPointInflow(id);
    }
    const j = this.props.otherCollections.filter((i, m) =>
      this.props.datefilter === "Month"
        ? i.date === months[date - 1]
        : this.props.datefilter === "Week"
        ? i.date === this.getWeekRangeFromWeekNum(date)
        : i.date === date
    );
    this.setState({
      data: j
    });
    if (j.length > 0 && seriesName.name === "OtherCollections") {
      this.setState({
        isShowingModal: true
      });
    } else if (seriesName.name !== "OtherCollections") {
      let pointId;
      if (datePoint) {
        pointId = this.props.groupedData[date].filter(i => i.name === seriesName.name);
      }
      this.props.getCustomerDetailsonId(
        datePoint ? pointId[0].id : id,
        this.props.fromDate,
        this.props.toDate
      );
      this.setState({
        isShowingModal: true
      });
    }
  }

  closeModalHandler(close, id) {
    this.setState({
      isShowingModal: false
    });
    if (!close) {
      this.openModalHandler(false, false, id);
    }
  }


  render() {
    const filterValue = this.state.isShowingModal;
    return (
      <Container style={{ maxWidth: "100%", height: "100%", position: "relative" }}>
        <Row
          style={{
            position: "absolute",
            width: "100%",
            height: "100%",
            filter: filterValue ? "blur(5px) grayscale(80%)" : null
          }}
        >
          <Col xl={9} lg={9} md={12} xs={12} style={{ backgroundColor: "rgb(248, 249, 251)" }}>
            <div style={{background:"white",height:"inherit"}}>
            <SubHeaderInflow
              applyDatePicker={this.props.applyDatePicker}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              onButtonSelect={this.props.onButtonSelect}
              datefilter={this.props.datefilter}
            />
            <CustomerView
              setFilterOptionsInflow={this.props.setFilterOptionsInflow}
              collectionsInflow={this.props.collectionsInflow}
              options={this.props.options}
              enteredAmountInflow={this.props.enteredAmountInflow}
              rangeInflow={this.props.rangeInflow}
            />
            <ParentDiv>
              <GraphDiv ref={this.inflowGraphParentRef}>
                <GroupByDayComponentInflow
                  openModalHandler={this.openModalHandler}
                  dates={this.props.dates}
                  series={this.props.series}
                  getClusterData={this.props.getClusterData}
                  dataPointInflow={this.props.dataPointInflow}
                  customerDataFromId={this.props.customerDataFromId}
                  fullDates={this.props.fullDates}
                />
                <WrapperChartInflow sum={this.props.sum} />
              </GraphDiv>
              <div style=
              {{width:"30px",height:"30px",background:"white",position:"absolute",bottom:"26px",border:"1px solid #ebebeb",
                textAlign:"center",borderRadius:"5px"}}>
              <img
                src={require("../images/flowChart/arrow-left.png")}
                style={{marginLeft:"0px"}}
                onClick={this.inflowGraphPrevPage}
                disabled={this.state.inflowGraph.currentPage === 0}
              />
             </div>
            <div style=
             {{width:"30px",height:"30px",background:"white",position:"absolute",bottom:"26px",border:"1px solid #ebebeb",
             textAlign:"center",borderRadius:"5px",right:"15px"}}>
             <img
                src={require("../images/flowChart/arrow-right.png")}
                style={{ marginLeft:"0px"}}
                onClick={this.inflowGraphNextPage}
                disabled={this.state.inflowGraph.currentPage === this.state.inflowGraph.numberOfPages - 1}
              />
            </div>
            </ParentDiv>
            </div>
          </Col>
          <Col xl={3} lg={3} md={12} xs={12} style={{ backgroundColor: "#f7f7f9" }}>
            <InflowFilter
              buttonOne="Customer View"
              buttonTwo="Cluster View"
              customerFilterInflow={this.props.customerFilterInflow}
              data={this.props.data}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              datefilter={this.props.datefilter}
              cname={this.props.cname}
              productsList={this.props.productsList}
              initialList={this.props.initialList}
              customerclusterNames={this.props.customerclusterNames}
              getClusterData={this.props.getClusterData}
              inflowUpdate={this.props.inflowUpdate}
              customerClusterData={this.props.customerClusterData}
            />
          </Col>
        </Row>
        {this.props.point !== "Other" && this.state.isShowingModal && (
          <CustomerDetailsGraph
            point={this.props.point}
            customerDataFromId={this.props.customerDataFromId}
            style={{ zIndex: "10" }}
            isShowingModal={this.state.isShowingModal}
            closeModalHandler={this.closeModalHandler}
          />
        )}
        {this.props.point === "Other" &&
          this.state.isShowingModal &&
          this.state.data.length > 0 && (
            <CollectionsGraph
              otherCollections={this.state.data}
              style={{ zIndex: "10" }}
              isShowingModal={this.state.isShowingModal}
              closeModalHandler={this.closeModalHandler}
            />
          )}
      </Container>
    );
  }
}

export default Inflow;
