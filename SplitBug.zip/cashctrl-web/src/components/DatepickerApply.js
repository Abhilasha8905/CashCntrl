import React, { Component } from "react";
import styled from "styled-components";
import moment from "moment";
import { connect } from "react-redux";
import DatepickerComponent from "./dashboardComponents/DatepickerComponent.js";

const Button = styled.button`
  width: 65px;
  height: 32px;
  background-color: var(--black);
  border-radius: 0 !important;
`;

const Span = styled.span`
  font-size: 11px;
  line-height: 1.36;
`;
class DatePickerApply extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fromDate: this.props.fromDate,
      toDate: this.props.toDate
    };
    this.setDateFrom = this.setDateFrom.bind(this);
    this.setDateTo = this.setDateTo.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      fromDate: nextProps.fromDate,
      toDate: nextProps.toDate
    });
  }
 
  setDateFrom(date) {
    if(new Date(date) > new Date(this.state.toDate)) {
      this.setState({
        fromDate: date,
        toDate: date
      })
    } else {
      this.setState({
        fromDate: date
      });
    }
  }

  setDateTo(date) {
    this.setState({
      toDate: date
    });
  }

  render() {
    return (
      <div>
        <DatepickerComponent
          className="datePickComp"
          onDateSelect={this.setDateFrom}
          date={this.state.fromDate}
        />
        <DatepickerComponent
          onDateSelect={this.setDateTo}
          date={this.state.toDate}
          minDate={new Date(this.state.fromDate)}
        />
        <Button
          type="button"
          className="btn btn-dark btn  btn-sm"
          onClick={() => {
            if (
              this.state.fromDate != "" &&
              this.state.toDate != "" &&
              moment(this.state.fromDate) <= moment(this.state.toDate)
            ) {
              this.props.applyDatePicker(this.state.fromDate, this.state.toDate);
            }
          }}
        >
          <Span>Apply</Span>
        </Button>
      </div>
    );
  }
}

export default DatePickerApply;
