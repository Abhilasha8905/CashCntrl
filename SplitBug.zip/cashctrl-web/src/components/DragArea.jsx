/* eslint-disable react/destructuring-assignment */
import React, { Component } from "react";
import styled from "styled-components";
import PropTypes from "prop-types";
import ExpandablelistView from "./ExpandableListView";
import "./graph.css";

const Li = styled.li`
  opacity: 0.7;
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  letter-spacing: normal;

  color: var(--black);
`;
class DragArea extends Component {
  constructor(props) {
    super(props);
    this.state = {
      header: ["", "Aging", "Customer Name", "Currency", " Invoice No", "Value"],
      selectedView: this.props.selectedView
    };
  }

  sortingData(e) {
    this.props.sortData(e.target.innerHTML);
  }

  render() {
    return (
      <div style={{ backgroundColor: "white", height: "58vh" }}>
        <ul
          className="list-group-horizontal"
          style={{
            display: "flex",
            boxShadow: " 0 4px 4px 0 rgba(0, 0, 0, 0.05)",
            cursor: "pointer"
          }}
        >
          {this.state.header.map(h => (
            <Li
              value={h}
              className="list-group-item"
              style={{ border: "none" }}
              onClick={e => {
                this.props.sortData(e.target.innerHTML);
              }}
            >
              {h}
            </Li>
          ))}
        </ul>
        <div style={{ height: "100%", overflow: "auto", position: "relative" }}>
          <ExpandablelistView
            data={this.props.data}
            selectedView={this.state.selectedView}
            elementDropped={this.props.elementDropped}
          />
        </div>
      </div>
    );
  }
}

export default DragArea;

DragArea.propTypes = {
  selectedView: PropTypes.bool.isRequired,
  elementDropped: PropTypes.bool.isRequired,
  data: PropTypes.array.isRequired
};
