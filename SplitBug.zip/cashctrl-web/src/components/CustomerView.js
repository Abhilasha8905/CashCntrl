import React from "react";
import FlowHeaderInflow from "./FlowHeaderInflow";

class CustomerViewHeader extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <FlowHeaderInflow
        setFilterOptionsInflow={this.props.setFilterOptionsInflow}
        collectionsInflow={this.props.collectionsInflow}
        options={this.props.options}
        enteredAmountInflow={this.props.enteredAmountInflow}
        rangeInflow={this.props.rangeInflow}
      />
    );
  }
}

export default CustomerViewHeader;
