import React, { Component } from "react";
import { Container } from "react-bootstrap";
import PropTypes from "prop-types";
import Graph from "./Graph";

export default class DropArea extends Component {
  render() {
    const { xAxis, yAxis, graphData, updateGraphData, updateGraphRowData } = this.props;

    return (
      <Container
        fluid
        style={{
          backgroundColor: "#ffffff",
          width: 'auto',
          overflowX: 'scroll',
          overflowY: 'hidden'
        }}
      >
        <Graph
          xAxis={xAxis}
          yAxis={yAxis}
          graphData={graphData}
          updateGraphData={updateGraphData}
          updateGraphRowData={updateGraphRowData}
          selectedView={this.props.selectedView}
          splitUpdate={this.props.splitUpdate}
          onDrop={this.props.onDrop}
        />
      </Container>
    );
  }
}

DropArea.propTypes = {
  xAxis: PropTypes.array.isRequired,
  yAxis: PropTypes.isRequired,
  graphData: PropTypes.isRequired,
  updateGraphData: PropTypes.isRequired,
  updateGraphRowData: PropTypes.isRequired,
  selectedView: PropTypes.bool
};
