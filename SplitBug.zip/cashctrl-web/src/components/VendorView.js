import React from "react";
import FlowHeaderOutflow from "./FlowHeaderOutflow.js";

class VendorViewHeader extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <FlowHeaderOutflow
        setFilterOptionsOutflow={this.props.setFilterOptionsOutflow}
        collectionsOutflow={this.props.collectionsOutflow}
        options={this.props.options}
        enteredAmountOutflow={this.props.enteredAmountOutflow}
        rangeOutflow={this.props.rangeOutflow}
      />
    );
  }
}

export default VendorViewHeader;
