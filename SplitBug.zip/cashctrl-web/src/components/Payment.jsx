import React, { Component } from "react";
import DragArea from "./DragArea";

class Payment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      graphData: this.props.payment
    };
    this.state.listData = Object.assign([], this.state.graphData.map((o, i) => ({ ...o, id: i }))); // diff id for right list item
  }

  componentWillReceiveProps(nextProps) {

    this.setState({
      graphData: nextProps.payment
    });
  }

  render() {
    const { listData } = this.state.graphData;
    return (
      <DragArea
        sortData={this.props.sortData}
        data={this.props.payment}
        selectedView={this.props.selectedView}
        elementDropped={this.props.elementDropped}
      />
    );
  }
}

export default Payment;
