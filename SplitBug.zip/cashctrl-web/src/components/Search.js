import React, { Component } from "react";
import styled from "styled-components";
const searchIcon = require("./../images/header/Search.png");
import Navbar from "react-bootstrap/Navbar";

const Container = styled.div`
  position: relative;
  padding: 0;
  margin: 0;
`;

const Input = styled.input`
  height: 20px;
  margin: 0;
  padding-left: 30px;
  border-width: 0px;
  border: none;
  background-color: #f7f8f9;
`;

const Image = styled.img.attrs({
  src: searchIcon
})`
  position: absolute;
  left: 0.1px;
  margin-right: 12px;
  width: 22px;
  height: 22px;
  margin: 0;
  vertical-align: middle;
  background-color: #f7f8f9;
`;

export default class Search extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Container>
        <Input type="text" placeholder="Search Vender/Customer" />
        <Image imageURL={searchIcon} />
      </Container>
    );
  }
}
