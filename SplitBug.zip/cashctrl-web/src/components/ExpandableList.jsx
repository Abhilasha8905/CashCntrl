import React, { Component } from "react";
import PropTypes from "prop-types";

import List from "./List";

export default class ExpandableList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      elementDropped: this.props.elementDropped
    };
  }

  render() {
    return this.props.data.map(item => (
      <div key={item.ledgerId}>
        <List
          items={item}
          selectedView={this.props.selectedView}
          elementDropped={this.props.elementDropped}
        />
      </div>
    ));
  }
}

ExpandableList.propTypes = {
  selectedView: PropTypes.bool.isRequired,
  elementDropped: PropTypes.bool.isRequired,
  data: PropTypes.array.isRequired
};
