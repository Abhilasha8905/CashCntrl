import React, { Component } from "react";
import { Container, Row, Col, Image } from "react-bootstrap";
import styled from "styled-components";

import CustomerView from "./CustomerView";

import CustomerVendorComponent from "./dashboardComponents/CustomerVendorComponent";
import SubHeader from "./SubHeaderOutflow";
import VendorView from "./VendorView";
import TestComponent from "./dashboardComponents/OutflowFilter";
import GroupByDayComponent from "./dashboardComponents/GroupByDayComponentOutFlow";
import WrapperChart from "./dashboardComponents/WrapperChartOutflow";
import CustomerDetailsGraph from "./dashboardComponents/CustomerDetailsGraph";
import CollectionsGraph from "./dashboardComponents/CollectionsGraph";
import moment from "moment-timezone";
const GraphImg = styled(Image).attrs({
  src: props => props.imageURL
})`
  margin: 0%;
`;

const RowContainer = styled(Row)`
  margin-left: -1px;
  margin-right: -1px;
`;

const Div = styled.div`
  display: flex;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
  flex-direction: column;
`;
const GraphDiv = styled.div`
  background-color: white;
  height: calc(100vh - 230px);
  overflow: hidden;

`;
const ParentDiv = styled.div`
  background-color: white;
  height: calc(100vh - 230px);
 
`;
class Outflow extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isShowingModal: false,
      data: "",
      outflowGraph: {
        currentPage: 0,
        numberOfPages: 1
      }
    };

    this.outflowGraphParentRef = React.createRef();


    this.openModalHandler = this.openModalHandler.bind(this);
    this.closeModalHandler = this.closeModalHandler.bind(this);
    this.getWeekRangeFromWeekNum=this.getWeekRangeFromWeekNum.bind(this);
    this.outflowGraphNextPage = this.outflowGraphNextPage.bind(this);
    this.outflowGraphPrevPage = this.outflowGraphPrevPage.bind(this);
  }

  componentDidMount() {
    this.initializeOutflowGraphState();
    this.scrollOutflowGraph();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.dates !== this.props.dates) {
      this.initializeOutflowGraphState();
    }

    if (prevState.outflowGraph.currentPage !== this.state.outflowGraph.currentPage) {
      this.scrollOutflowGraph();
    }
  }
  initializeOutflowGraphState(){
    const outflowGraphParent = this.outflowGraphParentRef.current;
    const parentWidth = outflowGraphParent.clientWidth;
    const graphWidth = (this.props.dates.length > 25) ? 100 * this.props.dates.length : parentWidth;
    const numberOfPages = Math.ceil(graphWidth / parentWidth);
    this.setState({
      outflowGraph: {
        currentPage: 0,
        numberOfPages
      }
    });
  }
  scrollOutflowGraph(){
    const outflowGraphParent = this.outflowGraphParentRef.current;
    const parentWidth = outflowGraphParent.clientWidth;
    outflowGraphParent.scrollLeft = parentWidth * this.state.outflowGraph.currentPage;
  }
  outflowGraphPrevPage(){
    this.setState((state) => {
      if (state.outflowGraph.currentPage > 0) {
        return {
          ...state,
          outflowGraph: { ...state.outflowGraph, currentPage: state.outflowGraph.currentPage - 1 }
        }
      };
      return state;
    });
  }

  outflowGraphNextPage(){
    this.setState((state) => {
      if (state.outflowGraph.currentPage < state.outflowGraph.numberOfPages - 1) {
        return {
          ...state,
          outflowGraph: { ...state.outflowGraph, currentPage: state.outflowGraph.currentPage + 1 }
        };
      }
      return state;
    });
  }
  getWeekRangeFromWeekNum(weekNumber) {
    let range;
    const beginningOfWeek = moment()
      .week(weekNumber)
      .startOf("week");
    const endOfWeek = moment()
      .week(weekNumber)
      .startOf("week")
      .add(6, "days");
    range = `${beginningOfWeek.format(" DD MMM")}-${endOfWeek.format(" DD MMM")}`;
    return range;
  };
  openModalHandler(datePoint, seriesName, id = '') {
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "June",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];
    let date = datePoint;
    
    if (this.props.datefilter === "Day") {
      date = moment(datePoint).format("MM/DD/YYYY")
    } 
    if (datePoint) {
      let point = this.props.groupedData[date].filter((i) => i.name === seriesName.name);
      this.props.dataPointOutflow(point.length > 0 ? point[0].id : "Other");
    } else {
      this.props.dataPointOutflow(id);
    }
     let j = this.props.otherCollections.filter((i, m) => this.props.datefilter === "Month" ? i.date === months[date - 1] : this.props.datefilter === "Week" ? i.date === this.getWeekRangeFromWeekNum(date) : i.date === date)
     this.setState({
       data: j
     })
     if (j.length > 0 && seriesName.name === "OtherCollections") {
      this.setState({
        isShowingModal: true
      });
     } else if (seriesName.name !== "OtherCollections") {
      let pointId;
      if (datePoint) {
        pointId = this.props.groupedData[date].filter((i) => i.name === seriesName.name);
       }
       
       this.props.getCustomerDetailsonId(datePoint ? pointId[0].id : id,this.props.fromDate,this.props.toDate);
       this.setState({
        isShowingModal: true
      });
    }
    
  }


  closeModalHandler(close, id) {
    
    this.setState({
      isShowingModal: false
    });
    if (!close) {
      this.openModalHandler(false, false, id);
    }
  }

  render() {
    return (
      <Container style={{ maxWidth: "100%", height: "100%", position: "relative" }}>
        <Row
          style={{
            position: "absolute",
            width: "100%",
            height: "100%"
          }}
        >
          <Col lg={9} md={12} xs={12} style={{ backgroundColor: "rgb(248, 249, 251)" }}>
          <div style={{background:"white",height:"inherit"}}>

            <SubHeader
              applyDatePicker={this.props.applyDatePicker}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              onButtonSelect={this.props.onButtonSelect}
              datefilter={this.props.datefilter}
              addOutflowType={this.props.addOutflowType}
            />
            <VendorView
              setFilterOptionsOutflow={this.props.setFilterOptionsOutflow}
              collectionsOutflow={this.props.collectionsOutflow}
              options={this.props.options}
              enteredAmountOutflow={this.props.enteredAmountOutflow}
              rangeOutflow={this.props.rangeOutflow}
            />
            <ParentDiv>
            <GraphDiv ref={this.outflowGraphParentRef}>
              <GroupByDayComponent
                openModalHandler={this.openModalHandler}
                dates={this.props.dates}
                series={this.props.series}
                dataPointOutflow={this.props.dataPointOutflow}
                fullDates={this.props.fullDates}
              />
              <WrapperChart sum={this.props.sum} />
            </GraphDiv>
            <div style=
              {{width:"30px",height:"30px",background:"white",position:"absolute",bottom:"26px",border:"1px solid #ebebeb",
                textAlign:"center",borderRadius:"5px"}}>
            <img
                src={require("../images/flowChart/arrow-left.png")}
                style={{ marginLeft:"0px"}}
                onClick={this.outflowGraphPrevPage}
                disabled={this.state.outflowGraph.currentPage === 0}
              />
              </div>
              <div style=
             {{width:"30px",height:"30px",background:"white",position:"absolute",bottom:"26px",border:"1px solid #ebebeb",
             textAlign:"center",borderRadius:"5px",right:"15px"}}>
              <img
                src={require("../images/flowChart/arrow-right.png")}
                style={{ marginLeft:"0px"}}
                onClick={this.outflowGraphNextPage}
                disabled={this.state.outflowGraph.currentPage === this.state.outflowGraph.numberOfPages - 1}

             />
             </div>
            </ParentDiv>
            </div>
          </Col>
          <Col lg={3} md={3} xs={12} style={{ backgroundColor: "#f7f7f9" }}>
            <TestComponent
              buttonOne="Vendor/Expense View"
              buttonTwo="Cluster View"
              customerFilterOutflow={this.props.customerFilterOutflow}
              data={this.props.data}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              datefilter={this.props.datefilter}
              cname={this.props.cname}
              productsList={this.props.productsList}
              initialList={this.props.initialList}
              vendorclusterNames={this.props.vendorclusterNames}
              vendorClusterData={this.props.vendorClusterData}
              outflowUpdate={this.props.outflowUpdate}
              getClusterData={this.props.getClusterData}
            />
          </Col>
        </Row>
        {this.props.point !== "Other" && this.state.isShowingModal && (
          <CustomerDetailsGraph point={this.props.point} customerDataFromId={this.props.customerDataFromId}
            style={{ zIndex: "10" }}
            isShowingModal={this.state.isShowingModal}
            closeModalHandler={this.closeModalHandler}
          />
        )}
        {this.props.point === "Other" && this.state.isShowingModal && this.state.data.length> 0 && (
          <CollectionsGraph otherCollections={this.state.data}
            style={{ zIndex: "10" }}
            isShowingModal={this.state.isShowingModal}
            closeModalHandler={this.closeModalHandler}
          />
        )}
      </Container>
    );
  }
}

export default Outflow;
