import React from "react";
import styled from "styled-components";

const AmountDiv = styled.div`
  width: 88%;
  position: relative;
  margin-left:50px
  top: 5%;
`;
const AmountSpan = styled.span`
  position: absolute;
  transform: translateX(-6px);
  color: #2eacff;
  font-family: Nunito;
  font-size: 11px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  text-align: center;
  margin-left: -13px;
`;

export default class SumAmount extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sumArr: this.props.data
    };
  }

  render() {
    return (
      <AmountDiv>
        {this.state.sumArr.map((sumAtDate, i) => (
          <AmountSpan key={sumAtDate} style={{ left: `${i * 15}%` }}>
            {sumAtDate}
          </AmountSpan>
        ))}
      </AmountDiv>
    );
  }
}
