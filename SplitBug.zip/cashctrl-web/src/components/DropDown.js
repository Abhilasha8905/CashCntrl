import React, { Component } from "react";
import styled from "styled-components";
import onClickOutside from "react-onclickoutside";
import DropDownicon from "./../images/header/DropDownIcon.png";

const Li = styled.li`

    display: table;
    height: 100%;
    width: 100%;
    vertical-align: left;
    line-width: 10px
    position:relative
    margin-right:20px;
    float: right




`;

const DropDownIcon = styled.img.attrs({
  src: DropDownicon
})`
  width: 8px;
  height: 4.7px;
  object-fit: contain;
  vertical-align: middle;
  line-width: 30px;
`;
const Span = styled.span`
  width: 22px;
  height: 18px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: #c94593;
`;
const UL = styled.ul``;

class Dropdown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      listOpen: false,
      displaySelected: false,
      selectedValue: "₹ INR",

      DropDownData: [
        {
          id: 0,
          title: "Profile",
          selected: false,
          key: "options"
        },
        {
          id: 1,
          title: "Settings",
          selected: false,
          key: "options"
        },
        {
          id: 2,
          title: "Change Pass",
          selected: false,
          key: "options"
        },
        {
          id: 3,
          title: "Help",
          selected: false,
          key: "options"
        },
        {
          id: 4,
          title: "logout",
          selected: false,
          key: "options"
        }
      ]
    };
  }

  handleClickOutside() {
    this.setState({
      listOpen: false
    });
  }
  toggleList() {
    this.setState(prevState => ({
      listOpen: !prevState.listOpen
    }));
  }
  handleClick(e) {
    this.setState({
      selectedValue: e.target.getAttribute("value")
    });
  }

  closeDropDown() {
    this.setState({
      listOpen: false
    });
  }

  render() {
    const DropDownData = this.props.DropDownData
      ? this.props.DropDownData
      : this.state.DropDownData;
    const { listOpen, headerTitle } = this.state;
    const handleClick = this.props.handleClick
      ? this.props.handleClick
      : this.handleClick.bind(this);
    const displaySelected = this.props.displaySelected
      ? this.props.displaySelected
      : this.state.displaySelected;
    const selectedValue = this.state.selectedValue;

    return (
      <div className="dd-wrapper">
        <div className="dd-header" onClick={() => this.toggleList()}>
          {displaySelected && (
            <div className="dd-header-title" display="flex">
              {" "}
              <span>{selectedValue}</span>
              <DropDownIcon />
            </div>
          )}
          {!displaySelected && (
            <div className="dd-header-title" display="flex">
              <DropDownIcon />
            </div>
          )}
          <div style={{ right: "0" }}>
            <div style={{}}>
              {listOpen && (
                <UL
                  onChange={this.closeDropDown}
                  style={{ listStyleType: "none", position: "absolute" }}
                >
                  {DropDownData.map(item => (
                    <Li
                      onClick={handleClick}
                      className="dd-list-item"
                      key={item.id}
                      value={item.title}
                    >
                      {item.title}
                    </Li>
                  ))}
                </UL>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default onClickOutside(Dropdown);
