import React from "react";
import "./graph.css";
import styled from "styled-components";
import { Droppable, Draggable } from "react-drag-and-drop";
import PropTypes from "prop-types";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import DropBox from "./DropBox";
import ConverUnit from "../utility/ConvertUnit";

const BarContext = styled.div`
 
  font-family: Nunito;
  font-size: 11px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;

  padding-right:10px

  color: var(--black);
`;

const GraphDiv = styled.div`
  position: relative;
  max-width: 100%;
  height: 68vh;
  display: flex;
  margin: 0px 0 0 4px;
  // background: red;
  flex-wrap: wrap;
  margin: 2px auto;
`;

const BarLineContainer = styled.div`
  height: calc(100% - 80px);
  width: 99%;
  position: relative;
  border-left: solid 1px #707070;
  border-bottom: solid 1px #707070;
`;

const MarkersDiv = styled.div`
  width: 99%;
  position: relative;
  margin-top: 0px;
  margin-left: 57px;
`;
const MarkersSpan = styled.span`
  position: absolute;
  transform: translateX(-6px);
  color: black;
  font-family: Nunito;
  font-size: 11px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;
  color: var(--black);
`;

const AmountDiv = styled.div`
  width: 88%;
  position: relative;
  margin-left:50px
  top: 0px;
`;
const AmountSpan = styled.span`
  position: absolute;
  transform: translateX(-6px);
  color: #2eacff;
  font-family: Nunito;
  font-size: 11px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  text-align: center;
  margin-left: -13px;
`;

const Markers = ({ data }) => {
  return (
    <MarkersDiv>
      {data.map((el, i) => (
        <MarkersSpan key={el} style={{ left: `${i * 14}%` }}>
          {el.substring(0, 5)}
        </MarkersSpan>
      ))}
    </MarkersDiv>
  );
};

const BarTextContent = ({ dates }) => {
  return (
    <BarContext>
      {dates.map((date, i) => (
        <div key={i} className={i > 0 ? "textWithHeight" : "textWithoutHeight"} />
      ))}
    </BarContext>
  );
};

const SumAmount = ({ data }) => {
  const sumArr = [];

  for (const x in data) {
    let sum = 0;
    data[x].map(y => {
      if (y.mode === "INFLOW") {
        sum += y.invoiceValue;
      }
      if (y.mode === "OUTFLOW") {
        sum -= y.invoiceValue;
      }
    });
    console.log(sum, "....sum");
    sumArr.push(ConverUnit(sum));
  }
  console.log(sumArr, "...sumArr");
  return (
    <AmountDiv>
      {sumArr.map((sumAtDate, i) => (
        <AmountSpan key={i} style={{ left: `${i * 15}%` }}>
          {sumAtDate}
        </AmountSpan>
      ))}
    </AmountDiv>
  );
};
class Graph extends React.Component {
  onDrop(data, o) {
    this.props.updateGraphData(JSON.parse(data.row_item), o);
  }

  onDropHandle(data, o) {
    if (data.row_item) {
      this.onDrop(data, o);
    } else {
      this.onBoxDrop(data, o);
    }
    this.props.onDrop(data);
  }

  onBoxDrop(boxData, key) {
    this.props.updateGraphRowData(JSON.parse(boxData.box_row_item), key);
  }

  // renderLines(groupedData) {
  //   return this.props.xAxis.map((el, i) => {
  //     const left = i * 14;
  //     const height = 14;
  //     const initialTop = 87;
  //     const data = groupedData[el];
  //     return (
  //       <Line style={{ left: `${left}%` }} key={i}>
  //         {data.map((o, i) => (
  //            <Droppable onDrop={data => this.onBoxDrop(data)} types={['box_row_item']}>
  //           <div
  //             style={{ position: "absolute", left: "735%", top: `${initialTop - i * height}%` }}
  //           >
  //             <Draggable type="box_row_item" data={JSON.stringify(o)}><DropBox amount={o.amount} description={o.description} height="55px" width="70px" /></Draggable>
  //           </div>
  //           </Droppable>
  //         ))}
  //       </Line>
  //     );
  //   });
  // }

  renderDiv(groupedData) {
    return (
      <div className="droppable-container" style={{ height: "100% !important" }}>
        {this.props.xAxis.map((o, topIndex) => (
          <Droppable
            className="col"
            style={{ height: "calc(100% - 10px)" }}
            onDrop={data => this.onDropHandle(data, o)}
            types={["box_row_item", "row_item"]}
            key={o}
          >
            {groupedData[o] &&
              groupedData[o].map((el, index) => (
                <Draggable
                  style={{
                    position: "absolute",
                    bottom: `${index * 65}px`,
                    width: "80%",
                    left: `${topIndex === 0 ? "21px" : "12px"}`
                  }}
                  type="box_row_item"
                  data={JSON.stringify(el)}
                >
                  <DropBox
                    description={el.description}
                    invoiceValue={el.invoiceValue}
                    id={el.id}
                    ledgerId={el.ledgerId}
                    height="55px"
                    width="80%"
                    mode={el.mode}
                    uniqueKey={el.uniqueKey}
                    splitUpdate={this.props.splitUpdate}
                  />
                </Draggable>
              ))}
          </Droppable>
        ))}
      </div>
    );
  }

  render() {
    console.log(this.props.graphData, "....graphdddd");
    const groupedData = {};
    this.props.xAxis.map(
      o =>
        (groupedData[o] = this.props.graphData.filter(a => {
          return a.date === o;
        }))
    );

    return (
      <GraphDiv>
        <BarTextContent dates={this.props.yAxis} />
        <BarLineContainer>{this.renderDiv(groupedData)}</BarLineContainer>
        <div style={{ width: "12%" }} />
        <Markers data={this.props.xAxis} />
        <SumAmount data={groupedData} />
      </GraphDiv>
    );
  }
}

export default Graph;

Graph.propTypes = {
  xAxis: PropTypes.array.isRequired,
  yAxis: PropTypes.isRequired,
  graphData: PropTypes.isRequired,
  updateGraphData: PropTypes.isRequired,
  updateGraphRowData: PropTypes.isRequired
};
