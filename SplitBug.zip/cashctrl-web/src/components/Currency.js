import React, { Component } from "react";
import styled from "styled-components";
import Dropdown from "./DropDown";

const Container = styled.div`
  display: flex;
  width: 122px;
  height: 36px;
  border-radius: 3px;
  background-color: #f8f9fb;
`;

const CurrencyText = styled.div`
  width: 45px;
  height: 15px;
  opacity: 0.5;
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.36;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  line-width: 10px;
  position: relative;
  margin-top: 6px;
  vertical-align: middle;
`;
const CurrencyContainer = styled.div`
  border: none;
  color: #c94593;
  padding-right: " 8px";
`;

const DropDownData = [
  {
    id: 0,
    title: "₹ INR",
    selected: false,
    key: "currency"
  },

  {
    id: 1,
    title: "$ USD",
    selected: false,
    key: "currency"
  },
  {
    id: 2,
    title: "€ EUR",
    selected: false,
    key: "currency"
  },
  {
    id: 3,
    title: "£ JPY",
    selected: false,
    key: "currency"
  },
  {
    id: 4,
    title: "$ CAD",
    selected: false,
    key: "currency"
  }
];

export default class Currency extends Component {
  render() {
    return (
      <Container>
        <CurrencyText>Currency</CurrencyText>
        <CurrencyContainer>
          <Dropdown DropDownData={DropDownData} displaySelected leftPosition="82%" />
        </CurrencyContainer>
      </Container>
    );
  }
}
