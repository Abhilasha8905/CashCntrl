import React from "react";
import styled from "styled-components";

const Toggletab = styled.div.attrs({})`
  width: 50%;
  background: #fff;
  float: left;
  height: 60px;
  line-height: 60px;
  text-align: center;
  cursor: pointer;
  text-transform: uppercase;
  background: ${props => (props.active ? `#34b3a0` : "")};
  color: ${props => (props.active ? `white` : `black`)};
`;

const Toggleswitch = props => {
  const { active } = props;
  return (
    <Toggletab active={active} value={props.value} onClick={props.handleClick}>
      {props.value}
    </Toggletab>
  );
};

export default Toggleswitch;
