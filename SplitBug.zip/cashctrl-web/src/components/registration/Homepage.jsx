import React from "react";
import styled from "styled-components";
import Login from "./Login";
import Toggleswitch from "./Toggleswitch";
import Setting from "./Setting";

class Homepage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showSettingComponent: true,
      showLoginComponent: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.displaySetting = this.displaySetting.bind(this);
    this.displayLogIn = this.displayLogIn.bind(this);
  }

  displaySetting() {
    this.setState({
      showSettingComponent: true,
      showLoginComponent: false
    });
  }

  // displaySetting = () => {
  //     this.setState({
  //         showSettingComponent: true,
  //         showLoginComponent: false
  //     })
  // }

  displayLogIn() {
    this.setState({
      showSettingComponent: false,
      showLoginComponent: true
    });
  }

  handleClick(event) {
    const value = event.target.textContent;
    switch (value) {
      case "Setting": {
        this.displaySetting();
        break;
      }
      case "Log In": {
        this.displayLogIn();
        break;
      }
      default:
        console.log("others");
    }
  }

  render() {
    const activeSetting = this.state.showSettingComponent;
    const activeLogin = this.state.showLoginComponent;
    const { history, location } = this.props;

    return (
      <Container>
        <Toggleswitch value="Setting" handleClick={this.handleClick} active={activeSetting} />
        <Toggleswitch value="Log In" handleClick={this.handleClick} active={activeLogin} />
        {this.state.showSettingComponent && <Setting />}
        {this.state.showLoginComponent && <Login history={history} location={location} />}
      </Container>
    );
  }
}

export default Homepage;
