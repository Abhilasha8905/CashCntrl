import React from "react";
import styled from "styled-components";
import '../dashboardComponents/table.css';

const RegisterUserContainer = styled.div`
overflow-y: auto;
height: 80%;
`;

const RegisterUser = styled.div`

`;
const headerValue = ['Email','UserName'];
export const TableData=({registeredUserList})=> {

  return registeredUserList.map((data, i) => {
    const td = [];
    {
        td.push(<td >{data.userEmail}</td>);
        td.push(<td >{data.userName}</td>);

    }
    return <tr>{td}</tr>;
  });
}

export const TableHeader =({registeredUserList})=> {
  let header;
  if (registeredUserList.length > 0) {
    return headerValue.map((key, index) => {
      return <th key={index}>{key}</th>;
    });
  }
}

const AddedUser = props => {
  const { registeredUserList = [] } = props;

  if (registeredUserList.length > 0) {
    return (
      <RegisterUserContainer>

            <RegisterUser>
          <table className="addedUserTable">
          <tbody>
            <tr><TableHeader  registeredUserList={registeredUserList}/></tr>
            <TableData registeredUserList={registeredUserList}/>
          </tbody>
          </table>
            </RegisterUser>
      </RegisterUserContainer>
    );
  }
  else {
    return (
      <RegisterUserContainer>
        <h2>No Accounts Added. Click on Add User to add new Accounts</h2>
      </RegisterUserContainer>
    )
  }
}

export default AddedUser;
