import React from "react";
import styled from "styled-components";
import Inputfield from "./Inputfield";
import Button from "./Button";
import Newuserblock from "./Newuserblock";

const SettingForm = styled.div`
margin: 0px !important;

`;

const ErrorMessage = styled.div`
  display: block;
  color: ${props => (props.registerUserStatus === "done" ? "green" : "red")};
  font-size: 12px;
  width: 100%;
  padding: 0px 10px;
  position: relative;
  margin-bottom: 0px;
  position: absolute;
  bottom: 80px;

`;

class Setting extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      newUser: [
        {
          email: null,
          password: null
        }
      ],
      formError: {
        passwordError: "",
        emailError: ""
       },
      formInvalid: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleFormValidation = this.handleFormValidation.bind(this);
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });

    const { name, value } = event.target;
    this.setState({ newUser, [name]: value });
  }

  handleSubmit(e) {
    const emailRegex = RegExp(/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/);
    const password = document.getElementById("newUserPassword").value;
    const email = document.getElementById("newUserEmail").value;
    const username = document.getElementById("newUserUsername").value;

    const data = [{
      password,
      userEmail: email,
      userName: username
    }]
    const { emailError, passwordError } = this.state.formError;
    if (email && password && passwordError === "" && emailError === "") {
      this.setState({
        formInvalid: ""
      });
      this.props.handleSetting(data);
    } else {
      this.setState({
        formInvalid: "Please fill the empty field"
      });
    }
  }

  handleFormValidation(error) {
    this.setState({
      formError: error,
      formInvalid: ""
    });
    this.props.resetRegisterUser();
  }

  render() {
    const { newUser, formInvalid, formError } = this.state;
    const { registerUserStatus, registerMsg } = this.props;
    return (
      <SettingForm className="row adduser-row">

        {newUser.map((val, idx) => {
          return (
            <Newuserblock
              key={idx}
              idx={idx}
              newUser={newUser}
              onChange={this.handleChange}
              handleFormValidation={this.handleFormValidation}
            />
          );
        })}

        {formInvalid === "" && registerUserStatus !== "start" && registerMsg ? <ErrorMessage registerUserStatus={registerUserStatus}>{registerMsg} </ErrorMessage> : ""}
        {formError && formError.passwordError === "" && formError.emailError === "" && formInvalid && formInvalid !== "" ?
         <ErrorMessage registerUserStatus={registerUserStatus}>{formInvalid} </ErrorMessage> : ""}
       <div  style={{width:"300px",margin:"0px auto"}}>
        <Button label="+ ADD USER"  onClick={this.handleSubmit} />
        </div>
      </SettingForm>

    );
  }
}

export default Setting;
