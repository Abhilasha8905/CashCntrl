import React from "react";
import styled from "styled-components";
import Inputfield from "./Inputfield";
import Button from "./Button";

const LoginForm = styled.div`
  background: #fff;
  padding: 20px 40px;
  clear: both;
  width: 100%;
  box-sizing: border-box;
  height: auto;
`;

const ErrorMessage = styled.span`
  display: block;
  color: red;
  font-size: 10px;
  padding: 2px 0px;
  position: relative;
  margin-bottom: 10px;
`;

const emailRegex = RegExp(/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/);

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: null,
      password: null,
      emailError: "",
      passwordError: "",
      loggedIn: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleFocus = this.handleFocus.bind(this);
    this.handleBlur = this.handleBlur.bind(this);
  }

  handleFocus(event) {
    const focusField = event.target.name;
    switch (focusField) {
      case "email":
        this.setState({ emailError: "" });
        break;
      case "password":
        this.setState({ passwordError: "" });
        break;
      default:
        break;
    }
  }

  handleSubmit(event) {
    let emailErrorValue = this.state.emailError;
    let passwordErrorValue = this.state.passwordError;
    const { email, emailError, password, passwordError } = this.state;
    if (email === "" || email === null) {
      emailErrorValue = "Required field empty";
    }
    if (password === "" || password === null) {
      passwordErrorValue = "Required field empty";
    }

    this.setState(
      {
        loggedIn: true,
        emailError: emailErrorValue,
        passwordError: passwordErrorValue
      },
      () => {
        if (this.state.emailError === "" && this.state.passwordError === "") {
          this.props.handleLogin({ userEmail: email, password });
        }
      }
    );
  }

  handleBlur(event) {
    const { email, emailError, passwordError, password } = this.state;
    const { name, value } = event.target;
    let emailErrorValue = this.state.emailError;
    let passwordErrorValue = this.state.passwordError;
    switch (name) {
      case "email":
        if (value === null || value === "") {
          emailErrorValue = "";
        } else if (emailRegex.test(value) == false) {
          emailErrorValue = "Invalid email address";
        } else {
          emailErrorValue = "";
        }
        break;
      case "password":
        if (value === null || value === "") {
          passwordErrorValue = "";
        } else if (value.length < 8) {
          passwordErrorValue = "Minimum length of password is 8";
        } else {
          passwordErrorValue = "";
        }
        break;
      default:
        break;
    }
    this.setState({ emailError: emailErrorValue, passwordError: passwordErrorValue });
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  render() {
    const { emailError, passwordError } = this.state;
    return (
      <LoginForm>
        <div style={{marginBottom:"30px"}}>
        <Inputfield
          name="email"
          type="text"
          title="Email/Username"
          placeholder="Email or Username"
          onChange={this.handleChange}
          onBlur={this.handleBlur}
          onFocus={this.handleFocus}
        />
        {emailError.length > 0 && <ErrorMessage>{emailError}</ErrorMessage>}
        </div>
        <div style={{marginBottom:"30px"}}>
        <Inputfield
          name="password"
          type="password"
          title="Password"
          placeholder="Enter password"
          onChange={this.handleChange}
          onBlur={this.handleBlur}
          onFocus={this.handleFocus}
        />
        {passwordError.length > 0 && <ErrorMessage>{passwordError}</ErrorMessage>}
        </div>
        <div style={{width:"300px", margin:"0 auto"}}>
        <Button label="SIGN IN" onClick={this.handleSubmit} />
        </div>
      </LoginForm>
    );
  }
}

export default Login;
