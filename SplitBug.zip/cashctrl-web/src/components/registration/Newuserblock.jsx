import React from "react";
import styled from "styled-components";
import { Col } from "react-bootstrap";

const Input = styled.input.attrs({})`
  margin-bottom: 10px;
  display: inline-block;
  height: 45px;
  padding: 0px 10px !important;
  margin-left: 3px !important;
  margin-right: 3px !important;
  border: 2px solid #e9eaea !important;
  width: 100%;
  ::-webkit-input-placeholder {
    /* Chrome/Opera/Safari */
    color: rgb(37, 36, 36);
  }
  ::-moz-placeholder {
    /* Firefox 19+ */
    color: rgb(37, 36, 36);
  }
  :-ms-input-placeholder {
    /* IE 10+ */
    color: rgb(37, 36, 36);
  }
  :-moz-placeholder {
    /* Firefox 18- */
    color: rgb(37, 36, 36);
  }
`;

const Label = styled.label`
font-size: 14px;
color: rgba(0,0,0,0.6);
display: block;
`;

const ErrorMessage = styled.span`
  display: block;
  color: red;
  font-size: 10px;
  padding: 2px 0px;
  position: relative;
  margin-bottom: 5px;
`;

const emailRegex = RegExp(/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/);

class Newuserblock extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: null,
      password: null,
      username: null,
      emailError: "",
      passwordError: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleFocus = this.handleFocus.bind(this);
    this.handleBlur = this.handleBlur.bind(this);
  }

  handleBlur(event) {
    const { email, emailError, passwordError, password } = this.state;
    const { name, value } = event.target;
    let emailErrorValue = this.state.emailError;
    let passwordErrorValue = this.state.passwordError;

    switch (name) {
      case "email":
        if (value === null || value === "") {
          emailErrorValue = "";
        } else if (emailRegex.test(value) == false) {
          emailErrorValue = "Invalid email address";
        } else {
          emailErrorValue = "";
        }
        break;
      case "password":
        if (value === null || value === "") {
          passwordErrorValue = "";
        } else if (value.length < 8) {
          passwordErrorValue = "Minimum length of password is 8";
        } else {
          passwordErrorValue = "";
        }
        break;
      default:
        break;
    }
    this.setState({ emailError: emailErrorValue, passwordError: passwordErrorValue });
    this.props.handleFormValidation({
      emailError: emailErrorValue,
      passwordError: passwordErrorValue
    });
  }

  handleFocus(event) {
    const focusField = event.target.name;
    switch (focusField) {
      case "email":
        this.setState({ emailError: "" });
        break;
      case "password":
        this.setState({ passwordError: "" });
        break;
      default:
        break;
    }
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
    console.log(event.target.name);
    console.log(event.target.value);
  }

  render() {
    const { emailError, passwordError } = this.state;
    return (
      <div key={this.props.idx} className="row" style={{width:"100%"}}>
        <Col lg={12}>
        <Label>Username</Label>
        <Input
          type="text"
          name="username"
          value={this.props.newUser[this.props.idx].username}
          placeholder={`Enter username of user #${this.props.idx + 1}`}
          onChange={this.handleChange}
          onFocus={this.handleFocus}
          onBlur={this.handleBlur}
          id="newUserUsername"
          key={`username {this.props.idx}`}
        />
        </Col>
        <Col lg={12}>
        <Label>Email</Label>
        <Input
          type="text"
          name="email"
          value={this.props.newUser[this.props.idx].email}
          placeholder={`Enter email id of user #${this.props.idx + 1}`}
          onChange={this.handleChange}
          onFocus={this.handleFocus}
          onBlur={this.handleBlur}
          id="newUserEmail"
          key={`email {this.props.idx}`}
        />
        {emailError.length > 0 && <ErrorMessage>{emailError}</ErrorMessage>}
        </Col>
        <Col lg={12}>
        <Label>Password</Label>
        <Input
          type="password"
          name="password"
          value={this.props.newUser[this.props.idx].password}
          placeholder={`Enter password of user #${this.props.idx + 1}`}
          onChange={this.handleChange}
          onFocus={this.handleFocus}
          onBlur={this.handleBlur}
          id="newUserPassword"
          key={`password {this.props.idx}`}
        />
        {passwordError.length > 0 && <ErrorMessage>{passwordError}</ErrorMessage>}
        </Col>

      </div>
    );
  }
}
export default Newuserblock;
