import React from "react";
import styled from "styled-components";

const Input = styled.input`
    font-size: 14px;
    padding: 0px 25px;
    height: 45px;
    background: white;
    font-weight: normal;
    padding-left: 10px !important;
    width: 100%; !important;
    box-sizing: border-box;
    border: 2px solid #e9eaea !important;
    color: #3e3e40;
    outline: none;
    margin-left: 0px !important;
    transform: all 0.5s ease;
    &:focus{
        border: 2px solid #34b3a0 !important;
    }
    ::-webkit-input-placeholder { /* Chrome/Opera/Safari */
        color: rgb(37, 36, 36);
      }
      ::-moz-placeholder { /* Firefox 19+ */
        color: rgb(37, 36, 36);
      }
      :-ms-input-placeholder { /* IE 10+ */
        color: rgb(37, 36, 36);
      }
      :-moz-placeholder { /* Firefox 18- */
        color: rgb(37, 36, 36);
      }
`;
const Inputfield = props => {
  const { value, type, name, placeholder } = props;
  return (
    <div>
      <label style={{ display:"inline-block",marginBottom:".5rem",fontSize:"14px",fontWeight:"normal",color:"rgba(0,0,0,0.6)"}}>{props.title}</label>
      <Input
        name={name}
        type={type}
        placeholder={placeholder}
        onChange={props.onChange}
        onBlur={props.onBlur}
        onFocus={props.onFocus}
        value={value}
        autoComplete="off"
      />
    </div>
  );
};

export default Inputfield;
