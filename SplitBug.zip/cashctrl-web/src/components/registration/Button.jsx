import React from "react";
import styled from "styled-components";

const Input = styled.input.attrs({
  type: "button",
  value: props => props.label
})`
  text-transform: uppercase;
  color: #fff;
  font-weight: bold;
  letter-spacing: 1px;
  cursor: pointer;
  background: #c94593;
  width: 300px;
  margin: 0 auto;
  height: 45px;
  text-align: center;
  line-height: normal;
  border: 0px;
  margin-top: 50px;
  
`;

const Button = props => {
  const { label } = props;
  return <Input label={label} onClick={props.onClick} />;
};

export default Button;
