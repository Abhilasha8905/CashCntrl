import React, { Component } from "react";
import styled from "styled-components";
import onClickOutside from "react-onclickoutside";
import { Container, Row, Col } from "react-bootstrap";
import statistics from "../images/flowChart/statistics.png";

import DropDown from "./dashboardComponents/DropDownFilterComponentInflow";
import { collectionsInflow, setFilterOptionsInflow } from "../actions/InflowActions";

const UL = styled.ul`
  list-style-type: none;
  margin-bottom: 0.2%;
`;

const Statistics = styled.img.attrs({
  src: statistics
})`
  vertical-align: middle;
  line-width: 30px
  width: 16px;
  height: 16px;
  object-fit: contain;
  margin-left:0;
  margin-right:5px;
  margin-bottom:5 px;
  `;

const Li = styled.li`
  float: left;
  display: inline-block;
  display: flex;
  margin-top: 8px;
  padding-left: 20px;
  line-height: 25px;
  margin: 10px 10px 0px 10px;
`;
const LiData = styled.li`
  padding: 1px 5px;
  margin-top: 8px;
  line-height: 25px;
  margin: 8px;
  display: table-row;
`;

const TopHeader = styled.div`
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
  background-color: #ffffff;
  width: 100%;
  margin: 0;
  height: 59.5pxx;
  left: 0px;
  margin-left: 0;
  position: relative;
`;

const Collections = styled.span`
  width: 123px;
  height: 18px;
  opacity: 0.5;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  line-height: 30px;
  cursor: pointer;
`;

const FloatRight = styled.div`
  float: right;
  width: 100%;
  display: flex;
  flex-flow: row;

  justify-content: flex-end;
  align-items: center;
`;

const FloatLeft = styled.div`
  float: left;
`;
const View = styled.span`
  width: 92px;
  height: 18px;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  margin-left: 5px;
`;
class FlowHeaderInflow extends Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
    this.handleEvents = this.handleEvents.bind(this);
  }

  handleClick(event) {
    this.props.collectionsInflow(event.target.id);
  }

  handleEvents(seeddd) {
    this.props.setFilterOptionsInflow(seeddd);
  }

  render() {
    return (
      // <TopHeader>
      //   <nav>
      //     <UL style={{ paddingInlineStart: "0" }}>
      //       <FloatLeft>
      //         <LiData>
      //           <Statistics />
      //           <View>{this.props.ViewName ? this.props.ViewName : "Customer View"}</View>
      //         </LiData>
      //       </FloatLeft>

      //       <FloatRight>
      //         <LiData>
      //           <Collections id="top_collections" onClick={() => this.handleClick(event)}>
      //             Top 10 Collections{" "}
      //           </Collections>
      //         </LiData>

      //         <LiData>
      //           <Collections id="bottom_collections" onClick={() => this.handleClick(event)}>
      //             {" "}
      //             Bottom 10 Collections
      //           </Collections>
      //         </LiData>

      //         <LiData>
      //           <Collections id="80_collections" onClick={() => this.handleClick(event)}>
      //             Top 80 Collections
      //           </Collections>
      //         </LiData>

      //         <LiData>
      //           <DropDown width="280px" setValues={this.handleEvents} />
      //         </LiData>
      //       </FloatRight>
      //     </UL>
      //   </nav>
      // </TopHeader>
      <Container
        fluid
        style={{
          backgroundColor: "#ffffff",
          marginBottom: "0.2%"
        }}
      >
        <Row>
          <Col xl={2} lg={2} md={2} sm={2} xs={2} style={{ display: "flex", alignItems: "center" }}>
            <FloatLeft>
              <Statistics />
              <View>{this.props.ViewName ? this.props.ViewName : "Customer View"}</View>
            </FloatLeft>
          </Col>
          <Col
            xl={10}
            lg={10}
            md={10}
            sm={10}
            xs={10}
            style={{ display: "flex", alignItems: "center", justifyContent: "space-evenly" }}
          >
            <UL style={{ paddingInlineStart: "0", width: "100%" }}>
              <FloatRight>
                <LiData>
                  <Collections id="top_collections" onClick={() => this.handleClick(event)}>
                    Top 10 Collections{" "}
                  </Collections>
                </LiData>

                <LiData>
                  <Collections id="bottom_collections" onClick={() => this.handleClick(event)}>
                    {" "}
                    Bottom 10 Collections
                  </Collections>
                </LiData>

                <LiData>
                  <Collections id="80_collections" onClick={() => this.handleClick(event)}>
                    Top 80% Collections
                  </Collections>
                </LiData>

                <LiData>
                  <DropDown
                    width="280px"
                    setValues={this.handleEvents}
                    options={this.props.options}
                    enteredAmountInflow={this.props.enteredAmountInflow}
                    rangeInflow={this.props.rangeInflow}
                  />
                </LiData>
              </FloatRight>
            </UL>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default FlowHeaderInflow;
