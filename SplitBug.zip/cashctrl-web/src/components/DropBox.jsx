import React, { Component } from "react";
import ReactDOM from "react-dom";
import styled from "styled-components";
import { Draggable } from "react-drag-and-drop";
import PropTypes from "prop-types";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import ConverUnit from "../utility/ConvertUnit";
import LiquiditySplitComponent from "./dashboardComponents/LiquiditySplitComponent";

const ExternalDiv = styled.div`
  height: ${props => (props.height ? props.height : "3.75em")};
  width: 90%;
  border-color: ${props => (props.mode === "OUTFLOW" ? "#FD8584" : "#69C2FE")};
  border-style: ${props => (props.borderStyle ? props.borderstyle : "dashed")};
  border-width: ${"1px"};
  float: left;
`;

const AmountView = styled.p`
  height: 17px;
  line-height: 0.93;
  text-align: left;
  margin: 10px 0px 0px 10px;
  color: ${props => (props.mode === "OUTFLOW" ? "#FD8584" : "#32A9FE")};
`;
const DescriptionView = styled.p`
  opacity: 0.8;
  font-family: Nunito;
  font-size: 8px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;

  color: var(--black);
`;

class DropBox extends Component {
  constructor(props) {
    super(props);
    this.state = {
      description: "Customer 2",
      // amount: this.props.invoiceValue,
      showDailog: false
    };
    this.onclick = this.onclick.bind(this);
    this.hideDIalog = this.hideDIalog.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.splitUpdate = this.splitUpdate.bind(this);
  }

  // componentWillReceiveProps(nextProps) {
  //   this.setState({
  //     amount: nextProps.invoiceValue
  //   });
  // }

  onclick() {
    const val = !this.state.showDailog;
    this.setState(
      {
        showDailog: !this.state.showDailog
      },
      () => {
        if (val) {
          document.addEventListener("mousedown", this.handleClickOutside);
        } else {
          document.removeEventListener("mousedown", this.handleClickOutside);
        }
      }
    );
  }

  hideDIalog() {
    this.setState({
      showDailog: false
    });
  }

  handleClickOutside(event) {
    const domNode = ReactDOM.findDOMNode(this);
    if (!domNode || !domNode.contains(event.target)) {
      this.setState({
        showDailog: false
      });
    }
  }

  splitUpdate(amount) {
    this.setState({
      showDailog: false
    });
    this.props.splitUpdate(this.props.id, amount, this.props.ledgerId, this.props.uniqueKey);
  }

  render() {
    console.log(this.props, ".....This.props");
    const description = this.props.description ? this.props.description : this.state.description;

    return (
      <Draggable data={description} style={{ position: "relative" }}>
        <span style={{ display: "inline-flex", float: "left", width: "10%" }}>
          <FontAwesomeIcon
            onClick={() => this.onclick()}
            icon={faEllipsisV}
            style={{ fontSize: "12", color: "#2e2e2e", opacity: "0.5" }}
          />
          <FontAwesomeIcon
            onClick={() => this.onclick()}
            icon={faEllipsisV}
            style={{ fontSize: "12", color: "#2e2e2e", opacity: "0.5", marginRight: "5px" }}
          />
          {this.state.showDailog && (
            <LiquiditySplitComponent
              hideDIalog={this.hideDIalog}
              invoiceValue={this.props.invoiceValue}
              splitUpdate={this.splitUpdate}
            />
          )}
        </span>{" "}
        <ExternalDiv {...this.props}>
          <AmountView {...this.state}>{ConverUnit(this.props.invoiceValue)}</AmountView>
          <DescriptionView>{description}</DescriptionView>
        </ExternalDiv>
      </Draggable>
    );
  }
}

export default DropBox;

DropBox.propTypes = {
  description: PropTypes.string.isRequired,
  amount: PropTypes.number.isRequired
};
