import React, { Component } from "react";
import { Row, Col, Container } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import ButtonGroupComponent from "./dashboardComponents/ButtonGroupComponent";
import DatePickerApply from "./DatepickerApply";

class SubHeaderInflow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fromDate: "",
      toDate: ""
    };
  }

  render() {
    return (
      <Container
        fluid
        style={{
          backgroundColor: "#ffffff",
          padding: "1%",
          marginBottom: "0.2%"
        }}
      >
        <Row>
          <Col xl={9} lg={8} md={9} sm={5} xs={5}>
            <DatePickerApply
              applyDatePicker={this.props.applyDatePicker}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
            />
          </Col>
          <Col
            xl={3}
            lg={4}
            md={3}
            sm={7}
            xs={7}
            style={{ display: "flex", alignItems: "center", justifyContent: "space-evenly" }}
          >
            <ButtonGroupComponent
              values={["Day", "Week", "Month"]}
              onButtonSelect={this.props.onButtonSelect}
              datefilter={this.props.datefilter}
            />
            {/* <FontAwesomeIcon
              icon={faEllipsisV}
              style={{ fontSize: "18", color: "#2e2e2e", opacity: "0.5", textAlign: "center" }}
            /> */}
          </Col>
        </Row>
      </Container>
    );
  }
}

export default SubHeaderInflow;
