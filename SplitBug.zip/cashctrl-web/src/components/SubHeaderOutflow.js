import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import { connect } from "react-redux";
import ButtonGroupComponent from "./dashboardComponents/ButtonGroupComponent";
import DatePickerApply from "./DatepickerApply";
import { addDateOutflow, onButtonSelectOutflow } from "../actions/OutFlowActions";

const Button = styled.button`
  background-color: #fbfcfe;
  border: none;
  border-radius: 0;
  font-family: Nunito;
  font-size: 11px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.36;
  letter-spacing: normal;
  text-align: center;
  color: var(--black);
  opacity: 0.7;
  padding: 8px;
  outline: none !important;
  &:hover ${Button} {
    background-color: #fbfcfe;
    border: 2px solid #c94593;
    color: #c94593;
    border-radius: 2px;
  }
  &:active ${Button} {
    background-color: #ffffff;
    border: 2px solid #c94593;
    color: #c94593;
    border-radius: 2px;
  }
  &:focus ${Button} {
    background-color: #ffffff;
    border: 2px solid #c94593;
    color: #c94593;
    border-radius: 2px;
  }
`;

class SubHeaderComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fromDate: "",
      toDate: ""
    };
  }

  render() {
    return (
      <Container
        fluid
        style={{
          backgroundColor: "#ffffff",
          padding: "1%",
          marginBottom: "0.2%"
        }}
      >
        <Row>
          <Col xl={5} lg={4} md={5} sm={5} xs={5}>
            <DatePickerApply
              applyDatePicker={this.props.applyDatePicker}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
            />
          </Col>
          <Col xl={4} lg={4} md={4} sm={4} xs={4}>
            <ButtonGroupComponent
              values={["Cheques issued", "PDC issued", "Non-negotiables"]}
              width="100px"
              onButtonSelect={id =>
                this.props.addOutflowType(this.props.fromDate, this.props.toDate, id)
              }
            />
          </Col>
          <Col
            xl={3}
            lg={4}
            md={3}
            sm={3}
            xs={3}
            style={{ display: "flex", alignItems: "center", justifyContent: "space-evenly" }}
          >
            <ButtonGroupComponent
              values={["Day", "Week", "Month"]}
              onButtonSelect={this.props.onButtonSelect}
              datefilter={this.props.datefilter}
            />
            {/* <FontAwesomeIcon
              icon={faEllipsisV}
              style={{ fontSize: "18", color: "#2e2e2e", opacity: "0.5", textAlign: "center" }}
            /> */}
          </Col>
        </Row>
      </Container>
    );
  }
}

export default SubHeaderComponent;
