import React, { Component } from "react";
import PropTypes from "prop-types";
import DragArea from "./DragArea";

class Collections extends Component {
  constructor(props) {
    super(props);
    this.state = {
      graphData: this.props.collection
    };
    this.state.listData = Object.assign([], this.state.graphData.map((o, i) => ({ ...o, id: i }))); // diff id for right list item
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      graphData: nextProps.collection
    });
    this.state.listData = Object.assign([], this.state.graphData.map((o, i) => ({ ...o, id: i }))); // diff id for right list item
  }

  render() {
    const { listData } = this.state;
    return (
      <DragArea
        data={this.props.collection}
        selectedView={this.props.selectedView}
        elementDropped={this.props.elementDropped}
        sortData={this.props.sortData}
      />
    );
  }
}

export default Collections;

Collections.propTypes = {
  selectedView: PropTypes.bool.isRequired,
  elementDropped: PropTypes.bool.isRequired
};
