import React, { Component } from "react";
import { Container, Row, Col, Image } from "react-bootstrap";

import styled from "styled-components";
import AccountDetailComponent from "./dashboardComponents/AccountDetailComponent";
import SubHeader from "./dashboardComponents/SubHeader";
import CardContainer from "./dashboardComponents/CardContainer";
import ReminderComponent from "./dashboardComponents/ReminderComponent";
import GraphContainer from "./dashboardComponents/GraphContainer";
import CalenderComponent from "./dashboardComponents/CalenderComponent";

const GraphDiv = styled.div`
  background-color: white;
  height: 46vh;
  overflow-x: hidden;
  overflow-y: hidden;
  @media (min-width: 1100px) {
    padding-top: "100px";
  }
`;
const ParentDiv = styled.div`
  background-color: white;
  height: 46vh;
 
`;
class Dashboard extends Component {
  constructor() {
    super();

    this.state = {
      isShowingModal: false,
      showCalender: false,
      calenderItems: [],
      modalTitle: '',
      titleColor: '',
      dashboardGraph: {
        currentPage: 0,
        numberOfPages: 1
      }
    };
    this.dashboardGraphParentRef = React.createRef();

    this.openModalHandler = this.openModalHandler.bind(this);
    this.closeModalHandler = this.closeModalHandler.bind(this);
    this.openCalenderView = this.openCalenderView.bind(this);
    this.closeCalenderView = this.closeCalenderView.bind(this);
    this.dashboardGraphNextPage = this.dashboardGraphNextPage.bind(this);
    this.dashboardGraphPrevPage = this.dashboardGraphPrevPage.bind(this);
  }

  componentDidMount() {
    this.initializeDashboardGraphState();
    this.scrollDashboardGraph();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.dates !== this.props.dates) {
      this.initializeDashboardGraphState();
    }

    if (prevState.dashboardGraph.currentPage !== this.state.dashboardGraph.currentPage) {
      this.scrollDashboardGraph();
    }
  }
  initializeDashboardGraphState() {
    const dashboardGraphParent = this.dashboardGraphParentRef.current;
    const parentWidth = dashboardGraphParent.clientWidth;
    const graphWidth = (this.props.dates.length > 25) ? 100 * this.props.dates.length : parentWidth;
    const numberOfPages = Math.ceil(graphWidth / parentWidth);
    this.setState({
      dashboardGraph: {
        currentPage: 0,
        numberOfPages
      }
    });

  }
  scrollDashboardGraph() {
    const dashboardGraphParent = this.dashboardGraphParentRef.current;
    const parentWidth = dashboardGraphParent.clientWidth;
    dashboardGraphParent.scrollLeft = parentWidth * this.state.dashboardGraph.currentPage;
  }
  dashboardGraphPrevPage() {
    this.setState((state) => {
      if (state.dashboardGraph.currentPage > 0) {
        return {
          ...state,
          dashboardGraph: { ...state.dashboardGraph, currentPage: state.dashboardGraph.currentPage - 1 }
        }
      };
      return state;
    });
  }
  dashboardGraphNextPage() {
    this.setState((state) => {
      if (state.dashboardGraph.currentPage < state.dashboardGraph.numberOfPages - 1) {
        return {
          ...state,
          dashboardGraph: { ...state.dashboardGraph, currentPage: state.dashboardGraph.currentPage + 1 }
        };
      }
      return state;
    });
  }
  openModalHandler(cardClicked, modalTitle, titleColor) {
    if (cardClicked === "bankBalance") {
      this.props.addCardsData();
      // this.props.addPDCOrClearIssue("bankBalance");
    }
    if (cardClicked === "cnClear") {
      // this.props.addPDCOrClearIssue("CNCI");
      this.props.addPDCOrClearIssue("CNCI");
    }

    if (cardClicked === "pdcIssue") {
      this.props.addPDCOrClearIssue("PDC");
    }
    this.setState({
      isShowingModal: true,
      modalTitle,
      titleColor
    });
  }

  closeModalHandler() {
    this.setState({
      isShowingModal: false,
      modalTitle: "",
      titleColor: ""
    });
  }

  openCalenderView(items) {
    this.setState({
      showCalender: true,
      calenderItems: items
    });
  }

  closeCalenderView() {
    this.setState({
      showCalender: false
    });
  }

  render() {
    const filterValue = this.state.isShowingModal || this.state.showCalender;
    return (
      <Container
        style={{
          maxWidth: "100%",
          height: "100%",
          position: "relative",
          backgroundColor: "#fbfcfe"
        }}
      >
        <Row
          style={{
            position: "absolute",
            width: "100%",
            height: "100%",
            backgroundColor: "rgb(248,249,251)",
            filter: filterValue ? "blur(4px)" : null
          }}
        >
          <Col xl={9} lg={9} md={12} xs={12} style={{ background: "rgb(248, 249, 251)" }}>
            <CardContainer
              openModalHandler={this.openModalHandler}
              bankBalance={this.props.bankBalance}
              cnClear={this.props.cnClear}
              ciClear={this.props.ciClear}
              pdcIssue={this.props.pdcIssue}
              cashBalance={this.props.cashBalance}
            />
            <SubHeader
              applyDatePicker={this.props.applyDatePicker}
              fromDate={this.props.fromDate}
              toDate={this.props.toDate}
              onButtonSelectDashboard={this.props.onButtonSelectDashboard}
              datefilter={this.props.datefilter}
            />
            <ParentDiv>
              <div className="row" style={{padding:"0px"}}>
              <div className="col-lg-10">
                <GraphDiv ref={this.dashboardGraphParentRef}>
                  <GraphContainer
                    dates={this.props.dates}
                    balanceData={this.props.balanceData}
                    inFlowData={this.props.inFlowData}
                    outFlowData={this.props.outFlowData}
                  />
                </GraphDiv>
                <div style=
                {{
                  width: "30px", height: "30px", background: "white", position: "absolute", bottom: "26px", border: "1px solid #ebebeb",
                  textAlign: "center", borderRadius: "5px"
                }}>
                <img
                  src={require("../images/flowChart/arrow-left.png")}
                  style={{ marginLeft: "0px" }}
                  onClick={this.dashboardGraphPrevPage}
                  disabled={this.state.dashboardGraph.currentPage === 0}
                />
              </div>
              <div style=
                {{
                  width: "30px", height: "30px", background: "white", position: "absolute", bottom: "26px", border: "1px solid #ebebeb",
                  textAlign: "center", borderRadius: "5px", right: "15px"
                }}>
                <img
                  src={require("../images/flowChart/arrow-right.png")}
                  style={{ marginLeft: "0px" }}
                  onClick={this.dashboardGraphNextPage}
                  disabled={this.state.dashboardGraph.currentPage === this.state.dashboardGraph.numberOfPages - 1}
                />
              </div>
              </div>
              <div className="col-lg-2 " style={{ padding:"0px",margin:"0px",marginTop:"50px" }}>
                <div style={{ fontSize: "12px",marginBottom:"20px" }}>
                  <span style={{ marginRight: "10px", width: "15px", height: "2px", backgroundColor: "#ffa600", display: "inline-block",marginBottom:"4px" }}></span>Inflow</div>
                <div style={{ fontSize: "12px",marginBottom:"20px"  }}>
                  <span style={{ marginRight: "10px", width: "15px", height: "2px", backgroundColor: "#c94593 ", display: "inline-block",marginBottom:"4px" }}></span>Outflow</div>
                <div style={{ fontSize: "12px",marginBottom:"20px"  }}>
                  <span style={{ marginRight: "10px", width: "15px", height: "2px", backgroundColor: "#20e12d", display: "inline-block",marginBottom:"4px" }}></span>Net Bank Balance</div>
              </div>
              </div>
            </ParentDiv>
          </Col>
          <Col
            xl={3}
            lg={3}
            md={12}
            xs={12}
            style={{ backgroundColor: "rgb(248, 249, 251)", paddingLeft: "10px" }}
          >
            <ReminderComponent openCalenderView={this.openCalenderView} 
            getReminderData={this.props.getReminderData} reminderCollections={this.props.reminderCollections}/>
          </Col>
        </Row>
        {this.state.isShowingModal && (
          <AccountDetailComponent
            style={{ zIndex: "10" }}
            isShowingModal={this.state.isShowingModal}
            closeModalHandler={this.closeModalHandler}
            dasboardTypeData={this.props.dasboardTypeData}
            cnClear={this.props.cnClear}
            ciClear={this.props.ciClear}
            pdcIssue={this.props.pdcIssue}
            dashboardType={this.props.dashboardType}
            dashboardTypeDataCnci={this.props.dashboardTypeDataCnci}
            dashboardTypeDataCncr={this.props.dashboardTypeDataCncr}
            bankBalance={this.props.bankBalance}
            modalTitle={this.state.modalTitle}
            titleColor={this.state.titleColor}
            addPDCOrClearIssue={this.props.addPDCOrClearIssue}
          />
        )}
        {this.state.showCalender && (
          <CalenderComponent
            isShowingModal={this.state.showCalender}
            closeModalHandler={this.closeCalenderView}
            events={this.state.calenderItems}
          />
        )}
      </Container>
    );
  }
}

export default Dashboard;
