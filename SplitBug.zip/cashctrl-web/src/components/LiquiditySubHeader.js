import React, { Component } from "react";
import { Row, Col, Container } from "react-bootstrap";
import styled from "styled-components";
import DropdownIcon from "../images/header/DropDownIcon.png";
import ExportButton from "./dashboardComponents/ExportButton";

const DropDownIcon = styled.img.attrs({
  src: DropdownIcon
})`
  width: 8px;
  height: 4.7px;
  object-fit: contain;
  vertical-align: middle;
  line-width: 30px;
  margin-left: 0.5rem;
`;

const FontStyle = styled.span`
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  opacity: 0.6;
  margin-top: 0.5rem;
  cursor:pointer;
`;

const Collections = styled.span`
  width: 123px;
  height: 18px;
  opacity: 0.5;
  font-family: Nunito;
  font-size: 13px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.38;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  line-height: 30px;
  cursor: pointer;
`;

class liquiditySubHeader extends Component {
  constructor(props) {
    super(props);
  }

  openModal() {
    this.props.openModal();
  }

  render() {
    return (
      <Container
        fluid
        style={{
          backgroundColor: "#ffffff",
          padding: "1%",
          marginBottom: "0.2%"
        }}
      >
        <Row>
          <Col xl={6} lg={6} md={6} sm={6} xs={6} style={{paddingLeft:"5%",textDecoration:"underline",color:"blue"}} >
            <FontStyle style={{color:"blue"}} onClick={() => this.openModal(event)}> Create New Scenario</FontStyle>
          </Col>
          {/* <Col xl={5} lg={4} md={4} sm={6} xs={6} style={{paddingLeft:"5%",display:"none"}}>
            <FontStyle>
              Open Scenario
              <DropDownIcon />
            </FontStyle>
          </Col> */}
          <Col xl={6} lg={6} md={6} sm={6} xs={6} style={{paddingLeft:"5%",textDecoration:"underline",color:"blue",textAlign:"right",paddingRight:"30px"}}>
            <FontStyle>Compare Scenarios</FontStyle>
          </Col>
        </Row>
      </Container>
    );
  }
}
export default liquiditySubHeader;
