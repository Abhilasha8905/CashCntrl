import React from "react";
import ClusterButton from "../../components/Dashboard/ClusterComponent";

class VendorCluster extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <ClusterButton
        visibility={this.props.visibility}
        name="Vendor Cluster"
        image={require("../../images/dashboard/vendor.svg")}
        style={{ float: "right" }}
      />
    );
  }
}
export default VendorCluster;
