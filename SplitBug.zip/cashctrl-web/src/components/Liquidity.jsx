import React, { Component } from "react";
import { Container, Row, Col, Image } from "react-bootstrap";
import styled from "styled-components";
import { connect } from "react-redux";
import moment from "moment";
import uuid from "uuid/v4";
import { isFuture } from "date-fns";
import memoizeOne from "memoize-one";
import LiquiditySubHeader from "./LiquiditySubHeader";
import Scenario from "./Scenario";
import PaymentCollection from "./PaymentsCollectionView";
import DropArea from "./DropArea";
import Payment from "./Payment";
import Collections from "./Collections";
import CreateNewScenario from "./CreateNewScenario";
import Modal from "./dashboardComponents/Modals/Modal";
import { getCustomerLedgerTotals } from "../utility/LiquidityUtil";

const getUpdatedPayments = function(payment, graphData) {
  return payment.map(payment => {
    const graphLedgers = graphData.filter(it => it.ledgerId == payment.ledgerId);
    const totalAmountEntered = graphLedgers.reduce((acc, it) => acc + it.invoiceValue, 0);

    // TODO: change it to not_dropped?
    let status = null;

    if (graphLedgers.length > 0) {
      if (totalAmountEntered === payment.invoiceValue) {
        status = "COMPLETE";
      } else {
        status = "PARTIAL";
      }
    }

    return {
      ...payment,
      status
    };
  });
};

const getUpdatedCollection = function(collection, graphData) {
  return collection.map(payment => {
    const graphLedgers = graphData.filter(it => it.ledgerId == payment.ledgerId);
    const totalAmountEntered = graphLedgers.reduce((acc, it) => acc + it.invoiceValue, 0);

    // TODO: change it to not_dropped?
    let status = null;

    if (graphLedgers.length > 0) {
      if (totalAmountEntered === payment.invoiceValue) {
        status = "COMPLETE";
      } else {
        status = "PARTIAL";
      }
    }

    return {
      ...payment,
      status
    };
  });
};

const getOverLoadUpdatedCollection = (
  collection,
  GroupedInvoice,
  i,
  updatedTotalEntered,
  status
) => {
  if (i < 0 || i > GroupedInvoice.length - 1) {
    return collection;
  }
  const invoiceTobeUpdate = collection.map(it => {
    let index = i;
    if (status === "Equal") {
      index -= 1;
    } else {
      index += 1;
    }
    if (it.ledgerId === GroupedInvoice[i].ledgerId) {
      if (updatedTotalEntered === it.invoiceValue) {
        it.status === "COMPLETE";
      } else if (updatedTotalEntered > it.invoiceValue) {
        it.status === "COMPLETE";
        getOverLoadUpdatedCollection(
          collection,
          GroupedInvoice,
          index,
          updatedTotalEntered - it.invoiceValue,
          status
        );
      } else {
        it.status = "PARTIAL";
        it.invoiceValue -= updatedTotalEntered;
      }
    }
    console.log(invoiceTobeUpdate, "invoiceTobeUpdate");
    return invoiceTobeUpdate;
  });
};

const GraphImg = styled(Image).attrs({
  src: props => props.imageURL
})`
  margin: 0%;
`;
const RowContainer = styled(Row)`
  margin-left: -1px;
  margin-right: -1px;
`;

const Div = styled.div`
  display: flex;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.04);
  flex-direction: column;
`;

const Line = styled.div`
  opacity: 0.05;
  border: solid 1px var(--black);
`;

class Liquidity extends Component {
  constructor(props) {
    super(props);
    this.state = {
      yAxis: ["10k", "15k", "20k", "25k", "30k", "35k", "40k", "45k", "50k", "55k", "60k"],
      xAxis: [...this.props.dates],
      graphData: this.props.scenarioData,
      selectedViewVr: "Payment",
      isDropped: false,
      openModal: false,
      newScenarioData: [],
      scenarioName: this.props.scenarioName,
      payment: this.props.payment,
      collection: this.props.collection,
      draggedId: "",
      customerLedgerTotals: getCustomerLedgerTotals(this.props.ledgerData, this.props.scenarioData)
    };
    this.state.listData = Object.assign([], this.state.graphData.map((o, i) => ({ ...o, id: i }))); // diff id for right list item
    this.onDrop = this.onDrop.bind(this);
    this.splitUpdate = this.splitUpdate.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    // if (!nextProps.newlyCreated) {

    if (this.props.scenarioData !== nextProps.scenarioData) {
      this.setState({
        xAxis: nextProps.dates,
        graphData: nextProps.scenarioData,
        scenarioData: nextProps.scenarioData
      });
    }

    if (
      this.props.ledgerData !== nextProps.ledgerData &&
      this.props.ledgerData !== nextProps.ledgerData
    ) {
      this.setState({
        customerLedgerTotals: getCustomerLedgerTotals(
          this.props.ledgerData,
          this.props.scenarioData
        )
      });
    }

    this.setState({
      scenarioName: nextProps.scenarioName,
      payment: nextProps.payment,
      collection: nextProps.collection
    });
  }

  selectedView(selectedView) {
    this.setState({ selectedViewVr: selectedView });
  }

  splitUpdate(id, amount, ledgerId, uniqueKey) {
    // required for overshoot
    // const customerTotals = this.state.customerLedgerTotals[id];

    const scenarioLedger = this.state.graphData.find(it => it.uniqueKey === uniqueKey);
    let ledger = this.props.ledgerData.collection.find(it => it.ledgerId === ledgerId);
    ledger = ledger || this.props.ledgerData.payments.find(it => it.ledgerId === ledgerId);

    if (!ledger || !scenarioLedger) {
      return;
    }
    const updatedNewScenarioData = this.state.newScenarioData.filter(
      o => o.uniqueKey !== scenarioLedger.uniqueKey
    );
    const totalAmountEntered = this.state.graphData
      .filter(it => it.ledgerId == ledgerId)
      .reduce((acc, it) => acc + it.invoiceValue, 0);

    const previousAmount = scenarioLedger.invoiceValue;
    const currentAmount = parseInt(amount, 10);

    if (isNaN(currentAmount)) {
      return;
    }

    const differenceEntered = currentAmount - previousAmount;

    let updatedStatus = scenarioLedger.status;

    const amountToBeUpdated = currentAmount;

    if (differenceEntered === 0) {
      return;
    }
    const updatedTotalEntered = totalAmountEntered + differenceEntered;
    const newData = [];
    if (currentAmount > ledger.invoiceValue) {
      updatedStatus = "COMPLETE";
      debugger;
      // overshoot TODO: handle
      let GroupedInvoice = this.state.payment
        .filter(it => it.id == id)
        .sort((a, b) => a.age - b.age);

      GroupedInvoice =
        GroupedInvoice.length > 0
          ? GroupedInvoice
          : this.state.collection.filter(it => it.id == id).sort((a, b) => a.age - b.age);

      const index = GroupedInvoice.findIndex(x => x.ledgerId === ledgerId);

      if (GroupedInvoice.length <= 1) {
        // Update cant happen msg here
        return;
      }
      if (GroupedInvoice.length - 1 === index) {
        return;
      }
      let newAmount = currentAmount - ledger.invoiceValue;
      const newFroupedData = GroupedInvoice.filter((it, i) => i > index);
      newFroupedData.map(it => {
        debugger;
        console.log(newFroupedData, "GroupedInvoice");
        console.log(index, "index");
        if (it.invoiceValue === newAmount && newAmount > 0) {
          const newValue1 = {
            ...it,
            invoiceValue: newAmount,
            status: "COMPLETE",
            uniqueKey: uuid()
          };
          updatedNewScenarioData.push(newValue1);
        }
        if (it.invoiceValue > newAmount && newAmount > 0) {
          const newValue2 = {
            ...it,
            invoiceValue: it.invoiceValue - newAmount,
            status: "PARTIAL",
            uniqueKey: uuid()
          };
          updatedNewScenarioData.push(newValue2);
          newAmount -= it.invoiceValue;
        }
        if (it.invoiceValue < newAmount && newAmount > 0) {
          const newValue3 = {
            ...it,
            status: "COMPLETE",
            uniqueKey: uuid()
          };
          updatedNewScenarioData.push(newValue3);
          newAmount -= it.invoiceValue;
        }
      });
      // newData = getOverLoadUpdatedCollection(
      //   this.state.payment,
      //   GroupedInvoice,
      //   index,
      //   updatedTotalEntered,
      //   "NotEqual"
      // );
      // }
    }
    if (currentAmount === ledger.invoiceValue) {
      updatedStatus = "COMPLETE";
    } else if (currentAmount < ledger.invoiceValue) {
      updatedStatus = "PARTIAL";
    }
    console.log(updatedStatus, "  ");
    const newValue = {
      ...scenarioLedger,
      invoiceValue: amountToBeUpdated,
      status: updatedStatus
    };

    const newValue4 = {
      ...scenarioLedger,
      invoiceValue: ledger.invoiceValue,
      status: updatedStatus
    };

    const newGraphData = this.state.graphData.filter(o => o.uniqueKey !== scenarioLedger.uniqueKey);
    newGraphData.push(newValue); // add dragged row to graph data

    updatedNewScenarioData.push(newValue4);
    console.log(updatedNewScenarioData, "updatedNewScenarioData");
    this.setState({
      graphData: newGraphData,
      newScenarioData: updatedNewScenarioData
    });
  }

  updateGraphData(data, key) {
    const { graphData } = this.state;
    const { newScenarioData } = this.state;
    // graphData = graphData.filter(o => o.id !== data.id);

    const totalAmountEntered = this.state.graphData
      .filter(it => it.ledgerId == data.ledgerId)
      .reduce((acc, it) => acc + it.invoiceValue, 0);

    const invoiceValue = data.invoiceValue - totalAmountEntered;
    if (invoiceValue <= 0) return;

    const newValue = Object.assign({}, data, { date: key, uniqueKey: uuid(), invoiceValue });
    graphData.push(newValue); // add dragged row to graph data

    this.setState({
      graphData,
      isDropped: true,
      newScenarioData: [...this.state.newScenarioData, newValue]
    });
  }

  updateGraphRowData(data, key) {
    let { graphData } = this.state;
    const { newScenarioData } = this.state;
    const newValue = Object.assign({}, data, { date: key, uniqueKey: uuid() });

    graphData = graphData.filter(o => o.uniqueKey !== data.uniqueKey);
    graphData.push(newValue); // add dragged row to graph data

    const updatedNewScenarioData = newScenarioData.filter(o => o.uniqueKey !== data.uniqueKey);
    updatedNewScenarioData.push(newValue);

    this.setState({ graphData, newScenarioData: updatedNewScenarioData });
  }

  openModal() {
    this.setState({
      openModal: true
    });
  }

  closeModalHandler() {
    this.setState({
      openModal: false
    });
  }

  addedScenarioName(name) {
    this.setState({
      openModal: false,
      scenarioName: name
    });

    this.props.createScenario(name, this.state.graphData);
  }

  saveScenario() {
    const param = {};
    const invoiceRequestDtoList = [];

    this.state.newScenarioData.map(currentLedger => {
      invoiceRequestDtoList.push({
        ledger: {
          id: currentLedger.ledgerId
        },
        updatedDate: moment(currentLedger.date, "DD/MM/YYYY").format("YYYY-MM-DD"),
        updatedAmount: parseFloat(currentLedger.invoiceValue),
        subLedgerId: currentLedger.subLedgerId,
        status: currentLedger.status,
        mode: currentLedger.mode
      });
    });
    param.invoiceRequestDtoList = invoiceRequestDtoList;

    const savingData = this.props.scenarioNames.filter(x => {
      return this.props.scenarioName === x.name;
    });

    if (savingData.length === 0) {
      param.scenario = {
        name: this.state.scenarioName
      };
      this.props.saveScenario(param);
      this.setState({
        newScenarioData: []
      });
    } else {
      param.scenario = {
        id: savingData[0].id
      };
      this.props.UpdateScenario(param);
    }
  }

  deleteScenario() {
    this.props.DeleteScenario();
  }

  onDrop(data) {
    const draggedId = JSON.parse(data.row_item).ledgerId;
    this.setState({ draggedId });
  }

  render() {
    const { xAxis, yAxis, graphData, listData } = this.state;

    const collection = getUpdatedCollection(this.props.collection, graphData);
    const payment = getUpdatedPayments(this.props.payment, graphData);
    console.log(this.state.newScenarioData, "....jjjj");
    return (
      <Container style={{ maxWidth: "100%", position: "relative" }}>
        <Row
          style={{
            position: "absolute",
            width: "100%",
            height: "100%"
          }}
        >
          <Col lg={7} md={7} xs={12} style={{ paddingRight: "0" }}>
            <LiquiditySubHeader
              style={{ borderRadius: "0px", border: "solid", borderColor: "#FBFBFB" }}
              openModal={this.openModal.bind(this)}
            />
            <Scenario
              style={{
                borderRadius: "0px",
                border: "solid",
                borderColor: "#FBFBFB",
                backgroundColor: "#FFFFFF"
              }}
              saveScenario={this.saveScenario.bind(this)}
              scenarioName={this.props.scenarioName}
              deleteScenario={this.deleteScenario.bind(this)}
              currentScenario={this.props.currentScenario}
              newlyCreated={this.props.newlyCreated}
              scenarioNames={this.props.scenarioNames}
            />

            <DropArea
              xAxis={xAxis}
              yAxis={yAxis.reverse()}
              graphData={this.state.graphData}
              updateGraphData={this.updateGraphData.bind(this)}
              updateGraphRowData={this.updateGraphRowData.bind(this)}
              style={{
                borderRadius: "0px",
                border: "solid",
                borderColor: "#FBFBFB",
                width: "500px",
                overflowX: "auto",
                pointerEvents: "none"
              }}
              selectedView={this.state.selectedViewVr}
              splitUpdate={this.splitUpdate}
              onDrop={this.onDrop}
            />
          </Col>

          <Col
            lg={5}
            md={5}
            xs={12}
            style={{
              backgroundColor: "rgb(248,249,251)"
            }}
          >
            <PaymentCollection selectedView={this.selectedView.bind(this)} />
            <Line />
            {this.state.selectedViewVr === "Payment" && (
              <Payment
                payment={payment}
                sortData={this.props.sortData}
                elementDropped={this.state.draggedId}
              />
            )}
            {this.state.selectedViewVr === "Collection" && (
              <Collections
                collection={collection}
                sortData={this.props.sortData}
                elementDropped={this.state.draggedId}
              />
            )}
          </Col>
        </Row>
        {this.state.openModal && (
          <CreateNewScenario
            style={{ zIndex: "10" }}
            isShowingModal={this.state.openModal}
            closeModalHandler={this.closeModalHandler.bind(this)}
            addedScenarioName={this.addedScenarioName.bind(this)}
          />
        )}
      </Container>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    isDropped: isDropped => dispatch(isDropped(this.state.isDropped))
  };
};
export default connect(
  null,
  mapDispatchToProps
)(Liquidity);
