import React, { Component } from "react";
import { Row, Col, Container } from "react-bootstrap";
import styled from "styled-components";

const Image = styled.img.attrs({
  src: props => props.imageURL
})`
  height: 10px;
  width: 10px;
  margin-right: 0.5rem;
`;
const FontStyle = styled.div`
  font-family: Montserrat;
  font-size: 12px;
  font-weight: 600;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.17;
  letter-spacing: normal;
  text-align: left;
  color: var(--black);
  margin-top: 0.5rem;
  cursor:pointer;
`;

class Scenario extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scenarioName: this.props.scenarioName
    };
  }

  saveScenario() {
    this.props.saveScenario();
    alert("Scenario Saved");
  }

  deleteScenario() {
    alert("Scenario Deleted");
    this.props.deleteScenario();
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      scenarioName: nextProps.scenarioName
    });
  }

  render() {
    return (
      <Container style={{ backgroundColor: "white", height: "50px" }}>
        <Row style={{ paddingTop: "10px",paddingBottom:"10px" }}>
          <Col xl={8} lg={8} md={8} sm={6} xs={6} style={{ float: "left", paddingLeft: "5%" }}>
            <FontStyle>Current Scenario :
{this.state.scenarioName}
</FontStyle>
          </Col>

          <Col xl={2} lg={2} md={2} sm={6} xs={6} style={{ float: "right" }}>
            <FontStyle
              onClick={() => {
                this.deleteScenario();
              }}
            >
              <Image imageURL={require("./../images/liquidity/delete.svg")} />
              Delete
            </FontStyle>
          </Col>
          <Col xl={2} lg={2} md={2} sm={6} xs={6}>
            <FontStyle
              onClick={() => {
                this.saveScenario();
              }}
            >
              <Image imageURL={require("./../images/liquidity/save-file-option.svg")} />
              Save
            </FontStyle>
          </Col>
        </Row>
      </Container>
    );
  }
}
export default Scenario;
