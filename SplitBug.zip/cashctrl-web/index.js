import React from "react";
import { hydrate } from "react-dom";
import { Provider } from "react-redux";
import App from "./src/App";
import configureStore from "./src/store/Store";
import "bootstrap/dist/css/bootstrap.min.css";

hydrate(
  <Provider store={configureStore()}>
    <App />
  </Provider>,
  document.getElementById("root")
);
