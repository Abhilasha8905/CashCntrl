module.exports = results => {
  return results
    .map(result => {
      return `${result.errorCount}|${result.warningCount}|${result.filePath}`;
    })
    .join("\n");
};
