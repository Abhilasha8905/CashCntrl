module.exports = (...args) => {
  require("./node_modules/jest-junit-reporter")(...args);
  return require("./node_modules/jest-json-reporter")(...args);
};
