# Cashctrl
React Project 

## Installation
Navigate to :  \cashctrl\ui\cash-control>
Run "npm install" inside the folder
Run "npm run build:dev"
Run "npm run start"




